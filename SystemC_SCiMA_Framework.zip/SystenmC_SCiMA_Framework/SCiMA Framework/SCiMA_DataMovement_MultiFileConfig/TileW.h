#include "Cluster.h"
#include "BurstChannel.h"

/*
-The third level of architecture is Tile.
-Tile includes an array of clusters, memory, maxpooling unit, activation.
-The dataflow is Systeolic among clusters of tile.
-paraemters of Tile sc_module are as follows:
*/

template<int TmemSize, int TileDTR, int mc, int nc, int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
SC_MODULE(TileW)
{
#define CTTR (mc==1 && nc==1)? 0 : TileDTR

	ofstream record;
	string filename;

	int C; int r; int s; int K; int Strd;
	//int *ClustWeight;
	//ClustWeight = (int*)malloc(2);
	//int *ClustWeight;
	int *TileWeight;
	bool COMP;
	int Hi, Wi, Ci, Ho, Wo, Co, NWi, NWo;
	int H, W;
	int ODS; int IDS; int cpv; int kpv; int cpc; int kpc;
	int TileID;
	string namemodule;


	int mac; int nac;

	sc_port<Pburst_write_if> InitPort;
	sc_port<Pburst_read_if>  TargetPort;


	sc_export<burst_write_if> InLeftCs[mc];
	sc_export<burst_read_if>  OutDownCs[nc];

	int *databufferI;
	int *databufferO;

	bool Activation;
	int PoolSize;
	bool NFC;

	TransferConfig *inputConfig;
	TransferConfig *outputConfig;
	TransferConfig *partialConfig;

	int InputConfigSize;
	int OutputConfigSize;
	int PartialConfigSize;

	Cluster <ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk> *Clusters[mc][nc];

	Chanel< CTTR, CTTR>* chanInD[mc][nc];
	Chanel< CTTR, CTTR>* chanOutD[mc][nc];

	Chanel<CTTR, CTTR>* chanTCin[mc];
	Chanel<CTTR, CTTR>* chanTCout[nc];

	sc_event GetP, GetI;
	bool fGetP = false;

	TileW(sc_module_name name, int C_, int r_, int s_, int K_, int Strd_, bool COMP_,
		bool Activation_, int PoolSize_, bool NFC_,
		int Hd_, int Wd_, int *TileWeight_, bool PartialSum_, int TileID_,
		TransferConfig *inputConfig_, TransferConfig *outputConfig_, TransferConfig *partialConfig_,
		int InputConfigSize_, int OutputConfigSize_, int PartialConfigSize_) :sc_module(name)
	{

		string direct = "Tile\\";
		string parent = get_parent()->basename();
		string modulename = name;
		string namemodule1 = parent + modulename;
		filename = direct + namemodule1 + ".rec";// +name() + ".rec";
		record.open(filename);

		TileID = TileID_;
		Activation = Activation_;
		PoolSize = PoolSize_;
		NFC = NFC_;
		H = Hd_; W = Wd_;
		C = C_; r = r_; s = s_; K = K_; Strd = Strd_;
		Ho = ((H > Strd) ? (H / Strd) : 1);
		Wo = ((W > Strd) ? (W / Strd) : 1);
		Co = K;
		COMP = COMP_;

		inputConfig = inputConfig_;
		outputConfig = outputConfig_;
		partialConfig = partialConfig_;

		InputConfigSize = InputConfigSize_;
		OutputConfigSize = OutputConfigSize_;
		PartialConfigSize = PartialConfigSize_;

		//*FTileWeight = (int *)malloc(r*s*C*K);
		TileWeight = TileWeight_;

		cpv = (s==1)? 1 :(VIVS / (r*s));
		kpv = VOVS;
		cpc = cpv*mv;
		kpc = kpv * nv;
		mac = int((C - 1) / (cpc)) + 1;
		nac = int((K - 1) / (kpc)) + 1;
		int *ClustWeight = new int[1];
		cout << "Tile instantion: " << TileID<<endl;
		for (int i = 0; i < mc; i++)
		for (int j = 0; j < nc; j++){
			namemodule = "Cluster__" + to_string(i) + "__" + to_string(j);
			if (COMP == false){
				int *ClustWeight = new int[1];
				Clusters[i][j] = new Cluster <ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>(namemodule.c_str(), 0, r, s, 0, 0, 0, 0, 0, 0, 0, ClustWeight);
			}
			else{
				//Determine speicified kernels and channels to Cluster
				int chanClus, kernelClus;
				if (i < (mc - mac)) chanClus = 0;
				else if (i == mc - 1) chanClus = C - (mac - 1)*cpc;
				else chanClus = cpc;
				if (j < nac - 1) kernelClus = kpc;
				else if (j == nac - 1) kernelClus = K - (nac - 1)*kpc;
				else kernelClus = 0;
				// Truncate weights specified to each cluster
				int *ClustWeight = new int[1];
				if (kernelClus != 0 && chanClus != 0) {
					/*F
					for (int kw = 0; kw < kernelClus; kw++){
						for (int xw = 0; xw < r; xw++)
						for (int yw = 0; yw < s; yw++)
						for (int cw = 0; cw < chanClus; cw++){

							int Cindexi = (cw)+(xw)* chanClus*s + (yw)* chanClus;
							int Cindexj = (kw);

							int indexi = ((i - (mc - mac)) * cpc + cw) + (xw)* C*s + (yw)* C;
							int indexj = (kpc * j + kw);

							if (indexj < K && indexi < (r*s*C) && ((i - (mc - mac)) * cpc + cw) < C){
								int cidx, tidx;
								cidx = Cindexi + Cindexj*(r*s*chanClus);
								tidx = indexi + indexj*(r*s*C);
								int tw = *(TileWeight + tidx);
								if (cidx == (r*s*chanClus*kernelClus - 1)){
									int ccc = cidx;
								}
								*(ClustWeight + cidx) = tw;
							}
							else{
								int cc = 1;
							}
						}
					}
					*/
				}
				//Determinne interface flags
				bool compute, leftInterface, rightinterface, topinterface, buttominterface;
				compute = (kernelClus == 0 || chanClus == 0) ? 0 : 1;
				leftInterface = (kernelClus == 0 || chanClus == 0) ? 0 : 1;
				rightinterface = ((i >= (mc - mac)) && (j < nac - 1)) ? 1 : 0;
				topinterface = ((i >(mc - mac)) && (j <= nac - 1)) ? 1 : 0;
				buttominterface = ((i >= (mc - mac)) && (j <= nac - 1)) ? 1 : 0;
				//Instantiation

				Clusters[i][j] = new Cluster <ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>(namemodule.c_str(), chanClus, r, s, kernelClus, Strd, leftInterface, rightinterface, topinterface, buttominterface, compute, ClustWeight);

				delete[] ClustWeight;
			}
		}
		for (int i = 0; i < mc; i++)
		for (int j = 0; j < nc; j++){
			string namemodule = "chanelsL" + to_string(i) + "_" + to_string(j);
			chanInD[i][j] = new Chanel<CTTR, CTTR>(namemodule.c_str());
		}
		for (int i = 0; i < mc; i++)
		for (int j = 0; j < nc; j++){
			string namemodule = "chanelsR" + to_string(i) + "_" + to_string(j);
			chanOutD[i][j] = new Chanel<CTTR, CTTR>(namemodule.c_str());
		}
		for (int i = 0; i < mc; i++){
			string namemodule = "chanTCin" + to_string(i);
			chanTCin[i] = new Chanel< CTTR, CTTR>(namemodule.c_str());
		}
		for (int i = 0; i < nc; i++){
			string namemodule = "chanTCout" + to_string(i);
			chanTCout[i] = new Chanel<CTTR, CTTR>(namemodule.c_str());
		}
		for (int i = 0; i < mc - 1; i++)
		for (int j = 1; j < nc; j++){
			Clusters[i][j]->inL(*chanInD[i][j - 1]);
			Clusters[i][j]->inU(*chanOutD[i][j]);
			Clusters[i][j]->outR(*chanInD[i][j]);
			Clusters[i][j]->outD(*chanOutD[i + 1][j]);
		}

		for (int i = 0; i < mc - 1; i++){
			InLeftCs[i](*chanTCin[i]);
			Clusters[i][0]->inL(*chanTCin[i]);
			Clusters[i][0]->inU(*chanOutD[i][0]);
			Clusters[i][0]->outR(*chanInD[i][0]);
			Clusters[i][0]->outD(*chanOutD[i + 1][0]);
		}
		for (int i = 1; i < nc; i++){
			OutDownCs[i](*chanTCout[i]);
			Clusters[mc - 1][i]->inL(*chanInD[mc - 1][i - 1]);
			Clusters[mc - 1][i]->inU(*chanOutD[mc - 1][i]);
			Clusters[mc - 1][i]->outR(*chanInD[mc - 1][i]);
			Clusters[mc - 1][i]->outD(*chanTCout[i]);
		}
		OutDownCs[0](*chanTCout[0]);
		InLeftCs[mc - 1](*chanTCin[mc - 1]);
		Clusters[mc - 1][0]->inL(*chanTCin[mc - 1]);
		Clusters[mc - 1][0]->inU(*chanOutD[mc - 1][0]);
		Clusters[mc - 1][0]->outR(*chanInD[mc - 1][0]);
		Clusters[mc - 1][0]->outD(*chanTCout[0]);




		SC_THREAD(InputComputeFunction);
		SC_THREAD(PartialOutputFunction);
		//set_stack_size(400097152);
	}
	SC_HAS_PROCESS(TileW);
	void InputComputeFunction();
	void PartialOutputFunction();
};


template<int TmemSize, int TileDTR, int mc, int nc, int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
void TileW <TmemSize, TileDTR, mc, nc, ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>::InputComputeFunction(){
	PacketBurst packetRecInput;
	DataVol ClusDataPAck;
	DataVol ClusterDataPackI, ClusterDataPackO;
	int *bufD;
	int *ClusterIFM;
	databufferI = (int *)malloc(1);
	bool DoneInputTransfer = false;
	while (COMP){
		record << "IFMCONTROLLER WAITS_GET_ALL_IFM @ " << sc_time_stamp() << endl;
		while (DoneInputTransfer == false){
			/********Receive input data****/
			//cout << "--------------" << name() << " waits getting next IFM " << " at time : " << sc_time_stamp() << endl;
			wait(1, SC_NS);
			packetRecInput = TargetPort->burstRead();
			cout << "--------------" << name() << " Got next IFM " << " at time : " << sc_time_stamp() << endl;

			/********set flag of corresponding batch****/
			int sourceID = packetRecInput.sourceNum;
			int index = 0;
			inputConfig[index].ListTile.readReset();
			int rr = inputConfig[index].ListTile.getNextNode();
			while (rr != sourceID){
				index++;
				inputConfig[index].ListTile.readReset();
				rr = inputConfig[index].ListTile.getNextNode();
			}
			inputConfig[index].done = true;
			inputConfig[index].ListTile.readReset();

			/********concatenate subpatches to generate batch****/
			int His = inputConfig[index].H1; int Hie = inputConfig[index].H2;
			int Wis = inputConfig[index].W1; int Wie = inputConfig[index].W2;
			int Cis = inputConfig[index].C1; int Cie = inputConfig[index].C2;
			/*F
			for (int i = His; i <= Hie; i++)
			for (int j = Wis; j <= Wie; j++)
			for (int k = Cis; k <= Cie; k++){
				int idx_s = (k - Cis) + (i - His)* (Wie - Wis + 1)* (Cie - Cis + 1) + (j - Wis)*(Cie - Cis + 1);
				int idx_d = (k)+(i)* W*C + (j)*C;
				int tt = *(packetRecInput.data + idx_s);
				*(databufferI + idx_d) = tt;
			}
			*/
			DoneInputTransfer = true;
			for (int i = 0; i < InputConfigSize; i++)
				DoneInputTransfer = DoneInputTransfer & inputConfig[i].done;
		}
		record << "IFMCONTROLLER GOT_ALL_IFM @ " << sc_time_stamp() << endl;
		for (int i = 0; i < InputConfigSize; i++) inputConfig[i].done = false;
		DoneInputTransfer = false;
		/* Sending sub bacthes to clusters*/
		for (int c = mc - mac; c < mc; c++){
			int IfmCh;

			if (c == mc - 1)  IfmCh = C - (mac - 1)*cpc;
			else IfmCh = cpc;
			//ClusterIFM = (int *)realloc(ClusterIFM, 5*Hi*Wi*IfmCh);

			int *ClusterIFM = new int[H*W*IfmCh];
			/*F
			for (int x = 0; x < H; x++)
			for (int y = 0; y < W; y++)
			for (int z = 0; z < IfmCh; z++)
			{
				int CAddindx = (z)+(x)* W*IfmCh + (y)*IfmCh;
				int TAddindx = (z + (c - (mc - mac)) *cpc) + (x)* W*C + (y)*C;
				*(ClusterIFM + CAddindx) = *(databufferI + TAddindx);
			}
			*/
			ClusDataPAck.H = H;
			ClusDataPAck.W = W;
			ClusDataPAck.C = IfmCh;
			ClusDataPAck.data = ClusterIFM;
			//cout << "--------------" << name() << " waits sending to cluster : " << c << " at time : " << sc_time_stamp() << endl;
			InLeftCs[c]->burstWrite(ClusDataPAck);
			//cout << "--------------" << name() << " did  sending  to cluster : " << c << " at time : " << sc_time_stamp() << endl;
			int IndexTiout = 0;

		}
		record << "IFMCONTROLLER SENT_ALL_IFM @ " << sc_time_stamp() << endl;
		wait(GetI);
	}
}



template<int TmemSize, int TileDTR, int mc, int nc, int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
void TileW< TmemSize, TileDTR, mc, nc, ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>::PartialOutputFunction(){
	DataVol 	ClusDataPAck;
	PacketBurst PacketRecPar;
	PacketBurst PacketSendOut;
	DataVol ClusterDataPackI, ClusterDataPackO;
	int *bufD;
	int * ClusterIFM;
	ClusterIFM = (int*)malloc(2);
	databufferO = (int *)malloc(1);
	while (COMP){
		record << "OFMCONTROLLER WAITS_GET_ALL_OFM @ " << sc_time_stamp() << endl;
		int IndexTiout = 0;
		for (int c = 0; c < nac; c++){
			int OfmH, OfmW, OfmC;
			cout << "--------------" << name() << " waits Getting OFM from cluster : " << c << " at time : " << sc_time_stamp() << endl;
			ClusDataPAck = OutDownCs[c]->burstRead();
			//cout << "--------------" << name() << " Got OFM from cluster : " << c << " at time : " << sc_time_stamp() << endl;
			bufD = ClusDataPAck.data;
			OfmH = ClusDataPAck.H; OfmW = ClusDataPAck.W; OfmC = ClusDataPAck.C;
			int idxClusOFM, idxTileOFM;
			/*F
			for (int x = 0; x < OfmH; x++)
			for (int y = 0; y < OfmW; y++)
			for (int z = 0; z < OfmC; z++)
			{
				int idxClusOFM = (z)+(x)* OfmW*OfmC + (y)*OfmC;
				int idxTileOFM = (z + c *kpc) + (x)* OfmW*K + (y)*K;
				int x = *(bufD + idxClusOFM);
				*(databufferO + idxTileOFM) = *(bufD + idxClusOFM);
			}
			*/
		}
		record << "OFMCONTROLLER GOT_ALL_OFM @ " << sc_time_stamp() << endl;
		if (PartialConfigSize>0) {
			bool DonePartialTransfer = false;
			while (DonePartialTransfer == false){
				cout << "--------------" << name() << " waits getting next Partial " << " at time : " << sc_time_stamp() << endl;
				wait(1, SC_NS);
				PacketRecPar = TargetPort->burstRead();
				cout << "--------------" << name() << " Got next Partial " << " at time : " << sc_time_stamp() << endl;

				int sourceID = PacketRecPar.sourceNum;
				int index = 0;
				partialConfig[index].ListTile.readReset();
				while (partialConfig[index].ListTile.getNextNode() != sourceID){
					partialConfig[index].ListTile.readReset();
					index++;
				}

				partialConfig[index].done = true;
				partialConfig[index].ListTile.readReset();
				int Hps = partialConfig[index].H1; int Hpe = partialConfig[index].H2;
				int Wps = partialConfig[index].W1; int Wpe = partialConfig[index].W2;
				int Cps = partialConfig[index].C1; int Cpe = partialConfig[index].C2;
				/*F
				for (int i = Hps; i <= Hpe; i++)
				for (int j = Wps; j <= Wpe; j++)
				for (int k = Cps; k <= Cpe; k++){
					int idx_s = (k - Cps) + (i - Hps)* (Wpe - Wps + 1)*(Cpe - Cps + 1) + (j - Wps)*(Cpe - Cps + 1);
					int idx_d = (k)+(i)* Wo*K + (j)*K;
					int p1 = *(PacketRecPar.data + idx_s);
					int SOP = *(databufferO + idx_d) + p1;
					*(databufferO + idx_d) = ((Activation == false) || (SOP>0)) ? SOP : 0;
				}
				*/
				DonePartialTransfer = true;
				for (int i = 0; i < PartialConfigSize; i++) DonePartialTransfer = DonePartialTransfer & partialConfig[i].done;
			}
			for (int i = 0; i < PartialConfigSize; i++) partialConfig[i].done = false;
			DonePartialTransfer = false;
			record << "OFMCONTROLLER GOT_ALL_POFM @ " << sc_time_stamp() << endl;
		}

		GetI.notify();
		if (PoolSize>1){
			/*F
			int index = 0;
			for (int x = 0; x < H; x = x + PoolSize)
			for (int y = 0; y < W; y = y + PoolSize)
			for (int z = 0; z < K; z++)
			{
				int x = -100000;
				for (int l = 0; l < PoolSize; l++)
				for (int m = 0; m < PoolSize; m++){
					int newValue = *(databufferO + ((z)+(x + l)* W*C + (y + m)*C));
					x = (x>newValue) ? x : newValue;
				}
				*(databufferO + index) = x;
				index++;
			}
			*/
		}
		if (OutputConfigSize>0){
			if (PoolSize){
				Wo = Wo / PoolSize;
			}
			if (NFC){
				Wo = 1;
				Co = 1;
			}
			for (int i = 0; i < OutputConfigSize; i++){
				int H1 = outputConfig[i].H1;
				int W1 = outputConfig[i].W1;
				int C1 = outputConfig[i].C1;
				int H2 = outputConfig[i].H2;
				int W2 = outputConfig[i].W2;
				int C2 = outputConfig[i].C2;

				int *OFMpartial = new int[15 * (H2 - H1 + 1)*(W2 - W1 + 1)*(C2 - C1 + 1)];
				int idx = 0;
				/*F
				for (int x = H1; x <= H2; x++)
				for (int y = W1; y <= W2; y++)
				for (int z = C1; z <= C2; z++)
				{
					int TAddindx = (z)+(x)* Wo*Co + (y)*Co;
					int temp = *(databufferO + TAddindx);
					*(OFMpartial + idx) = temp;
					idx++;
				}
				*/
				PacketSendOut.H = H2 - H1 + 1;
				PacketSendOut.W = W2 - W1 + 1;
				PacketSendOut.C = C2 - C1 + 1;
				PacketSendOut.data = OFMpartial;
				PacketSendOut.sourceNum = TileID;
				PacketSendOut.DestNum = outputConfig[i].ListTile;
				PacketSendOut.DestNum.appeand(-1);
				cout << "--------------" << name() << " waits sending next POFM  at time : " << sc_time_stamp() << endl;
				InitPort->burstWrite(PacketSendOut);
				cout << "--------------" << name() << " sent next OFM  at time : " << sc_time_stamp() << endl;
			}
			record << "OFMCONTROLLER SENT_ALL_OFM @ " << sc_time_stamp() << endl;
		}

	}
}
