#include "Channel.h"
#include <iostream>
#include <fstream>
using namespace std;
/*

Up_Interface(Partial Sum)
|
\|/
_________________________
|						|
|						|
|						|
Left_Interface ___\ |	\  / |\  /| |\  /|	|___\ Right_Tnterface
(Input Vector)	  / |	 \/  | \/ | | \/ |	|	/ (move Input Vector)
|						|
|						|
|_______________________|
|
\|/
Down_Interface (Partial Sum)

-VMM is for Vector Matrix multiplication unit which peforms multiplication of input vector and weight matrix
-VMM includes memristor crossbar and peripheral components to do analog matrix multiplication
[IVS*1]	*	[IVS*OVS]t	=	[OVS]
-IVS is Input Vector Size multiplied by weight matrix which is equivalent ti Rows of memristor array
-OVS is Output Vector Size resulted for multiplication which is equal to: array (cols/weight width* bits_per_cell)
-Dclk is equivaent to time period of Digital clock
-Other parameters of peripheral components ADC, DAC, and crossbar must be included

-VMM  has five steps:			 1-receiving input vector from left
2-Move input vector to right
3-Performing analog multiplication
4-get partial sum and collect with it own partial sum
5-send partial sum to down inteface


-Three pipelined threads (contrllers) are for steps 1-2, 3, and 4-5 which are notified by events among them

InputTransferController					Computation		OutputTransferController

Receive Input  from Left	--->||								||							||
||	start Analog Computation	||							||
||----------------------------->||							||
||	Apply Input to Crossbar		||							||
||<-----------------------------||							||
Send Input to Right			<---||								|| result is ready			||
||								||------------------------->||
||								||							||<--Get partil from up
||								||							||	 and do computation on the move
||								||	Done send output		||-->give partial to down
||								||<-------------------------||
||								||							||


-In the constructor of VMM: 1-Interface flags indicating used interfaces must be set
2-Weight matrix must be given
3-Name of module

*/
template <int IVS, int OVS, int Dclk>
SC_MODULE(VMM) {

	ofstream record;
	string filename;

	//Flags related to VMM interfaces
	bool LIF, RIF, UIF, DIF, COMP;

	//Declare ports of VMM
	sc_port<burst_write_if> outR;
	sc_port<burst_write_if> outD;
	sc_port<burst_read_if> inL;
	sc_port<burst_read_if> inU;

	//Declare arrays for input, output, and weight matrix	
	int *databufferI;
	int* databufferO;
	int *tempOB;
	int *memristors;

	//Declare events and flags for issue signals between threads
	sc_event ACput, ACget;
	bool ACflag;
	sc_event dataready;
	sc_event sendOFM1, applied;


	/*
	-all VMMs of cluster can be whether used or not based on size of matrix multiplication
	-Some configuration of VMM should be passed to constructor
	-li(left interface) and comp(computation) flags are set to true when VMM is matrix multplier for receiving input vector and analog computation respectively
	-ui(up interface) flag is set to true when VMM is a midstream or downstream of partial sum and set to false if it is an upstream
	-di(down interface) is set to true when VMM is a midstream or upstrean in cluster
	-ri(right interface) is set to true when VMM should move data to the right
	-module name should be passed to the constructor
	-pointer of values of memristor array
	*/
	VMM(sc_module_name name, bool li, bool ri, bool ui, bool di, bool comp, int* memvalue) : sc_module(name)
	{
		string direct = "VMM\\";
		string parent = get_parent()->basename();
		string modulename = name;
		string namemodule = parent + modulename;
		filename = direct + namemodule + ".rec";// +name() + ".rec";
		//*V/record.open(filename);

		LIF = li;
		RIF = ri;
		UIF = ui;
		DIF = di;
		COMP = comp;
		/*F
		for (int i = 0; i < IVS; i++)
		for (int j = 0; j < OVS; j++){
			memristors[i][j] = memvalue[i][j];
		}
		*/
		SC_THREAD(IFMcntrlr);
		SC_THREAD(OFMcntrlr);
		SC_THREAD(compute);
		//set_stack_size(2097152);
	}
	SC_HAS_PROCESS(VMM);
	void IFMcntrlr();
	void OFMcntrlr();
	void compute();
};


//-Input controller thread is just responsible for handling input data and provide suitable handshaking
template <int IVS, int OVS, int Dclk>
void VMM<IVS, OVS, Dclk>::IFMcntrlr()
{

	//-When VMM is utilized as matrix multplier, LIF or COMP is true (RIF is redundant but does not have any effect)
	int round = 0;
	while (LIF || COMP || RIF){
		DataVol InputPacket;
		InputPacket.H = IVS; InputPacket.W = 1; InputPacket.C = 1;
		int *bufD = NULL;

		//-If left interface is true, receives Input vector from input left (InL) port of channel
		if (LIF){
			//*V/record << "IFMCONTROLLER READY_GET_IFM @ " << sc_time_stamp() << " Round " << round << endl;
			//*Ccout << ">>>>>>" << name() << "waits IFM from left at time : " << sc_time_stamp() << " for round : " << round << endl;
			InputPacket = inL->burstRead();
			//*Ccout << ">>>>>>" << name() << "got IFM from left at time : " << sc_time_stamp() << " for round : " << round << endl;
			//*V/record << "IFMCONTROLLER GOT_IFM @ " << sc_time_stamp() << " Round " << round << endl;
			bufD = InputPacket.data;
			//wait(2, SC_NS);
			//*Ccout << name() << "read from Left at time" << sc_time_stamp() << endl;


		}
		//-If ri is true, this thread moves data to the right VMM through output right port (OutR)
		if (RIF){
			//*V/record << "IFMCONTROLLER READY_SEND_IFM @ " << sc_time_stamp() << " Round " << round << endl;
			//*Ccout << ">>>>>>" << name() << "waits giving IFM to right at time : " << sc_time_stamp() << " for round : " << round << endl;
			InputPacket.data = bufD;
			outR->burstWrite(InputPacket);
			//*Ccout << ">>>>>>" << name() << " Gave IFM to right at time : " << sc_time_stamp() << " for round : " << round << endl;
			//*V/record << "IFMCONTROLLER SENT_IFM @ " << sc_time_stamp() << " Round " << round << endl;
		}
		//-If computation flag is true, this thread triggers computation thread to start multiplication and waits until input vector is applied to crossbar
		if (COMP){
			if (ACflag == true) wait(ACget);
			ACflag = true;
			bufD = InputPacket.data;
			//*Ffor (int i = 0; i < IVS; i++) databufferI[i] = *(bufD + i);
			wait(2, SC_NS);
			ACput.notify();

			wait(applied);
		}


		round++;
	}
}

//Output controller thread is just responsible for handling output data.
//it would be triggered by computation thread if output is calculated
template <int IVS, int OVS, int Dclk>
void VMM<IVS, OVS, Dclk>::OFMcntrlr()
{

	int round = 0;
	while (COMP || UIF || DIF){

		DataVol OutputPacket;
		OutputPacket.H = OVS; OutputPacket.W = 1; OutputPacket.C = 1;
		int *bufD;

		// waits output vector is available by commputation thread 
		if (COMP){
			//*V/record << "OFMCONTROLLER WAIT_DONE_COMP  @ " << sc_time_stamp() << " Round " << round << endl;
			wait(dataready);
			//*V/record << "OFMCONTROLLER DONE_COMP  @ " << sc_time_stamp() << " Round " << round << endl;
		}

		// If triggered, it receives upstream accumulated partial sum from up interface (InU) if its flag is set to true
		if (UIF){
			//*V/record << "OFMCONTROLLER WAIT_GET_POFM @ " << sc_time_stamp() << " Round " << round << endl;
			//*Ccout << ">>>>>>" << name() << " waits getting OFM from up at time : " << sc_time_stamp() << " for round : " << round << endl;
			OutputPacket = inU->burstRead();
			bufD = OutputPacket.data;
			//*Ccout << ">>>>>>" << name() << " got OFM from up at time : " << sc_time_stamp() << " for round : " << round << endl;
			//*V/record << "OFMCONTROLLER GOT_POFM @ " << sc_time_stamp() << " Round " << round << endl;

			/*F
			for (int i = 0; i < OVS; i++) {
				databufferO[i] += *(bufD + i);
			}
			*/
		}

		// VMM sends accumulated partial sum through Donw interface(DownO) to downstream VMM
		if (DIF){
			//*V/record << "OFMCONTROLLER WAIT_SEND_POFM @ " << sc_time_stamp() << " Round " << round << endl;
			//*Ccout << ">>>>>>" << name() << " waits giving OFM to down at time : " << sc_time_stamp() << " for round : " << round << endl;
			/*F
			for (int i = 0; i < OVS; i++) {
				tempOB[i] = databufferO[i];
			}
			*/
			OutputPacket.data = tempOB;
			outD->burstWrite(OutputPacket);
			//*Ccout << ">>>>>>" << name() << " gave OFM to down at time : " << sc_time_stamp() << " for round : " << round << endl;
			//*V/record << "OFMCONTROLLER SENT_POFM @ " << sc_time_stamp() << " Round " << round << endl;

			wait(1, SC_NS);
			sendOFM1.notify();
			wait(3, SC_NS);
		}
		round++;
	}
}

// Computation thread is to do multiplication of input vector and weight matrix
template <int IVS, int OVS, int Dclk>
void VMM<IVS, OVS, Dclk>::compute()
{
	int round = 0;
	while (COMP || DIF){
		if (COMP){

			// 1- if input vector is ready and provided by input thread 
			ACflag = false;
			ACget.notify();
			//*V/record << "COMPUTATION WAIT_START_COMP  @ " << sc_time_stamp() << " Round " << round << endl;
			if (ACflag == false) wait(ACput);

			// 2- wait for applying data to crossbar and notify input data controller thread


			//applied.notify();

			// 3- doing mtrix multplication 
			//*V/record << "COMPUTATION START_COMP  @ " << sc_time_stamp() << " Round " << round << endl;
			/*F
			for (int i = 0; i < OVS; i++){
				int tempMAC = 0;

				for (int j = 0; j < IVS; j++){
					tempMAC += databufferI[j] * memristors[j][i];
				}
				databufferO[i] = tempMAC;
			}
			*/
			//4-wait for doing computations
			wait(750, SC_NS);

			//*Ccout << name() << ":" << sc_time_stamp() << endl;
			//*V/record << "COMPUTATION DONE_COMP @ " << sc_time_stamp() << " Round " << round << endl;
			//*Ccout << name() << "Done Computation at time : " << sc_time_stamp() << " Round " << round << endl;
			//5- notify output controller thread
			dataready.notify();

			wait(1, SC_NS);
		}
		else{
			//*Ffor (int i = 0; i < OVS; i++)	databufferO[i] = 0;
		}
		if (DIF){
			wait(sendOFM1);
			applied.notify();
		}
		wait(1, SC_NS);
		round++;
	}
}