module Cluster_Array
#(parameter XB_size=128, DataWidth=16,WeightWidth=8,  BitsApplied=2,BitsPerCell=2,
  VDD=3, HighResistance=10**6,LowResistance=10**3, NumclockTimer = 10,
  mv=4, nv=4, mc = 4, nc=4, mca = 3, nca =3, H=5, W=32, C=6, CL=4, r=3, s=3, K = 30, KL=25,stride = 1,
  Tix=1, Tiy=1)
	(clk, rst, ReqLeft, AckLeft, ReqDown, AckDown, DataLeft, DataDown);

  
input clk, rst;
input  [(DataWidth-1):0] DataLeft    [0:mc-1];
output [(DataWidth-1):0] DataDown    [0:nc-1];

input  ReqLeft     [0:mc-1];
output AckLeft     [0:mc-1];
input  AckDown    [0:nc-1];
output ReqDown    [0:nc-1];

wire Req_right_left [0:mc-1][0:nc];
wire Req_up_down    [0:mc][0:nc-1];
wire Ack_right_left [0:mc-1][0:nc];
wire Ack_up_down    [0:mc][0:nc-1];

wire [(DataWidth-1):0] Data_right_left    [0:mc-1][0:nc];
wire [(DataWidth-1):0] Data_up_down       [0:mc][0:nc-1];


genvar i, j;
generate
for (i = 0; i< mc; i=i+1) begin: rowvmms
	for (j = 0; j< nc; j=j+1) begin	: colvmms
		if (j > (nca-1))  //1
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,1,i,j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		else if (i>(mca-1)) // 2
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, CL, r, s, K, stride, 0, 0, 1, 1, 1,1,i,j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		else if (i==(mca-1) && j == (nca-1))  //3
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, CL, r, s, KL, stride, 1, 0, 1, 1, 1, 1, i, j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		else if (i==(mca-1) && j < (nca-1)) //4 
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, CL, r, s, K, stride, 1, 1, 1, 1, 1, 1, i, j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		else if (i==0 && j < (nca-1))  //5
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, C, r, s, K, stride, 1, 1, 0, 1, 1, 1, i, j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		else if (i==0 && j == (nca-1))  //6
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, C, r, s, KL, stride, 1, 0, 0, 1, 1, 1, i, j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		else if (i<(mca-1) && j == (nca-1))  //7
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, C, r, s, KL, stride, 1, 0, 1, 1, 1, 1, i, j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		
		else //8
			Cluster #(XB_size, DataWidth,WeightWidth, BitsApplied,BitsPerCell, VDD, HighResistance,LowResistance,
			NumclockTimer, mv, nv, H, W, C, r, s, K, stride, 1, 1, 1, 1, 1, 1, i, j) ClusInst
			(clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
			Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
			Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		
	end
 end
endgenerate

generate
for (i = 0; i< mc; i=i+1) begin
	assign Data_right_left[i][0] =DataLeft[i];
	//Acking Acking_right (clk, Req_right_left[i][nc], Ack_right_left[i][nc]);
	assign Req_right_left[i][0] = ReqLeft[i];
	assign AckLeft[i]=Ack_right_left[i][0];
 end
endgenerate

generate
for (j = 0; j< nc; j=j+1) begin
  assign Data_up_down[0][j] = 0;
	assign DataDown[j] = Data_up_down[mc][j] ;
	//Requesting Requesting_up (clk, Req_up_down[0][j], Ack_up_down[0][j]);
	assign Ack_up_down[mc][j] = AckDown[j];
	assign ReqDown[j]         = Req_up_down[mc][j];
 end
endgenerate

endmodule