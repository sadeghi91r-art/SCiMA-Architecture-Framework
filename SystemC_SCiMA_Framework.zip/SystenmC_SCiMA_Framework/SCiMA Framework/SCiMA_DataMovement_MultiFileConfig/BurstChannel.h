#ifndef BCHANNEL
#define BCHANNEL

#include "BurstInterfaceClasses.h"
template<int WTRb, int RTRb>
class ChanelMD : public sc_channel, public Pburst_write_if, public Pburst_read_if {

public:
	bool full = false;
	PacketBurst saved, savedR;
	sc_event put_event, get_event;
	ChanelMD(sc_module_name NAME) : sc_channel(NAME){
	};
	SC_HAS_PROCESS(ChanelMD);
	void burstWrite(PacketBurst Data);
	PacketBurst burstRead();
};

template<int WTRb, int RTRb>
void ChanelMD<WTRb, RTRb>::burstWrite(PacketBurst Data) {
	//cout << "This is the channel writer " << endl;

	if (full == true) wait(get_event);
	//wait(20, SC_NS);

	saved = Data;
	full = true;
	put_event.notify();
	int vol = saved.H*saved.W*saved.C;
	double delay = (WTRb > RTRb) ? (vol)*WTRb : (vol)*RTRb;
	if (delay < 0 || delay>10000000){
		int me = 100;
	}
	wait(4 + delay, SC_NS);
}

template<int WTRb, int RTRb>
PacketBurst ChanelMD<WTRb, RTRb>::burstRead(){
	if (full == false) wait(put_event);
	savedR = saved;
	//wait(20, SC_NS);
	int vol = savedR.H*savedR.W*savedR.C;
	double delay = (WTRb > RTRb) ? (vol)*WTRb : (vol)*RTRb;
	if (delay < 0 || delay>10000000){
		int me = 100;
	}
	wait(4 + delay, SC_NS);

	//wait(delay, SC_NS);
	full = false;
	get_event.notify();
	//wait(200, SC_NS);
	return savedR;
}
#endif

