
module BufferIFM_VMM
  #(parameter Size =128, Width=16, parameter NumShift=2)
  (clk, rst, write, read, shift, FullEmpty, Din, Dout, Dsout);
  input clk, rst, write, read, shift;
  output FullEmpty;
  input  [(Width-1):0] Din;
  output [(Width-1):0] Dout;
  output  [(NumShift-1):0] Dsout [0:(Size-1)];

  logic [($clog2(Size)-1):0] count_reg;
  logic  [(Width-1):0] RegO [0:(Size-1)];

  always @(posedge clk) begin // writing and shifiting  
	if (write) begin
		RegO[count_reg] <= Din;
	end
	else if (shift) begin
		for (int i = 0; i<Size ; i++) begin
			RegO[i]<= {RegO[i][(NumShift-1):0], RegO[i][(Width-1): NumShift]};
		end
	end
  end
  
 
  
  assign Dout = (read) ? RegO [count_reg] : 0; // reading 
  
   always@(posedge clk) begin // Poninter
    if(rst) count_reg<=0;
    else if ((read||write)) count_reg <= count_reg + 1;
  end
  assign FullEmpty= & count_reg;


 genvar k; // connect Shift Ports
  generate
    for (k=0; k<Size; k=k+1) begin : ShiftPort
        assign Dsout[k] = RegO[k][(NumShift-1):0];
    end  
  endgenerate 
 /*
integer i;
  always @(negedge write) begin
	for (i = 0 ; i<128; i=i+1) begin
		$display("Address(%d)->Data(%d) at %t", i, Drego[i], $time );
	end 
  end
  */
  
endmodule


 module BufferIFM_Tester
  #(parameter Size =128, Width=16, parameter NumShift=2)();
  
  logic clk=0, rst, write, read, shift;
  wire FullEmpty;
  logic  [(Width-1):0] Din;
  wire [(Width-1):0] Dout;
  wire  [(NumShift-1):0] Dsout [(Size-1):0];
  
  BufferIFM_VMM #(Size, Width, NumShift) BufferIFMUT(clk, rst, write, read, shift, FullEmpty, Din, Dout, Dsout);
  
  always #17 clk=~clk;
  initial begin
    rst =1;
    #27;
    rst =0;
	read=0;
	shift=0;
    #27;
    write = 1;
    for (int i=0; i<Size-1; i=i+1) begin
      Din = i;
      #34;
    end
    #38;
    write = 0;
     #138;
    read = 1;
   for (int i=0; i<Size-1; i=i+1) begin
      #34;
    end
     read = 0;
     #138;
     shift  = 1;
   for (int i=0; i<8; i=i+1) begin
      #34;
    end 
    shift  = 0;
  end
  endmodule
  
  