module VMMTester


#(parameter XB_size=128, DataWidth=16,WeightWidth=8, SliceWidth=4,m=1,
  real DACmax=1, parameter ADCresolution=16, real Hcond=1, real Lcond=0, parameter convDelayClk = 200,
  LIF=1, RIF=1, UIF=1, DIF=1,  Tix=1, Tiy=1,Cix=1,Ciy=1,Vix=1, Viy=1)
();

parameter OVS=XB_size*m/WeightWidth;
parameter IVS=XB_size;
parameter CW=WeightWidth/m;

logic  [(DataWidth-1):0] IV [0:(IVS-1)];
logic  [(DataWidth-1):0] RIV [0:(IVS-1)];
logic  [(DataWidth-1):0] OV [0:(OVS-1)];
logic  [(DataWidth-1):0] POV [0:(OVS-1)];
logic  [(DataWidth-1):0] WOV [0:(OVS-1)];
logic  [(WeightWidth-1):0] WM [0:(IVS-1)][0:(OVS-1)];

 logic clk=0, rst=1;
 logic req_left, ack_right, req_up, ack_down;
 logic ack_left, req_right, ack_up, req_down;
  
  logic [(DataWidth-1):0] Din_left=1;
  logic [(DataWidth-1):0] Din_up=0;
  logic [(DataWidth-1):0] Dout_right; 
  logic [(DataWidth-1):0] Dout_down;
  
  logic [(2*DataWidth-1):0] Data=1;
  
  
  logic [(WeightWidth-1):0] Weight;
  logic [(m-1):0] Bits;

always #17 clk=~clk;

integer sum;
	real memvalue;
	real v1, v2;
	int i1, i2;
always begin
#44;
	req_left=0;
	req_up=0;
	
	for (int i=0; i<IVS; i=i+1) IV[i]=$urandom%500;
	for (int i=0; i<IVS; i=i+1) for (int j=0; j<OVS; j=j+1) WM[i][j]=$random%500;
	
	for (int i=0; i<IVS; i=i+1)
		for (int j=0; j<OVS; j=j+1) begin
			Weight=WM[i][j];
			for (int k=0; k<CW; k=k+1) begin
				i1=Weight[(WeightWidth-k*m-1)-:m];
				v1=$itor(i1)/$itor((2**m)-1);
				memvalue=v1*(Hcond-Lcond);
				i2=j*CW+k;
				VMM0.VMM_DatapathA0.MemArr.MemArray[i][i2]=memvalue;
			end
	end
	
	if (UIF==1) for (int j=0; j<OVS; j=j+1) POV[j]=$random%20;
	else for (int j=0; j<OVS; j=j+1) POV[j]=0;
	
	for (int j=0; j<OVS; j=j+1) WOV[j] = POV[j];
	for (int j=0; j<OVS; j=j+1) for(int i=0; i<IVS; i=i+1) WOV[j] = WOV[j] + (IV[i] * WM[i][j]);
	#44;
	rst=0;
	if (LIF==1) begin
		req_left=1;
		@(posedge ack_left);
		req_left=0;
		@(negedge ack_left);
		@(posedge clk);
		for (int i=0; i<IVS; i=i+1) begin
			Din_left=IV[i];
			@(posedge clk);
		end
	end
	if (RIF==1) begin
		ack_right=0;
		@(posedge req_right);
		ack_right=1;
		@(negedge req_right);
		ack_right=0;
		@(posedge clk);
		@(posedge clk);
		for (int i=0; i<IVS; i=i+1) begin
			RIV[i]=Dout_right;
			@(posedge clk);
		end
	end
	if (UIF==1) begin
		req_up=1;
		@(posedge ack_up);
		req_up=0;
		@(negedge ack_up);
		@(posedge clk);
		for (int j=0; j<OVS; j=j+1) begin
			Din_up=POV[j];
			@(posedge clk);
		end
	end
	if (DIF==1) begin
		ack_down=0;
		@(posedge req_down);
		ack_down=1;
		@(negedge req_down);
		ack_down=0;
		//@(posedge clk);
		@(posedge clk);
		for (int j=0; j<OVS; j=j+1) begin
			OV[j]=Dout_down;
			@(posedge clk);
		end
	end
	$stop();
end

  
VMM  #( XB_size, DataWidth, WeightWidth, SliceWidth, m, DACmax, ADCresolution, Hcond, Lcond, convDelayClk,
  LIF, RIF, UIF, DIF,  Tix, Tiy,Cix,Ciy,Vix, Viy) VMM0
  (clk, rst, req_left, ack_left, req_right, ack_right,
  req_up, ack_up, req_down, ack_down, Din_left, Din_up, Dout_right, Dout_down);

ReqAckRegister #("left", "VMM",1,2) Regleft (req_left, ack_left );
ReqAckRegister #("right", "VMM",1,2) Regright (req_right, ack_right );
ReqAckRegister #("up", "VMM",1,2) Regup (req_up, ack_up );
ReqAckRegister #("down", "VMM",1,2) Regdown (req_down, ack_down );



endmodule