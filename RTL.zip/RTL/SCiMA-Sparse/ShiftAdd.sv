module ShiftAdd
  #(parameter Width=32)
  (operand, ShiftNum, clk, rst, load, SAout);
  
  input [(Width-1):0] operand;
  input [($clog2(Width)-1):0] ShiftNum;
  input clk, rst, load;
  output [(Width-1):0] SAout;
  
  wire [(Width-1):0] shiftoperand;
  wire [(Width-1):0] sum;
  
  Register #(Width) RegSA(sum, clk, rst, load, SAout);
  assign sum = SAout + shiftoperand;
  
  barrel_shiftern #(Width) BS (shiftoperand, operand, ShiftNum);
  
endmodule

module ShftAd_test;
parameter Width=16;

logic [(Width-1):0] operand;
logic [($clog2(Width)-1):0] ShiftNum;
logic clk=0, rst, load;
wire[(2*Width-1):0] SAout;

ShiftAdd #(Width) SA_UT (operand, ShiftNum, clk, rst, load, SAout);



always #17 clk=~clk;
initial begin
  rst=1;
  load=0;
  #178;
  load=1;
  rst=0;
  operand = 4;
  ShiftNum = 1;
  #34;
  operand = 16;
  ShiftNum = 2;
  #34;
  operand = 0;
  ShiftNum = 0;
end 
endmodule

