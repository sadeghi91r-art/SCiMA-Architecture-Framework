module CounterMaxStep
  #(parameter Width =16, Max=128, step=1)
  (clk, rst, en, init, cnt, count, co);
  input clk, rst, en, init, cnt;
  output  [(Width-1):0] count;
  output co;
  
  logic [(Width-1):0]count_reg;
  always@(posedge clk) begin
    if(rst) count_reg<=0;
    else if (en) begin
		if (init) count_reg <= 0;
		else if(cnt) begin
			if(count_reg>=Max) count_reg <= 0;
			else count_reg <= count_reg+step;
		end
	end
  end
  assign count = count_reg;
  assign co= (count_reg >= Max);
endmodule