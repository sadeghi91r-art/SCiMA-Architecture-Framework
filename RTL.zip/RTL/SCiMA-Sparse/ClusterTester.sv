
module TestCluster 
#(parameter XB_size=128, DataWidth=16,WeightWidth=8,  SliceWidth=4,CellBits=1,
  real DACmax=1, parameter ADCresolution=16, real Hcond=1, real Lcond=0, parameter SRIF_ADC_delay=200,
  parameter mv = 4, nv=4, H=6, W=6, C=56, r=3, s=3, K = 64, stride = 1, LIF=1, RIF=0, UIF=0, DIF=1,
  Tix=1, Tiy=1,Cix=1,Ciy=1)();
  
  parameter Ho=(H - r +1);
  parameter Wo=(W - s +1);
  parameter OVS=XB_size*CellBits/WeightWidth;
  parameter IVS=XB_size;
  parameter CpX=XB_size/(r*s);
  parameter KpX=OVS;
  parameter CW=WeightWidth/CellBits;

logic  [(WeightWidth-1):0] WM [0:(IVS-1)][0:(OVS-1)];
logic  [(DataWidth-1):0] IFM [0:(H-1)][0:(W-1)][0:(C-1)];
logic  [(DataWidth-1):0] OFM [0:(Ho-1)][0:(Wo-1)][0:(K-1)];
logic  [(DataWidth-1):0] POFM [0:(Ho-1)][0:(Wo-1)][0:(K-1)];
logic  [(DataWidth-1):0] WOFM [0:(Ho-1)][0:(Wo-1)][0:(K-1)];
logic  [(WeightWidth-1):0] NNW [0:(K-1)][0:(r-1)][0:(s-1)][0:(C-1)];
logic [(WeightWidth-1):0] Weight;
logic [(WeightWidth-1):0] In;
  
  
  logic clk=0, rst=1;
  logic ReqLeft, AckRight;
  wire AckLeft, ReqRight;
  logic  ReqUp, AckDown;
  wire AckUp, ReqDown;
  logic  [(DataWidth-1):0]  Din_left=2, Din_up=3;
  wire [(DataWidth-1):0] Dout_right, Dout_down;
  always #5 clk=~clk;

  Cluster 
#(XB_size, DataWidth,WeightWidth,  SliceWidth,CellBits, DACmax, ADCresolution, Hcond,Lcond, SRIF_ADC_delay ,
  mv, nv, H, W, C, r, s, K, stride , LIF, RIF, UIF, DIF, Tix, Tiy,Cix,Ciy) ClusterInst
  (clk, rst, ReqLeft, AckLeft, ReqRight, AckRight, ReqUp, AckUp, ReqDown, AckDown, Din_left, Din_up, Dout_right, Dout_down);

int ri, si, ki, Ci, ti;
real memvalue;
real v1, v2;
int i1, i2;
genvar ii, jj;
initial begin


	//randomly generate weights
	for (int i=0; i<K; i=i+1) for (int j=0; j<r; j=j+1) for (int k=0; k<s; k=k+1) for (int l=0; l<C; l=l+1) NNW[i][j][k][l]=$random%100;
	//randomly generate inputs
	for (int i=0; i<H; i=i+1) for (int j=0; j<W; j=j+1) for (int k=0; k<C; k=k+1) IFM[i][j][k]=$urandom%100;
	//randomly generate inputs
	for (int i=0; i<Ho; i=i+1) for (int j=0; j<Wo; j=j+1) for (int k=0; k<K; k=k+1) POFM[i][j][k]=$random%100;
/*
  //partitioning and 				
	for (int i = 0; i< mv; i=i+1) begin
		for (int j = 0; j< nv; j=j+1) begin
			//Constitute Weight Matrix of Crossbars
			for (int k=0; k<IVS; k=k+1) begin
				for (int l=0; l<OVS; l=l+1) begin
					ri= (k/(s*CpX));
					ti=(k/CpX);
					si= (ti%s);
					Ci= (k%(CpX));
					if(((Ci+i*CpX)>(C-1)) || ((l+j*KpX)>(K-1)) ||(k>(r*s*CpX)) || (l>(KpX))) Weight=0;
					else begin
						Weight=NNW[l+j*KpX][ri][si][Ci+i*CpX];
					end
					WM[k][l]=Weight;
					// Writing into memristors
					for (int kk=0; kk<CW; kk=kk+1) begin
						i1=Weight[(WeightWidth-kk*CellBits-1)-:CellBits];
						v1=$itor(i1)/$itor((2**CellBits)-1);
						memvalue=v1*(Hcond-Lcond);
						i2=j*CW+kk;
						ClusterInst.ClusDP.VMMArray.rowvmms[i].colvmms[j].VMMInst.VMM_DatapathA0.MemArr.MemArray[k][i2]=memvalue;
					end
				end
			end
		end
	end
*/

	//Calculate Output feature map
	for (int x=0; x<Ho; x=x+stride) begin
		for (int y=0; y<Wo; y=y+stride) begin
			for (int k=0; k<K; k=k+1) begin
				WOFM[x][y][k]=0;
				for (int rii=0; rii<r; rii=rii+1) begin
					for (int sii=0; sii<r; sii=sii+1) begin
						for (int cii=0; cii<C; cii=cii+1) begin
							Weight=NNW[k][rii][sii][cii];
							In=IFM[x+rii][y+sii][cii];
							WOFM[x][y][k]=WOFM[x][y][k]+Weight*In;
	
						end
					end
				end
			end
		end
	end
	if (UIF) begin
		for (int i=0; i<Ho; i=i+1) for (int j=0; j<Wo; j=j+1) for (int kk=0; kk<K; kk=kk+1) WOFM[i][j][kk]=WOFM[i][j][kk]+POFM[i][j][kk];
	end
					
end


//partitioning and
generate 				
	for (genvar i = 0; i< mv; i=i+1) begin
		for (genvar j = 0; j< nv; j=j+1) begin
			initial begin
			@(posedge clk);
			@(posedge clk);
			//Constitute Weight Matrix of Crossbars
			for (int k=0; k<IVS; k=k+1) begin
				for (int l=0; l<OVS; l=l+1) begin
					si= (k/(s*CpX));
					ti=(k/CpX);
					ri= (ti%r);
					Ci= (k%(CpX));
					if(((Ci+i*CpX)>(C-1)) || ((l+j*KpX)>(K-1)) ||(k>(r*s*CpX)) || (l>(KpX))) Weight=0;
					else begin
						Weight=NNW[l+j*KpX][ri][si][Ci+i*CpX];
					end
					WM[k][l]=Weight;
					// Writing into memristors
					for (int kk=0; kk<CW; kk=kk+1) begin
						i1=Weight[(WeightWidth-kk*CellBits-1)-:CellBits];
						v1=$itor(i1)/$itor((2**CellBits)-1);
						memvalue=v1*(Hcond-Lcond);
						i2=l*CW+kk;
						ClusterInst.ClusDP.VMMArray.rowvmms[i].colvmms[j].VMMInst.VMM_DatapathA0.MemArr.MemArray[k][i2]=memvalue;
					end
				end
			end
			end
		end
	end
endgenerate

always begin
#45;
	ReqLeft=0;
	ReqUp=0;
	#55;
	rst=0;
	if (LIF==1) begin
		ReqLeft=1;
		@(posedge AckLeft);
		ReqLeft=0;
		@(negedge AckLeft);
		@(posedge clk);
		for (int i=0; i<H; i=i+1) for (int j=0; j<W; j=j+1) for (int k=0; k<C; k=k+1) begin
			Din_left=IFM[i][j][k];
			@(posedge clk);
		end
	end
	if (UIF==1) begin
		ReqUp=1;
		@(posedge AckUp);
		ReqUp=0;
		@(negedge AckUp);
		@(posedge clk);
		for (int i=0; i<Ho; i=i+1) for (int j=0; j<Wo; j=j+1) for (int k=0; k<K; k=k+1) begin
			Din_up=POFM[i][j][k];
			@(posedge clk);
		end
	end
	if (DIF==1) begin
		AckDown=0;
		@(posedge ReqDown);
		AckDown=1;
		@(negedge ReqDown);
		AckDown=0;
		@(posedge clk);
		@(posedge clk);
		for (int i=0; i<Ho; i=i+1) for (int j=0; j<Wo; j=j+1) for (int k=0; k<K; k=k+1) begin
			OFM[i][j][k]=Dout_down;
			@(posedge clk);
		end
	end
	$stop();
end

genvar i, j;	
generate
for (i = 0; i< mv; i=i+1) begin
	for (j = 0; j< nv; j=j+1) begin
		//ReqAckRegister #("left_right", "VMM", i+1, j+1) recorderLR (ClusterInst.ClusDP.VMMArray.Req_right_left[i][j], ClusterInst.ClusDP.VMMArray.Ack_right_left[i][j] );
		//ReqAckRegister #("up_down", "VMM", i+1, j+1) recorderUD (ClusterInst.ClusDP.VMMArray.Req_up_down[i][j], ClusterInst.ClusDP.VMMArray.Ack_up_down[i][j] );
		Recorder #("VMM", i, j) Monitor (
		ClusterInst.ClusDP.VMMArray.Req_right_left[i][j],
		ClusterInst.ClusDP.VMMArray.Ack_right_left[i][j],
		ClusterInst.ClusDP.VMMArray.Req_right_left[i][j+1],
		ClusterInst.ClusDP.VMMArray.Ack_right_left[i][j+1],
		ClusterInst.ClusDP.VMMArray.Req_up_down[i][j],
		ClusterInst.ClusDP.VMMArray.Ack_up_down[i][j],
		ClusterInst.ClusDP.VMMArray.Req_up_down[i+1][j],
		ClusterInst.ClusDP.VMMArray.Ack_up_down[i+1][j]);
	end
end
endgenerate	 
 
ReqAckRegister #("Left", "Cluster", 0, 0)  recorderL (ReqLeft, AckLeft);
ReqAckRegister #("Up", "Cluster", 0, 0)    recorderU (ReqUp, AckUp );
ReqAckRegister #("Right", "Cluster", 0, 0) recorderR (ReqRight, AckRight);
ReqAckRegister #("Down", "Cluster", 0, 0) recorderD (ReqDown, AckDown);



  

/*
generate
  for (genvar i=0; i<mv; i=i+1) begin  
      for (genvar j=0; j<nv; j=j+1) begin
        for (genvar k=0; k<XB_size; k=k+1) begin
        always @(*) begin
          if (ClusterInst.ClusDP.VMMArray.rowvmms[i].colvmms[j].VMMInst.VMM_IntController0.ps==4) begin
          $display("IFM of VMM (%d, %d) --> %d = %d", i, j, k,
	           ClusterInst.ClusDP.VMMArray.rowvmms[i].colvmms[j]
	           .VMMInst.VMM_DatapathA0.BufferIFM.genShiftreg[k].ShiftRegN
	           .Dreg);
	         end
	         end
	    end 
  end
  end
endgenerate

generate
  for (genvar i=0; i<mv; i=i+1) begin  
      for (genvar j=0; j<nv; j=j+1) begin
        for (genvar k=0; k<32; k=k+1) begin
        always @(*) begin
          if (ClusterInst.ClusDP.VMMArray.rowvmms[i].colvmms[j].VMMInst.VMM_CompControl0.ps==9) begin
          $display("OFM of VMM (%d, %d) <-- %d = %d", i, j, k, 
	           ClusterInst.ClusDP.VMMArray.rowvmms[i].colvmms[j]
	           .VMMInst.VMM_DatapathA0.BufferOFM.regarray[k].Reg.Dout);
	         end
	         end
	    end 
  end
  end
endgenerate
*/

  endmodule 
  