#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
using namespace std;
/*
struct HardwareParameters{
	int NOCDTR;
	int TmemSize;
	int TileDTR;
	int mc;
	int nc;
	int ClusMSize;
	int ClusDTR;
	int mv;
	int nv;
	int VIVS;
	int VOVS;
	int VmmDTR;
	int Dclk;
	int Trow;
	int Tcol;
};
*/
struct TileConfig{
	string name;
	int C=1;
	int r=1;
	int s=1;
	int K=0;
	int Strd=1;
	bool COMP=0;
	bool Activation=0;
	int PoolSize=1;
	bool NFC=0;
	int Hd=0;
	int Wd=0;
	int *TileWeight;
	bool PartialSum=0;
	int TileID=0;
	TransferConfig *inputConfig;
	TransferConfig *outputConfig;
	TransferConfig *partialConfig;
	int InputConfigSize=0;
	int OutputConfigSize=0;
	int PartialConfigSize=0;
};
/*
 HardwareParameters ReadHWparameters(string parameterFile){
	HardwareParameters HW_P;
	ifstream fileHP(parameterFile);
	string line;
	string value;
	getline(fileHP, line);
	getline(fileHP, line);
	istringstream iss(line);
	getline(iss, value, '	');
	HW_P.NOCDTR = stoi(value);
	getline(iss, value, '	');
	HW_P.TmemSize = stoi(value);
	getline(iss, value, '	');
	HW_P.TileDTR = stoi(value);
	getline(iss, value, '	');
	HW_P.mc = stoi(value);
	getline(iss, value, '	');
	HW_P.nc = stoi(value);
	getline(iss, value, '	');
	HW_P.ClusMSize = stoi(value);
	getline(iss, value, '	');
	HW_P.ClusDTR = stoi(value);
	getline(iss, value, '	');
	HW_P.mv = stoi(value);
	getline(iss, value, '	');
	HW_P.nv = stoi(value);
	getline(iss, value, '	');
	HW_P.VIVS = stoi(value);
	getline(iss, value, '	');
	HW_P.VOVS = stoi(value);
	getline(iss, value, '	');
	HW_P.VmmDTR = stoi(value);
	getline(iss, value, '	');
	HW_P.Dclk = stoi(value);
	getline(iss, value, '	');
	HW_P.Trow = stoi(value);
	getline(iss, value, '	');
	HW_P.Tcol = stoi(value);
	return HW_P;
};
*/
 TileConfig ReadConfigs(int TileID, string APPname){
	 string Fname = APPname + "\\Config.txt";
	 ifstream ConfigFile(Fname);
	 
	TileConfig config;
	string line;
	string value;
	bool det = false;
	while (getline(ConfigFile, line) && det==false){
		istringstream iss(line);
		getline(iss, value, '	');
		if (value == "TT"){
			getline(iss, value, '	');
			if (TileID == stoi(value)) det = true;
		}
	}
		if (det==true){
		getline(ConfigFile, line);
		//getline(ConfigFile, line);
		//getline(ConfigFile, line);
		istringstream iss(line);
		getline(iss, value, '	');
		config.name = value;
		getline(iss, value, '	');
		config.C = stoi(value);
		getline(iss, value, '	');
		config.r = stoi(value);
		getline(iss, value, '	');
		config.s = stoi(value);
		getline(iss, value, '	');
		config.K = stoi(value);
		getline(iss, value, '	');
		config.Strd = stoi(value);
		getline(iss, value, '	');
		config.COMP = stoi(value);
		getline(iss, value, '	');
		config.Activation = stoi(value);
		getline(iss, value, '	');
		config.PoolSize = stoi(value);
		getline(iss, value, '	');
		config.NFC = stoi(value);
		getline(iss, value, '	');
		config.Hd = stoi(value);
		getline(iss, value, '	');
		config.Wd = stoi(value);
		getline(iss, value, '	');
		config.PartialSum = stoi(value);
		getline(iss, value, '	');
		config.TileID = stoi(value);
		getline(iss, value, '	');
		config.InputConfigSize = stoi(value);
		getline(iss, value, '	');
		config.OutputConfigSize = stoi(value);
		getline(iss, value, '	');
		config.PartialConfigSize = stoi(value);
		getline(ConfigFile, line);

		TransferConfig *InputConfig = new TransferConfig[config.InputConfigSize];
		TransferConfig *OutputConfig = new TransferConfig[config.OutputConfigSize];
		TransferConfig *PartialConfig = new TransferConfig[1];

		getline(ConfigFile, line);
		for (int i = 0; i < config.InputConfigSize; i++){
			getline(ConfigFile, line);
			istringstream iss(line);
			getline(iss, value, '\t');
			InputConfig[i].H1 = stoi(value);
			getline(iss, value, '	');
			InputConfig[i].W1 = stoi(value);
			getline(iss, value, '	');
			InputConfig[i].C1 = stoi(value);
			getline(iss, value, '	');
			InputConfig[i].H2 = stoi(value);
			getline(iss, value, '	');
			InputConfig[i].W2 = stoi(value);
			getline(iss, value, '	');
			InputConfig[i].C2 = stoi(value);
			while (getline(iss, value, '	'))
				InputConfig[i].ListTile.appeand(stoi(value));
		}
		config.inputConfig = InputConfig;

		getline(ConfigFile, line);
		for (int i = 0; i < config.OutputConfigSize; i++){
			getline(ConfigFile, line);
			istringstream iss(line);
			getline(iss, value, '	');
			OutputConfig[i].H1 = stoi(value);
			getline(iss, value, '	');
			OutputConfig[i].W1 = stoi(value);
			getline(iss, value, '	');
			OutputConfig[i].C1 = stoi(value);
			getline(iss, value, '	');
			OutputConfig[i].H2 = stoi(value);
			getline(iss, value, '	');
			OutputConfig[i].W2 = stoi(value);
			getline(iss, value, '	');
			OutputConfig[i].C2 = stoi(value);
			while (getline(iss, value, '	'))
				OutputConfig[i].ListTile.appeand(stoi(value));
		}
		config.outputConfig = OutputConfig;

		getline(ConfigFile, line);
		for (int i = 0; i < config.PartialConfigSize; i++){
			getline(ConfigFile, line);
			istringstream iss(line);
			getline(iss, value, '	');
			PartialConfig[i].H1 = stoi(value);
			getline(iss, value, '	');
			PartialConfig[i].W1 = stoi(value);
			getline(iss, value, '	');
			PartialConfig[i].C1 = stoi(value);
			getline(iss, value, '	');
			PartialConfig[i].H2 = stoi(value);
			getline(iss, value, '	');
			PartialConfig[i].W2 = stoi(value);
			getline(iss, value, '	');
			PartialConfig[i].C2 = stoi(value);
			while (getline(iss, value, '	'))
				PartialConfig[i].ListTile.appeand(stoi(value));
		}
		config.partialConfig = PartialConfig;
		int* weigthts = new int[1];
		/*
		getline(ConfigFile, line);
		getline(ConfigFile, line);
		
		for (int i = 0; i < (config.r*config.s*config.C*config.K); i++){
			getline(ConfigFile, line);
			*(weigthts + i) = stoi(line);
			//*(weigthts + i) = 0;
		}
		*/
		config.TileWeight = weigthts;
	}
	else{
		int* weigthts1=new int[1];
		config.name = "Tile_" + to_string(TileID);
		config.TileID =TileID;
		config.TileWeight = weigthts1;
	}
	ConfigFile.close();
	return config;
};