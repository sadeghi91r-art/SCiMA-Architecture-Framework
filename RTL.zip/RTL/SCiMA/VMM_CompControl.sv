
module VMM_CompControl
  #(parameter XB_size=128, DataWidth=16, WeightWidth=8,  SliceWidth=2, BitsPerCell=2, convDelayClk = 10)
  (clk, rst, start, dataready, shiftIFM, writeOFM, DoneSendOFM, index, slice);
  
  parameter WidthTimer = $clog2(convDelayClk)+1;
  parameter OutVectSize=XB_size*BitsPerCell/WeightWidth;
  parameter NumSlices=DataWidth/SliceWidth;

  
  input clk, rst, start, DoneSendOFM;
  output dataready, shiftIFM, writeOFM;
  output [($clog2(OutVectSize)-1) : 0] index;
  output [($clog2(NumSlices)-1) : 0] slice;
  logic [3:0] ns, ps;
  logic rstSC, enSC, coSC;
  logic rstADC_Timer, enADC_Timer, XBTO;
  logic rstIC, enIC, coIC;

  
parameter Idle=0, Start=1, CheckLastSlice=2, DotProduct=3, Store=4, CheckSent=5;    
    always@(*) begin
      ns=Idle;
      case(ps)
        Idle: begin
          if(start==1'b1) ns=Start;
          else ns=Idle;
        end
        Start: begin
          if(start==1'b0) ns=DotProduct;
          else ns=Start;
        end
        
        DotProduct: begin
          if(XBTO) ns= Store;
          else
          ns= DotProduct;
        end
		Store: begin
          if(coIC) ns = CheckLastSlice;
          else ns = Store;
        end
 
        CheckLastSlice: begin
          if(coSC) ns = CheckSent;
          else ns=DotProduct;
        end
       
		CheckSent: begin
          if(DoneSendOFM) ns = Idle;
          else ns = CheckSent;
        end
        default : begin
          ns = Idle;
        end
      endcase
    end
    
    always@(posedge clk) begin
      if (rst) ps<=Idle;
      else ps<=ns;
    end
  
  assign dataready = (ps ==CheckSent);
  assign shiftIFM = (ps ==CheckLastSlice);
  assign writeOFM = (ps ==Store);


  assign enSC = (ps == CheckLastSlice);
  assign rstSC = (ps == Start);
  assign enIC = (ps == Store);
  assign rstIC = (ps == Start);
  assign rstADC_Timer = (ps==CheckLastSlice);
  assign enADC_Timer = (ps==DotProduct);
  
   
   Counter #($clog2(NumSlices)) SliceCounter (clk, rstSC, enSC, slice, coSC);
   Counter #($clog2(OutVectSize)) IndexCounter (clk, rstIC, enIC, index, coIC);
   
   Timer #(WidthTimer, convDelayClk) XBTimer  (clk, rstADC_Timer, enADC_Timer, XBTO);

endmodule
  