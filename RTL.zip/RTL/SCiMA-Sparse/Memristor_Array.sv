
module Memristor_Array
  #( parameter size = 128, Tix=1, Tiy=1,Cix=1,Ciy=1,Vix=1, Viy=1, LIF=1)
  (Vin, Iout);

input  real Vin [0:(size-1)];
output real Iout [0:(size-1)];
 
real MemArray [0:(size-1)][0:(size-1)];

real Ioutreg [0:(size-1)];

genvar k;
integer i, j, m, n;
logic w;
string my_file;

initial begin

int f_binw, status;
	$sformat(my_file, "C:/Users/rezga/Dropbox/IMC/Matlab/New folder/weights/MemRistor_%0d_%0d_%0d_%0d_%0d_%0d.txt", Tix, Tiy,Cix,Ciy,Vix, Viy);
	
	
	
	for (i=0; i<size; i=i+1) begin
		for (j=0; j<size; j=j+1) begin
			MemArray[i][j] = 0;
		end
	end
	/*
	if (LIF==1) begin
		f_binw = $fopen(my_file,"rb");
		for (i=0; i<size; i=i+1) begin
			for (j=0; j<size; j=j+1) begin
				status = $fscanf(f_binw, " %b", w);
				if(w==1) MemArray[i][j] = 0.001;
				else MemArray[i][j] = 0;
			end
		end
	end
	*/
  
end
always@(*) begin
  
  for (i=0; i<size; i=i+1) begin
    Ioutreg[i] = 0;
  end
  
  for (i=0; i<size; i=i+1) begin
    for (j=0; j<size; j=j+1) begin
      Ioutreg[j] = Ioutreg[j] + (Vin[i] * MemArray[i][j]);
    end
  end 
end

generate
  for (k=0; k<size; k=k+1) begin
      assign Iout[k] = Ioutreg[k];
  end  
endgenerate
  
endmodule
`timescale 1ns/1ps
module Tester_MA
#( parameter size = 128)
();

  real Vin [0:(size-1)];
 real Iout [0:(size-1)];  
  
Memristor_Array #(size) MA (Vin, Iout);

integer i;
initial begin

for (i =0; i<size; i=i+1) begin
    Vin[i] =0;
  end
  #15;
  
  for (i =0; i<size; i=i+1) begin
    Vin[i] =1;
  end
  
  #15;
  
  for (i =0; i<size; i=i+1) begin
    Vin[i] =2;
  end
  
  #15;
  
  for (i =0; i<size; i=i+1) begin
    Vin[i] =3;
  end
end

endmodule

