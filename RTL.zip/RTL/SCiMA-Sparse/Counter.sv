module Counter
  #(parameter Width =16)
  (clk, rst, en, count, co);
  input clk, rst, en;
  output  [(Width-1):0] count;
  output co;
  
  logic [(Width-1):0]count_reg;
  always@(posedge clk) begin
    if(rst) count_reg<=0;
    else if (en) count_reg <= count_reg+1;
  end
  assign count = count_reg;
  assign co= &count_reg;
endmodule