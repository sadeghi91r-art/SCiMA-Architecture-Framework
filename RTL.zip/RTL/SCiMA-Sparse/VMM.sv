module VMM 
#(parameter XB_size=128, DataWidth=16,WeightWidth=8, SliceWidth=2,CellBits=2,
  real DACmax=1, parameter ADCresolution=11, real Hcond=10**-9, real Lcond=0, parameter SRIF_ADC_delay = 10,
  integer PSI=64, integer PSO=8, logic [9:0] PrunedRows [0:PSI-1], logic [9:0] PrunedColumns [0:PSO-1],
  LIF=1, RIF=1, UIF=1, DIF=1,  Tix=1, Tiy=1,Cix=1,Ciy=1,Vix=1, Viy=1)
  (clk, rst,
  req_left, ack_left, req_right, ack_right,
  req_up, ack_up, req_down, ack_down,
  Din_left, Din_up, Dout_right, Dout_down);

  parameter NumSlices=DataWidth/SliceWidth;
  parameter OVsize=(XB_size*CellBits/WeightWidth);
  
  input clk, rst, req_left, ack_right, req_up, ack_down;
  output ack_left, req_right, ack_up, req_down;
  
  input [(DataWidth-1):0] Din_left;
  input [(DataWidth-1):0] Din_up;
  output [(DataWidth-1):0] Dout_right; 
  output [(DataWidth-1):0] Dout_down;
  
  logic dataready, writeOFM, readOFM, DoneSendOFM, FullEmptyOFM, start, writeIFM, readIFM, FullEmptyIFM,shiftIFM;
  logic writeOFM1, writeOFM2;
  logic [($clog2(OVsize)-1) : 0] index;
  logic [($clog2(NumSlices)-1) : 0] slice;
  
  logic zeroingBPRD, writeBPRD, readBPRD, FullEmptyBPRD, selectPrunedRow;
  logic zeroingBPCD, writeBPCD, readBPCD, FullEmptyBPCD, selectPrunedColumn;
  
  
  assign writeOFM = writeOFM1 | writeOFM2;

  
  
  VMM_ContOutput  #(LIF, UIF, DIF, OVsize, PSO, PrunedColumns) VMM_CO
  (clk, rst, dataready, writeOFM1, readOFM, DoneSendOFM, FullEmptyOFM,
  zeroingBPCD, writeBPCD, readBPCD, FullEmptyBPCD, selectPrunedColumn,
  req_up, ack_up, req_down, ack_down);
  
  VMM_ContInput #(XB_size, LIF, RIF, PSI, PrunedRows) VMM_CI
  (clk, rst, start, writeIFM, readIFM, FullEmptyIFM, DoneSendOFM,
  zeroingBPRD, writeBPRD, readBPRD, FullEmptyBPRD, selectPrunedRow,
  req_left, ack_left, req_right, ack_right);
  
  VMM_CompControl #(XB_size, DataWidth,WeightWidth, SliceWidth, CellBits, SRIF_ADC_delay) VMM_CC
  (clk, rst, start, dataready, shiftIFM, writeOFM2, DoneSendOFM, index, slice);


  VMM_Datapath
  #(XB_size, DataWidth,WeightWidth, SliceWidth, CellBits, ADCresolution, DACmax, Hcond, Lcond, Tix, Tiy,Cix,Ciy,Vix, Viy, LIF, PSI, PSO) VMM_DP 
  ( clk, rst, writeIFM, readIFM, shiftIFM, writeOFM, readOFM, index, slice,
  FullEmptyIFM, FullEmptyOFM,
  zeroingBPRD, writeBPRD, readBPRD, FullEmptyBPRD,
  zeroingBPCD, writeBPCD, readBPCD, FullEmptyBPCD,
  selectPrunedRow, selectPrunedColumn,
  Din_left, Din_up, Dout_right, Dout_down);
  
  endmodule