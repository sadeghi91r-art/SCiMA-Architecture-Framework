
#include"BurstRouter.h"


void Router::Arbitter(){
	port1 = 0; port2 = 0; port3 = 0; port4 = 0; portW = 0; portN = 0; portE = 0; portS = 0;
	while (1){
		wait(1, SC_NS);
		grantW = sc_logic(0); grantN = sc_logic(0); grantE = sc_logic(0); grantS = sc_logic(0);
		grant1 = sc_logic(0); grant2 = sc_logic(0); grant3 = sc_logic(0); grant4 = sc_logic(0);



		if (req1 == true){
			int NodeDestRow = Packet1_DestNum / dimRowNodes;
			int NodeDestCol = Packet1_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grant1 = sc_logic(1);  port1 = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grant1 = sc_logic(1);  port1 = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grant1 = sc_logic(1);  port1 = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grant1 = sc_logic(1);  port1 = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grant1 = sc_logic(1);  port1 = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grant1 = sc_logic(1);  port1 = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grant1 = sc_logic(1);  port1 = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grant1 = sc_logic(1);  port1 = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}
		if (req2 == true){
			int NodeDestRow = Packet2_DestNum / dimRowNodes;
			int NodeDestCol = Packet2_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grant2 = sc_logic(1);  port2 = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grant2 = sc_logic(1);  port2 = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grant2 = sc_logic(1);  port2 = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grant2 = sc_logic(1);  port2 = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grant2 = sc_logic(1);  port2 = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grant2 = sc_logic(1);  port2 = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grant2 = sc_logic(1);  port2 = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grant2 = sc_logic(1);  port2 = 3; fullE = 1; }
				//cout << grant2 << " " << port2 << " " << fullE <<"---";
				//wait(1, SC_NS);
			}
		}
		if (req3 == true){
			int NodeDestRow = Packet3_DestNum / dimRowNodes;
			int NodeDestCol = Packet3_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grant3 = sc_logic(1);  port3 = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grant3 = sc_logic(1);  port3 = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grant3 = sc_logic(1);  port3 = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grant3 = sc_logic(1);  port3 = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grant3 = sc_logic(1);  port3 = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grant3 = sc_logic(1);  port3 = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grant3 = sc_logic(1);  port3 = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grant3 = sc_logic(1);  port3 = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}
		if (req4 == true){
			int NodeDestRow = Packet4_DestNum / dimRowNodes;
			int NodeDestCol = Packet4_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grant4 = sc_logic(1);  port4 = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grant4 = sc_logic(1);  port4 = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grant4 = sc_logic(1);  port4 = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grant4 = sc_logic(1);  port4 = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grant4 = sc_logic(1);  port4 = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grant4 = sc_logic(1);  port4 = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grant4 = sc_logic(1);  port4 = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grant4 = sc_logic(1);  port4 = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}
		if (reqW == true){
			int NodeDestRow = PacketW_DestNum / dimRowNodes;
			int NodeDestCol = PacketW_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grantW = sc_logic(1);  portW = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grantW = sc_logic(1);  portW = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grantW = sc_logic(1);  portW = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grantW = sc_logic(1);  portW = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grantW = sc_logic(1);  portW = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grantW = sc_logic(1);  portW = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grantW = sc_logic(1);  portW = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grantW = sc_logic(1);  portW = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}
		if (reqN == true){
			int NodeDestRow = PacketN_DestNum / dimRowNodes;
			int NodeDestCol = PacketN_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grantN = sc_logic(1);  portN = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grantN = sc_logic(1);  portN = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grantN = sc_logic(1);  portN = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grantN = sc_logic(1);  portN = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grantN = sc_logic(1);  portN = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grantN = sc_logic(1);  portN = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grantN = sc_logic(1);  portN = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grantN = sc_logic(1);  portN = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}
		if (reqE == true){
			int NodeDestRow = PacketE_DestNum / dimRowNodes;
			int NodeDestCol = PacketE_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grantE = sc_logic(1);  portE = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grantE = sc_logic(1);  portE = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grantE = sc_logic(1);  portE = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grantE = sc_logic(1);  portE = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grantE = sc_logic(1);  portE = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grantE = sc_logic(1);  portE = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grantE = sc_logic(1);  portE = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grantE = sc_logic(1);  portE = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}
		if (reqS == true){
			int NodeDestRow = PacketS_DestNum / dimRowNodes;
			int NodeDestCol = PacketS_DestNum % dimColNodes;
			int RoutRow = NodeDestRow / 2;
			int RoutCol = NodeDestCol / 2;
			if (RoutRow == RowID && RoutCol == ColID){
				if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 0 && full1 == 0) { grantS = sc_logic(1);  portS = 5; full1 = 1; }
				else if (NodeDestRow % 2 == 0 && NodeDestCol % 2 == 1 && full2 == 0) { grantS = sc_logic(1);  portS = 6; full2 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 1 && full3 == 0) { grantS = sc_logic(1);  portS = 7; full3 = 1; }
				else if (NodeDestRow % 2 == 1 && NodeDestCol % 2 == 0 && full4 == 0) { grantS = sc_logic(1);  portS = 8; full4 = 1; }
			}
			else{
				if (RoutRow > RowID && fullS == 0) { grantS = sc_logic(1);  portS = 4; fullS = 1; }
				else if (RoutRow < RowID && fullN == 0) { grantS = sc_logic(1);  portS = 2; fullN = 1; }
				else if (RoutRow == RowID && RoutCol < ColID && fullW == 0) { grantS = sc_logic(1);  portS = 1; fullW = 1; }
				else if (RoutRow == RowID && RoutCol > ColID && fullE == 0) { grantS = sc_logic(1);  portS = 3; fullE = 1; }
			}
			//wait(1, SC_NS);
		}

	}

}

void Router::BufferW(){

	while (1){
	jumpW:
		PacketW = WestIn->burstRead();
		PacketW.DestNum.readReset();
		for (int i = 0; i <= PacketW.cnt; i++)	PacketW_DestNum = PacketW.DestNum.getNextNode();
		while (PacketW_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from West packet: " << PacketW.sourceNum << " to " << PacketW_DestNum << " at time" << sc_time_stamp() << endl;
			reqW = 1;
			wait();
			reqW = 0;
			if (portW == 1){

				WestOut->burstWrite(PacketW);
				fullW = 0;
				//break;
			}
			else if (portW == 2){

				NorthOut->burstWrite(PacketW);
				fullN = 0;
				//break;
			}
			else if (portW == 3){

				EastOut->burstWrite(PacketW);
				fullE = 0;
				//break;
			}
			else if (portW == 4){

				SouthOut->burstWrite(PacketW);
				fullS = 0;
				//break;
			}
			else if (portW == 5){

				Node1_Out->burstWrite(PacketW);
				full1 = 0;
				//break;
			}
			else if (portW == 6){

				Node2_Out->burstWrite(PacketW);
				full2 = 0;
				//break;
			}
			else if (portW == 7){

				Node3_Out->burstWrite(PacketW);
				full3 = 0;
				//break;
			}
			else if (portW == 8){

				Node4_Out->burstWrite(PacketW);
				full4 = 0;
				//break;
			}
			if (portW > 4){
				PacketW.cnt = PacketW.cnt + 1;
				PacketW_DestNum = PacketW.DestNum.getNextNode();
			}
			else{
				goto jumpW;
			}
		}
	}
}

void Router::BufferN(){
	while (1){
	jumpN:
		PacketN = NorthIn->burstRead();
		PacketN.DestNum.readReset();
		for (int i = 0; i <= PacketN.cnt; i++)	PacketN_DestNum = PacketN.DestNum.getNextNode();
		while (PacketN_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from North packet: " << PacketN.sourceNum << " to " << PacketN_DestNum << " at time" << sc_time_stamp() << endl;
			reqN = 1;
			wait();
			reqN = 0;
			if (portN == 1){

				WestOut->burstWrite(PacketN);
				fullW = 0;
				//break;
			}
			else if (portN == 2){

				NorthOut->burstWrite(PacketN);
				fullN = 0;
				//break;
			}
			else if (portN == 3){

				EastOut->burstWrite(PacketN);
				fullE = 0;
				//break;
			}
			else if (portN == 4){

				SouthOut->burstWrite(PacketN);
				fullS = 0;
				//break;
			}
			else if (portN == 5){

				Node1_Out->burstWrite(PacketN);
				full1 = 0;
				//break;
			}
			else if (portN == 6){

				Node2_Out->burstWrite(PacketN);
				full2 = 0;
				//break;
			}
			else if (portN == 7){

				Node3_Out->burstWrite(PacketN);
				full3 = 0;
				//break;
			}
			else if (portN == 8){

				Node4_Out->burstWrite(PacketN);
				full4 = 0;
				//break;
			}
			if (portN > 4){
				PacketN.cnt = PacketN.cnt + 1;
				PacketN_DestNum = PacketN.DestNum.getNextNode();
			}
			else{
				goto jumpN;
			}
		}
	}
}

void Router::BufferE(){

	while (1){
	jumpE:
		PacketE = EastIn->burstRead();
		PacketE.DestNum.readReset();
		for (int i = 0; i <= PacketE.cnt; i++)	PacketE_DestNum = PacketE.DestNum.getNextNode();
		while (PacketE_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from East packet: " << PacketE.sourceNum << " to " << PacketE_DestNum << " at time" << sc_time_stamp() << endl;
			reqE = 1;
			wait();
			reqE = 0;
			if (portE == 1){

				WestOut->burstWrite(PacketE);
				fullW = 0;
				//break;
			}
			else if (portE == 2){

				NorthOut->burstWrite(PacketE);
				fullN = 0;
				//break;
			}
			else if (portE == 3){

				EastOut->burstWrite(PacketE);
				fullE = 0;
				//break;
			}
			else if (portE == 4){

				SouthOut->burstWrite(PacketE);
				fullS = 0;
				//break;
			}
			else if (portE == 5){

				Node1_Out->burstWrite(PacketE);
				full1 = 0;
				//break;
			}
			else if (portE == 6){

				Node2_Out->burstWrite(PacketE);
				full2 = 0;
				//break;
			}
			else if (portE == 7){

				Node3_Out->burstWrite(PacketE);
				full3 = 0;
				//break;
			}
			else if (portE == 8){

				Node4_Out->burstWrite(PacketE);
				full4 = 0;
				//break;
			}
			if (portE > 4){
				PacketE.cnt = PacketE.cnt + 1;
				PacketE_DestNum = PacketE.DestNum.getNextNode();
			}
			else{
				goto jumpE;
			}
		}
	}
}

void Router::BufferS(){
	while (1){
	jumpS:
		PacketS = SouthIn->burstRead();
		PacketS.DestNum.readReset();
		for (int i = 0; i <= PacketS.cnt; i++)	PacketS_DestNum = PacketS.DestNum.getNextNode();
		while (PacketS_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from South packet: " << PacketS.sourceNum << " to " << PacketS_DestNum << " at time" << sc_time_stamp() << endl;
			reqS = 1;
			wait();
			reqS = 0;
			if (portS == 1){

				WestOut->burstWrite(PacketS);
				fullW = 0;
				//break;
			}
			else if (portS == 2){

				NorthOut->burstWrite(PacketS);
				fullN = 0;
				//break;
			}
			else if (portS == 3){

				EastOut->burstWrite(PacketS);
				fullE = 0;
				//break;
			}
			else if (portS == 4){

				SouthOut->burstWrite(PacketS);
				fullS = 0;
				//break;
			}
			else if (portS == 5){

				Node1_Out->burstWrite(PacketS);
				full1 = 0;
				//break;
			}
			else if (portS == 6){

				Node2_Out->burstWrite(PacketS);
				full2 = 0;
				//break;
			}
			else if (portS == 7){

				Node3_Out->burstWrite(PacketS);
				full3 = 0;
				//break;
			}
			else if (portS == 8){

				Node4_Out->burstWrite(PacketS);
				full4 = 0;
				//break;
			}
			if (portS > 4){
				PacketS.cnt = PacketS.cnt + 1;
				PacketS_DestNum = PacketS.DestNum.getNextNode();
			}
			else{
				goto jumpS;
			}
		}
	}
}

void Router::BufferNode1(){
	while (1){
	jump1:
		Packet1 = Node1_In->burstRead();
		Packet1.DestNum.readReset();
		for (int i = 0; i <= Packet1.cnt; i++)	Packet1_DestNum = Packet1.DestNum.getNextNode();
		while (Packet1_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from Nod1 packet: " << Packet1.sourceNum << " to " << Packet1_DestNum << " at time" << sc_time_stamp() << endl;
			req1 = 1;
			wait();
			req1 = 0;
			if (port1 == 1){

				WestOut->burstWrite(Packet1);
				fullW = 0;
				//break;
			}
			else if (port1 == 2){

				NorthOut->burstWrite(Packet1);
				fullN = 0;
				//break;
			}
			else if (port1 == 3){

				EastOut->burstWrite(Packet1);
				fullE = 0;
				//break;
			}
			else if (port1 == 4){

				SouthOut->burstWrite(Packet1);
				fullS = 0;
				//break;
			}
			else if (port1 == 5){

				Node1_Out->burstWrite(Packet1);
				full1 = 0;
				//break;
			}
			else if (port1 == 6){

				Node2_Out->burstWrite(Packet1);
				full2 = 0;
				//break;
			}
			else if (port1 == 7){

				Node3_Out->burstWrite(Packet1);
				full3 = 0;
				//break;
			}
			else if (port1 == 8){

				Node4_Out->burstWrite(Packet1);
				full4 = 0;
				//break;
			}

			if (port1 > 4){
				Packet1.cnt = Packet1.cnt + 1;
				Packet1_DestNum = Packet1.DestNum.getNextNode();
			}
			else{
				goto jump1;
			}

		}
	}
}

void Router::BufferNode2(){
	while (1){
	jump2:
		Packet2 = Node2_In->burstRead();
		Packet2.DestNum.readReset();
		for (int i = 0; i <= Packet2.cnt; i++)	Packet2_DestNum = Packet2.DestNum.getNextNode();
		while (Packet2_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from Nod2 packet: " << Packet2.sourceNum << " to " << Packet2_DestNum << " at time" << sc_time_stamp() << endl;
			req2 = 1;
			wait();
			req2 = 0;
			if (port2 == 1){

				WestOut->burstWrite(Packet2);
				fullW = 0;
				//break;
			}
			else if (port2 == 2){

				NorthOut->burstWrite(Packet2);
				fullN = 0;
				//break;
			}
			else if (port2 == 3){

				EastOut->burstWrite(Packet2);
				fullE = 0;
				//break;
			}
			else if (port2 == 4){

				SouthOut->burstWrite(Packet2);
				fullS = 0;
				//break;
			}
			else if (port2 == 5){

				Node1_Out->burstWrite(Packet2);
				full1 = 0;
				//break;
			}
			else if (port2 == 6){

				Node2_Out->burstWrite(Packet2);
				full2 = 0;
				//break;
			}
			else if (port2 == 7){

				Node3_Out->burstWrite(Packet2);
				full3 = 0;
				//break;
			}
			else if (port2 == 8){

				Node4_Out->burstWrite(Packet2);
				full4 = 0;
				//break;
			}
			if (port2 > 4){
				Packet2.cnt = Packet2.cnt + 1;
				Packet2_DestNum = Packet2.DestNum.getNextNode();
			}
			else{
				goto jump2;
			}
		}
	}
}

void Router::BufferNode3(){
	while (1){
	jump3:
		Packet3 = Node3_In->burstRead();
		Packet3.DestNum.readReset();
		for (int i = 0; i <= Packet3.cnt; i++)	Packet3_DestNum = Packet3.DestNum.getNextNode();
		while (Packet3_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from Nod3 packet: " << Packet3.sourceNum << " to " << Packet3_DestNum << " at time" << sc_time_stamp() << endl;
			req3 = 1;
			wait();
			req3 = 0;
			if (port3 == 1){

				WestOut->burstWrite(Packet3);
				fullW = 0;
				//break;
			}
			else if (port3 == 2){

				NorthOut->burstWrite(Packet3);
				fullN = 0;
				//break;
			}
			else if (port3 == 3){

				EastOut->burstWrite(Packet3);
				fullE = 0;
				//break;
			}
			else if (port3 == 4){

				SouthOut->burstWrite(Packet3);
				fullS = 0;
				//break;
			}
			else if (port3 == 5){

				Node1_Out->burstWrite(Packet3);
				full1 = 0;
				//break;
			}
			else if (port3 == 6){

				Node2_Out->burstWrite(Packet3);
				full2 = 0;
				//break;
			}
			else if (port3 == 7){

				Node3_Out->burstWrite(Packet3);
				full3 = 0;
				//break;
			}
			else if (port3 == 8){

				Node4_Out->burstWrite(Packet3);
				full4 = 0;
				//break;
			}
			if (port3 > 4){
				Packet3.cnt = Packet3.cnt + 1;
				Packet3_DestNum = Packet3.DestNum.getNextNode();
			}
			else{
				goto jump3;
			}
		}
	}
}

void Router::BufferNode4(){
	while (1){
	jump4:
		Packet4 = Node4_In->burstRead();
		Packet4.DestNum.readReset();
		for (int i = 0; i <= Packet4.cnt; i++)	Packet4_DestNum = Packet4.DestNum.getNextNode();
		while (Packet4_DestNum != -1){
			cout << "Router(" << RowID << "," << ColID << ") from Nod4 packet: " << Packet4.sourceNum << " to " << Packet4_DestNum << " at time" << sc_time_stamp() << endl;
			req4 = 1;
			wait();
			req4 = 0;
			if (port4 == 1){

				WestOut->burstWrite(Packet4);
				fullW = 0;
				//break;
			}
			else if (port4 == 2){

				NorthOut->burstWrite(Packet4);
				fullN = 0;
				//break;
			}
			else if (port4 == 3){

				EastOut->burstWrite(Packet4);
				fullE = 0;
				//break;
			}
			else if (port4 == 4){

				SouthOut->burstWrite(Packet4);
				fullS = 0;
				//break;
			}
			else if (port4 == 5){

				Node1_Out->burstWrite(Packet4);
				full1 = 0;
				//break;
			}
			else if (port4 == 6){

				Node2_Out->burstWrite(Packet4);
				full2 = 0;
				//break;
			}
			else if (port4 == 7){

				Node3_Out->burstWrite(Packet4);
				full3 = 0;
				//break;
			}
			else if (port4 == 8){
				Node4_Out->burstWrite(Packet4);
				full4 = 0;
				//break;
			}
			if (port4 > 4){
				Packet4.cnt = Packet4.cnt + 1;
				Packet4_DestNum = Packet4.DestNum.getNextNode();
			}
			else{
				goto jump4;
			}
		}

	}
}