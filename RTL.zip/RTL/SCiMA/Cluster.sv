module Cluster 
#(parameter ConfigSize=32, PacketSize=16, XB_size=128, DataWidth=16,WeightWidth=8,  SliceWidth=2,CellBits=2,
  real DACmax=3,parameter ADCresolution=11, real Hcond=10**-9, real Lcond=0, parameter SRIF_ADC_delay = 10,
  mv = 4, nv=4)
  (clk, rst, reqIn, ackIn, Din, reqOut, ackOut, Dout);
  /*
  parameter N = (H - r +1) * (W - s +1);
  parameter Cluster_IFM_size = (H* W * C);
  parameter Cluster_OFM_size = (N*K);
  parameter KPU = XB_size / WeightWidth * CellBits;
  parameter ChPerVMM = XB_size / (r*s);
  parameter mav = (C-1)/ ChPerVMM;
  parameter nav = (K-1)/KPU;
  */
  input clk, rst;
  input clk, rst, reqIn, ackOut;
  output ackIn, reqOut;
  input [DataWidth-1:0] Din;
  output [DataWidth-1:0] Dout;
  
  wire ReqVMMLeft [0:(mv-1)];
  wire  AckVMMLeft [0:(mv-1)];  
  wire ReqVMMDown [0:(nv-1)];
  wire  AckVMMDown [0:(nv-1)];
  wire readIFM, writeIFM, readOFM, writeOFM;
  wire enIFMout, enOFMout, seldata;
  wire [$clog2(Cluster_IFM_size):0] AddIFM;
  wire [$clog2(Cluster_OFM_size):0] AddOFM;
  wire [$clog2(nv):0] SelVMM;
  wire zeroing, rstsum, loadSum, sendsum1, sendsum2;
  
  ClusterInterface  #(DataWidth, PacketSize, ConfigSize) CI
  (clk, rst, reqIn, ackIn, Din, reqOut, ackOut, Dout, writeMem, readMem, addressWrite, addressRead,
  Index, LIF, RIF, UIF, DIF, H, W, C, K, r, s, stride, MP, Act,
  BaseI, PacketI, NumI, BaseO, PacketO, NumO,BaseP, PacketP, NumP, N, KPU, CPU, mav, nav
  );
  
  ClusterDatapath #(XB_size, DataWidth,WeightWidth,  SliceWidth,CellBits,
  DACmax, ADCresolution, Hcond,Lcond, SRIF_ADC_delay, mv, nv, Cluster_IFM_size, Cluster_OFM_size, mav+1, nav+1,
  Tix, Tiy,Cix,Ciy) ClusDP
  (clk, rst, ReqVMMLeft, AckVMMLeft, ReqVMMDown, AckVMMDown, Din_left, Din_up, Dout_right, Dout_down,
  enIFMout, enOFMout, SelVMM, seldata, AddIFM, AddOFM, readIFM, writeIFM, readOFM, writeOFM,
  zeroing, rstsum, loadSum, sendsum1, sendsum2);
  
  ClusOFMController  
  #(nv, KPU, K, N, LIF, UIF, DIF) OFMController
  (clk, rst, writeOFM, readOFM, AddOFM, ReqVMMDown, AckVMMDown, ReqUp, AckUp,
  ReqDown, AckDown, seldata, SelVMM, enOFMout);
  
  
  ClusIFMContrConv  
  #(mv, H, W, C, r, s, stride, XB_size, LIF, RIF) IFMControllerConv
  (clk, rst, writeIFM, readIFM, AddIFM, ReqVMMLeft, AckVMMLeft, ReqLeft, AckLeft, ReqRight, AckRight, enIFMout,
  zeroing, rstsum, loadSum, sendsum1, sendsum2);

  endmodule 
  