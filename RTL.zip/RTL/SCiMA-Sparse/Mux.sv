module Mux 
  #(Size = 8, Width=8)
  (Din, Sel, en, Dout);
  
  input [(Width-1):0] Din [0:(Size-1)];
  input [($clog2(Size)):0] Sel;
  input en;
  output [(Width-1):0] Dout;
  
  assign Dout = en ? Din[Sel] : 0;
  
  
endmodule