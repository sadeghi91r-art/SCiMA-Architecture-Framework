module ADC
  #(parameter real MaxVal=3, parameter ResolutionBits=16, size=128, Aggrgate=8, m=1, sliceWidth=2)
  (SigIn, DigOut);
  parameter SizeOutputVector=size/Aggrgate;
  input  real SigIn [0:(size-1)];
  output logic [(ResolutionBits-1):0] DigOut [0:(SizeOutputVector-1)];
  
  
  
  real AggregateAnalog [0:(SizeOutputVector-1)];
  real val[0:(SizeOutputVector-1)];
  integer val_i [0:(SizeOutputVector-1)];
  
  always @(*) begin
	for (int i=0; i<SizeOutputVector; i=i+1) begin
		AggregateAnalog[i]=0;
		for (int j=0; j<Aggrgate; j=j+1) begin
			AggregateAnalog[i]=AggregateAnalog[i]+ SigIn[i*Aggrgate+j]*((2**m)**(Aggrgate-1-j));
		end
	end
	for (int i=0; i<SizeOutputVector; i=i+1) begin
		val[i] = AggregateAnalog[i]/MaxVal;
		val_i[i] = val[i] * ((2**sliceWidth)-1)*(size)*((2**m)-1)*(((2**m)**Aggrgate)-1);
		DigOut[i]= val_i[i];
	end
	
		
  end
  /*
  genvar i;
  generate
    for (i=0; i<SizeOutputVector; i=i+1) begin
		always @ (SigIn[i]) begin
			AggregateAnalog[i]=0;
			for (int j=0; j<Aggrgate; j=j+1) AggregateAnalog[i]=AggregateAnalog[i]+ SigIn[i*Aggrgate+j]*((2**m)**j);
		end
		always@(*) begin
			val[i] = AggregateAnalog[i]/MaxVal;
			val_i[i] = val[i] * ((2**ResolutionBits)-1);
			DigOut[i]= val_i[i];
		end
	end
  endgenerate
*/
endmodule


module ADC_tester #(parameter real MaxVal=3, parameter ResolutionBits=16, size=128, Aggrgate=8, m=1) ();
parameter SizeOutputVector=size/Aggrgate;
real SigIn [0:(size-1)];
logic [(ResolutionBits-1):0] DigOut [0:(SizeOutputVector-1)];
ADC #(MaxVal, ResolutionBits, size, Aggrgate, m) ADC_UT (SigIn, DigOut);
  
 
  
   initial begin
   
	for (int j=0; j<size; j=j+1)	SigIn[j]=0;
	#175;
	for (int j=0; j<size; j=j+1) 
		if (j<5 || j>100) SigIn[j]=0.005;
		else SigIn[j]=0;
	#175;
	for (int j=0; j<size; j=j+1) 
		if (j<5 || j>100) SigIn[j]=0;
		else SigIn[j]=0;
	
   end
  
endmodule

