    module VMM_ContOutput
      #(LIF=1, UIF=1, DIF=1, OVsize=16,
	  PSO=8, logic [($clog2(PSO)-1):0] PrunedColumns [0:PSO-1])
  (clk, rst, dataready,
  writeOFM, readOFM, DoneSendOFM,
  FullEmptyOFM,
  zeroingBPCD, writeBPCD, readBPCD, FullEmptyBPCD,
  selectPruned,
  req_up, ack_up,
  req_down, ack_down);
  
input clk, rst, dataready, FullEmptyOFM, req_up, ack_down;
output writeOFM, readOFM, ack_up, req_down, DoneSendOFM;

  output zeroingBPCD;
  output writeBPCD;
  output readBPCD;
  input FullEmptyBPCD;
  input selectPruned;
  
logic [3:0] ns, ps;
  logic rstC, enC, DetTransferEnd;
  logic [($clog2(2*OVsize)-1):0] count_reg;
  logic [($clog2(PSO)-1):0] index_Temp_Pruned;

 parameter Idle=0, GetRegUp=1, GiveAckUp=2, TakeAckUp=3, GetOFMBurst=4,
 GiveReqDown=5, ReqInAc=6, waiting=7, sendOFM=8, Idle1=9, Idle2=10; 
always@(ps, dataready, req_up, FullEmptyOFM, ack_down) begin
      ns=Idle;
      case(ps)
        Idle: begin
			if (LIF) begin
				if(dataready) begin
					if (UIF==1) ns=GetRegUp;
					else
						if (DIF==1) ns=GiveReqDown;
						else ns = Idle;
				end 
				else ns= Idle;
			end
			else
				if (UIF==1) ns=GetRegUp;
				else
					if (DIF==1) ns=GiveReqDown;
					else ns = Idle;
			end 
        GetRegUp: begin
          if (req_up==1'b1) ns=GiveAckUp;
          else ns= GetRegUp;
        end
        GiveAckUp: begin
          if (req_up==1'b0) ns=TakeAckUp;
          else ns= GiveAckUp;
        end
        TakeAckUp: begin
          ns= GetOFMBurst;
        end
		GetOFMBurst: begin
          if(FullEmptyOFM) ns = GiveReqDown;
		  else ns=GetOFMBurst;
        end
        GiveReqDown: begin
          if(ack_down==1'b1) ns = ReqInAc;
		  else ns=GiveReqDown;
        end
		ReqInAc: begin
          if(ack_down==1'b0) ns = sendOFM;
		  else ns=ReqInAc;
        end
		waiting: begin
          ns=sendOFM;
        end
		sendOFM: begin
          if(FullEmptyOFM) ns = Idle1;
		  else ns=sendOFM;
        end
		Idle1: begin
          ns = Idle2;
        end
		Idle2: begin
          ns = Idle;
        end
        default : begin
          ns = Idle;
        end
      endcase
end

always@(posedge clk) begin
      if (rst) ps<=Idle;
      else ps<=ns;
end



assign writeOFM = ((ps == GetOFMBurst) && !selectPruned);
assign readOFM = (ps == GetOFMBurst || (ps == sendOFM)) && !selectPruned;
assign ack_up = (ps == GiveAckUp);
assign req_down = (ps == GiveReqDown);
assign DoneSendOFM = (ps == Idle1 || ps==Idle2);

assign rstC = (ps == TakeAckUp || ps == waiting);
assign enC = (ps == GetOFMBurst || ps == sendOFM);
assign DetTransferEnd=count_reg==(PSO+OVsize);
always@(posedge clk) begin
	if(rstC) count_reg<=0;
	else if (enC) count_reg <= count_reg+1;
end
always@(posedge clk) begin
	if(rstC) index_Temp_Pruned<=0;
	else if (enC) index_Temp_Pruned <= index_Temp_Pruned+1;
end
assign selectPruned=PrunedColumns[index_Temp_Pruned]==count_reg;

	
	assign zeroingBPRD = (ps==Idle);
	assign writeBPRD = ((ps == GetOFMBurst) && selectPruned);
	assign readBPRD = (ps == GetOFMBurst || (ps == sendOFM)) && selectPruned;
	
endmodule