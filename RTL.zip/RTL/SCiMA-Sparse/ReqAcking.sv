module Requesting 
(clk, req, ack);
input clk, ack;
output logic req;

always begin
req=0;
@(posedge clk);
@(posedge clk);
@(posedge clk);
req=1;
@(posedge clk);

@(posedge ack);

@(posedge clk);

req=0;
@(posedge clk);
@(negedge ack);
@(posedge clk);

end

endmodule

module Acking 
(clk, req, ack);
input clk, req;
output logic ack;

always begin
ack=0;
@(posedge clk);

if (req != 0) @(posedge req);

@(posedge clk);

ack=1;
@(posedge clk);
@(negedge req);
@(posedge clk);

end

endmodule

module ReqAckTester();
  wire req, ack;
  logic clk=0;
  always #17 clk=~clk;
  Requesting Req1 (clk, req, ack);
  Acking     Ack1 (clk, req, ack);
  ReqAckRegister #("left", "VMM",1,2) Regist (req, ack );
endmodule