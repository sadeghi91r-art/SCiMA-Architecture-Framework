module VMM_Datapath
  #(
  parameter  XB_size=128, DataWidth=16, WeightWidth=8,  SliceWidth=2, m=2, ADCresolution=11,
  real DACmax=1, real Hcond=10**-9, real Lcond=0, Tix=1, Tiy=1,Cix=1,Ciy=1,Vix=1, Viy=1, LIF=1,
  integer PSI=64, integer PSO=8)
  (
  clk, rst,
  writeIFM, readIFM, shiftIFM, 
  writeOFM, readOFM,
  index, slice,
  FullEmptyIFM, FullEmptyOFM,
  zeroingBPRD, writeBPRD, readBPRD, FullEmptyBPRD,
  zeroingBPCD, writeBPCD, readBPCD, FullEmptyBPCD,
  selectRightData, selectDownData,
  Din_left, Din_up, Dout_right, Dout_down);
  
  
  
  parameter Aggrgate=WeightWidth/m;
  parameter NumSlices=DataWidth/SliceWidth;
  parameter OVsize=(XB_size*m/WeightWidth);
 
  parameter real maxCurXB=XB_size* DACmax * Hcond*(((2**m)**Aggrgate)-1);
  parameter minCurXB=0;
  parameter ConcWidth = DataWidth - ADCresolution;
  
  input clk, rst, writeIFM, readIFM, shiftIFM, writeOFM, readOFM;
  input [($clog2(OVsize)-1) : 0] index;
  input [($clog2(NumSlices)-1) : 0] slice;
  output FullEmptyIFM, FullEmptyOFM;
  input [(DataWidth-1):0] Din_left;
  input [(DataWidth-1):0] Din_up;
  output [(DataWidth-1):0] Dout_right; 
  output [(DataWidth-1):0] Dout_down;
  

  input zeroingBPRD;
  input writeBPRD;
  input readBPRD;
  input FullEmptyBPRD;

  input zeroingBPCD;
  input writeBPCD;
  input readBPCD;
  input FullEmptyBPCD;

  input selectRightData;
  input selectDownData;
  
  real CurrentMemArray [0:(XB_size-1)];
  real VinMemArray [0:(XB_size-1)];
  
  wire [(ADCresolution-1):0] PartialResult [0:(OVsize-1)];
  wire [(ADCresolution-1):0] PRselected;
  wire [(DataWidth-1):0] WeightedPartialResult;
  wire [(DataWidth-1):0] OBin;
  wire [(DataWidth-1):0] Din;
  wire [(SliceWidth-1):0] DACin [0:(XB_size-1)];
  wire [(DataWidth-1):0] Dout_IFM;
  wire [(DataWidth-1):0] ADCout;
  
  logic  [($clog2(DataWidth)-1): 0] shiftNum;
  
  
  //new for datapath
  
  logic [(DataWidth-1):0] Dout_downM;
  logic [(DataWidth-1):0] D_right_pruned;
  logic [(DataWidth-1):0] Dout_down_Pruned;
  

  
  assign shiftNum=slice*SliceWidth;
  
  assign PRselected=PartialResult[index];
  assign ADCout={{ConcWidth{PRselected[ADCresolution-1] }}, PRselected};
  BufferIFM_VMM #(XB_size, DataWidth, SliceWidth) BufferIFM (clk, rst, writeIFM, readIFM, shiftIFM, FullEmptyIFM, Din_left, Dout_IFM, DACin);
  
  genvar i;
  generate
    for (i=0; i<XB_size; i=i+1) begin
      DAC #(DACmax,  SliceWidth) DacNum (DACin[i], VinMemArray[i]);
	  end
  endgenerate
  Memristor_Array #(XB_size,  Tix, Tiy, Cix, Ciy, Vix, Viy, LIF) MemArr(VinMemArray, CurrentMemArray);
  ADC #(maxCurXB, ADCresolution, XB_size, Aggrgate, m, SliceWidth) ADC_UT (CurrentMemArray, PartialResult);
  barrel_shiftern #(DataWidth) BS (WeightedPartialResult, ADCout, shiftNum);
  assign OBin=WeightedPartialResult+(slice==0 ? 0 : Dout_downM);
  Buffer #(OVsize, DataWidth) BufferOFM (clk, rst, writeOFM, readOFM, FullEmptyOFM, Din, Dout_downM);
  assign Din = ((~readOFM) & writeOFM) ? OBin : (Dout_downM+Din_up);
  
  
  /***************For pruing the input********************/
  
  
  Buffer #(PSI, DataWidth) BufferPrunedRowsData
  (clk, rst, writeBPRD, readBPRD, FullEmptyBPRD, Din_left, D_right_pruned);
  
  assign Dout_right = (selectRightData) ?  D_right_pruned : Dout_IFM;
  
  /***************For pruing the output*******************/
 
  Buffer #(PSO, DataWidth) BufferPrunedColumnsData 
  (clk, rst, writeBPCD, readBPCD, FullEmptyBPCD, Din_up, Dout_down_Pruned);
  
  assign Dout_down=(selectDownData) ?  Dout_down_Pruned : Dout_downM;

endmodule

