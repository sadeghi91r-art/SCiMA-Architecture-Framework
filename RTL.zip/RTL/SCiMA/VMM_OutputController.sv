    module VMM_OutputController
  (clk, rst, dataready,
  writeOFM, readOFM, DoneSendOFM,
  FullEmptyOFM,
  req_up, ack_up,
  req_down, ack_down,
  Prog, LIF, UIF, DIF);
  
input clk, rst, dataready, FullEmptyOFM, req_up, ack_down;
output writeOFM, readOFM, ack_up, req_down, DoneSendOFM;
input Prog, LIF, UIF, DIF;

logic [3:0] ns, ps;



 parameter Idle=0, GetRegUp=1, GiveAckUp=2, TakeAckUp=3, GetOFMBurst=4,
 GiveReqDown=5, ReqInAc=6, waiting=7, sendOFM=8, Idle1=9, Idle2=10; 
always@(ps, dataready, req_up, FullEmptyOFM, ack_down) begin
      ns=Idle;
      case(ps)
        Idle: begin
			if (LIF) begin
				if(dataready) begin
					if (UIF==1) ns=GetRegUp;
					else
						if (DIF==1) ns=GiveReqDown;
						else ns = Idle;
				end 
				else ns= Idle;
			end
			else
				if (UIF==1) ns=GetRegUp;
				else
					if (DIF==1) ns=GiveReqDown;
					else ns = Idle;
			end 
        GetRegUp: begin
          if (req_up==1'b1) ns=GiveAckUp;
          else ns= GetRegUp;
        end
        GiveAckUp: begin
          if (req_up==1'b0) ns=TakeAckUp;
          else ns= GiveAckUp;
        end
        TakeAckUp: begin
          ns= GetOFMBurst;
        end
		GetOFMBurst: begin
          if(FullEmptyOFM) ns = GiveReqDown;
		  else ns=GetOFMBurst;
        end
        GiveReqDown: begin
          if(ack_down==1'b1) ns = ReqInAc;
		  else ns=GiveReqDown;
        end
		ReqInAc: begin
          if(ack_down==1'b0) ns = sendOFM;
		  else ns=ReqInAc;
        end
		waiting: begin
          ns=sendOFM;
        end
		sendOFM: begin
          if(FullEmptyOFM) ns = Idle1;
		  else ns=sendOFM;
        end
		Idle1: begin
          ns = Idle2;
        end
		Idle2: begin
          ns = Idle;
        end
        default : begin
          ns = Idle;
        end
      endcase
end

always@(posedge clk) begin
      if (rst) ps<=Idle;
      else ps<=ns;
end
	
assign writeOFM = ((ps == GetOFMBurst) );
assign readOFM = (ps == GetOFMBurst || (ps == sendOFM));
assign ack_up = (ps == GiveAckUp);
assign req_down = (ps == GiveReqDown);
assign DoneSendOFM = (ps == Idle1 || ps==Idle2);


endmodule