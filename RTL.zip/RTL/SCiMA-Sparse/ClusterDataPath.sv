module ClusterDatapath
#(parameter XB_size=128, DataWidth=16,WeightWidth=8,  SliceWidth=2,CellBits=2,
  real DACmax=3,parameter ADCresolution=11, real Hcond=10**-9, real Lcond=0, parameter SRIF_ADC_delay = 10,
  mv = 4, nv=4, Cluster_IFM_size=200, Cluster_OFM_size=100, mav=2, nav=2, Tix=1, Tiy=1,Cix=1,Ciy=1)
  (clk, rst,
  ReqVMMLeft, AckVMMLeft, ReqVMMDown, AckVMMDown,
  Din_left, Din_up, Dout_right, Dout_down,
  enIFMout, enOFMout, SelVMM, seldata,
  AddIFM, AddOFM, readIFM, writeIFM, readOFM, writeOFM,
  zeroing, rstsum, loadSum, sendsum1, sendsum2);
    
  
  input  clk, rst;
  input ReqVMMLeft [0:(mv-1)];
  output  AckVMMLeft [0:(mv-1)];
  
  output ReqVMMDown [0:(nv-1)];
  input  AckVMMDown [0:(nv-1)];
  
  input  [(DataWidth-1):0]  Din_left, Din_up;
  output [(DataWidth-1):0] Dout_right, Dout_down;
  input enIFMout, enOFMout, seldata;
  input [$clog2(Cluster_IFM_size):0] AddIFM;
  input [$clog2(Cluster_OFM_size):0] AddOFM;
  input [$clog2(nv):0] SelVMM;
  input readIFM, writeIFM, readOFM, writeOFM;
  input  [(DataWidth-1):0]  Din_left, Din_up;
  output zeroing, rstsum, loadSum, sendsum1, sendsum2;
  
   wire  [(DataWidth-1):0]  DataLeft [0:(mv-1)];
   wire  [(DataWidth-1):0]  DataDown [0:(nv-1)];
   
   wire  [(DataWidth-1):0]  DinIFM, DinOFM;
   wire  [(2*DataWidth-1):0]  DoutSum;
   wire  [(DataWidth-1):0]  DoutIFM, DoutOFM, VMMDownOut;
   logic  [(DataWidth-1):0]  DataMux;

  
Memory  #(Cluster_IFM_size, DataWidth, 0) IFMmem (DinIFM, AddIFM, DoutIFM, clk, rst, readIFM, writeIFM);
Memory  #(Cluster_OFM_size, DataWidth, 0) OFMmem (DinOFM, AddOFM, DoutOFM, clk, rst, readOFM, writeOFM);

VMM_Array
#( XB_size, DataWidth, WeightWidth, SliceWidth, CellBits, DACmax, ADCresolution, Hcond,Lcond, SRIF_ADC_delay,
	mv, nv, mav, nav, Tix, Tiy,Cix,Ciy) VMMArray (clk, rst, ReqVMMLeft, AckVMMLeft, ReqVMMDown, AckVMMDown, DataLeft, DataDown);
	
Mux 	#(nv, DataWidth) VMM_selector (DataDown, SelVMM, 1'b1, VMMDownOut);

assign Dout_right = enIFMout ? DoutIFM : 0;
assign Dout_down =  enOFMout ? DoutOFM  : 0;
assign DinIFM = Din_left;
assign DinOFM = seldata ? VMMDownOut : (DoutOFM + Din_up);

assign DataMux = zeroing ? 0 : sendsum1 ? DoutSum[DataWidth-1: 0] : sendsum2? DoutSum[(2*DataWidth-1): DataWidth]: DoutIFM;
genvar i;
generate // concting one port to some ports directly
	for (i = 0; i< mv; i=i+1) begin
		assign DataLeft[i] = DataMux;
	end
endgenerate

Register #(2*DataWidth) RegSum (({{DataWidth{1'b0 }}, DataLeft[0]} + DoutSum), clk, rstsum, loadSum, DoutSum);

endmodule