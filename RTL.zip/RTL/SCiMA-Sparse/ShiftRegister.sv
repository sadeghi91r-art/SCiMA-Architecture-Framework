module ShiftRegister
  #(parameter Width =16, parameter NumShift=2)
  (clk, reset, load, shift, Din, Dout, DSout);
  
  input clk, reset, load, shift;
  input  [(Width-1):0] Din;
  output [(Width-1):0] Dout;
  output [(NumShift-1):0] DSout;
  
  reg [(Width-1):0] Dreg=0;
  always@(posedge clk) begin
    if (reset) Dreg<=0;
    else if (load) Dreg<=Din;
    else if (shift) Dreg<= {Dreg[(NumShift-1):0], Dreg[(Width-1): NumShift]};
  end
  assign Dout = Dreg;
  assign DSout = Dreg[(NumShift-1):0];
  
endmodule

