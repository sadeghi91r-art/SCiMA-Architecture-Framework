
struct DataVol{
public:
	int H=0;
	int W=0;
	int C=0;
	int* data;
	int sourceNum=0;
	int DestNum=0;
};