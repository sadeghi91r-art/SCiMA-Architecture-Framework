module ClusterarrayTester
#(parameter XB_size=128, DataWidth=16,WeightWidth=16,  BitsApplied=2,BitsPerCell=2,
  VDD=3, HighResistance=10**6,LowResistance=10**3, NumclockTimer = 10,
  mv=4, nv=4, mc = 4, nc=4, mca = 2, nca =2, H=6, W=6, C=56, CL=8, r=3, s=3, K = 30, KL=5,stride = 1,
  Tix=1, Tiy=1);
    
  
 logic clk=0, rst;
logic  [(DataWidth-1):0] DataLeft    [0:mc-1];
wire [(DataWidth-1):0] DataDown    [0:nc-1];

logic  ReqLeft     [0:mc-1];
wire AckLeft     [0:mc-1];
logic  AckDown    [0:nc-1];
wire  ReqDown    [0:nc-1];


Cluster_Array
#(XB_size, DataWidth, WeightWidth, BitsApplied, BitsPerCell, VDD, HighResistance, LowResistance, NumclockTimer,
  mv, nv, mc, nc, mca, nca, H, W, C, CL, r, s, K, KL, stride, Tix, Tiy) Inst
  (clk, rst, ReqLeft, AckLeft, ReqDown, AckDown, DataLeft, DataDown);

   always #17 clk=~clk;


genvar i, j;	

generate
for (i = 0; i< mc; i=i+1) begin
	for (j = 0; j< nca; j=j+1) begin
		//ReqAckRegister #("left_right", "VMM", i+1, j+1) recorderLR (ClusterInst.ClusDP.VMMArray.Req_right_left[i][j], ClusterInst.ClusDP.VMMArray.Ack_right_left[i][j] );
		//ReqAckRegister #("up_down", "VMM", i+1, j+1) recorderUD (ClusterInst.ClusDP.VMMArray.Req_up_down[i][j], ClusterInst.ClusDP.VMMArray.Ack_up_down[i][j] );
		Recorder #("Cluster", i, j) Monitor (
		Inst.Req_right_left[i][j],
		Inst.Ack_right_left[i][j],
		Inst.Req_right_left[i][j+1],
		Inst.Ack_right_left[i][j+1],
		Inst.Req_up_down[i][j],
		Inst.Ack_up_down[i][j],
		Inst.Req_up_down[i+1][j],
		Inst.Ack_up_down[i+1][j]);
	end
end
endgenerate	
/*
generate
for (i = 0; i< mc; i=i+1) begin
	for (j = 0; j< nca; j=j+1) begin
		//ReqAckRegister #("left_right", "VMM", i+1, j+1) recorderLR (ClusterInst.ClusDP.VMMArray.Req_right_left[i][j], ClusterInst.ClusDP.VMMArray.Ack_right_left[i][j] );
		//ReqAckRegister #("up_down", "VMM", i+1, j+1) recorderUD (ClusterInst.ClusDP.VMMArray.Req_up_down[i][j], ClusterInst.ClusDP.VMMArray.Ack_up_down[i][j] );
		Recorder #("Cluster", i, j) Monitor (
		Inst.ClusInst[0][0].ClusDP.VMMArray.Req_right_left[i][j],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Ack_right_left[i][j],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Req_right_left[i][j+1],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Ack_right_left[i][j+1],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Req_up_down[i][j],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Ack_up_down[i][j],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Req_up_down[i+1][j],
		Inst.ClusInst[0][0].ClusDP.VMMArray.Ack_up_down[i+1][j]);
	end
end
endgenerate	
*/

 initial begin
		rst =1;
		#170 rst=0;
end

genvar ii;
generate 
	for ( ii = 0; ii<nc; ii++) begin
		assign AckDown[ii] = ReqDown[ii];
	end
endgenerate  

initial begin
	for (int i = 0; i<mc; i++) begin
		ReqLeft[i] = 0;
	end

	for (int i = 0; i<(mca-1); i++) begin
		ReqLeft[i] = 1;
		@(posedge AckLeft[i]);
		#170;
		ReqLeft[i] = 0;
		@(negedge AckLeft[i]);
		#34;
		#34;
		for (integer i1 = 0; i1<(H*W*C); i1=i1+1) begin
			DataLeft[i]  = i1;
			#34;
		end
	end
	ReqLeft[mca-1] = 1;
	@(posedge AckLeft[mca-1]);
	#170;
	ReqLeft[mca-1] = 0;
	@(negedge AckLeft[mca-1]);
	#34;
	#34;
	for (integer i = 0; i<(H*W*CL); i=i+1) begin
		DataLeft[mca-1] = i;
		#34;
	end
end 
  
endmodule