
module BufferConfig
  #(parameter Size =128, Width=16)
  (clk, rst, zeroing, write, read, Din, Dout, Dsout);
  input clk, rst, write, read, shift;
  input  [(Width-1):0] Din;
  output [(Width-1):0] Dout;
  output  [(Width-1):0] Dsout [0:(Size-1)];

  logic [($clog2(Size)-1):0] count_reg;
  logic  [(Width-1):0] RegO [0:(Size-1)];

  always @(posedge clk) begin // writing and shifiting  
	if (write) begin
		RegO[count_reg] <= Din;
	end
  end
  
 
  
  assign Dout = (read) ? RegO [count_reg] : 0; // reading 
  
   always@(posedge clk) begin // Poninter
    if(rst || zeroing) count_reg<=0;
    else if ((read||write)) count_reg <= count_reg + 1;
  end


 genvar k; 
  generate
    for (k=0; k<Size; k=k+1) begin : ShiftPort
        assign Dsout[k] = RegO[k];
    end  
  endgenerate 

  
endmodule

