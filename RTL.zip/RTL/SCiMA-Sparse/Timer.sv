
module Timer
  #(parameter Width =3, Numclock=5)
  (clk, rst, en, TO);
  input clk, rst, en;
  output TO;
  logic [(Width-1):0] count_reg=0;
  always@(posedge clk) begin
    if(rst) count_reg<=0;
    else if (en) count_reg <= count_reg+1;
  end
  assign TO= (count_reg==Numclock);
endmodule
