module Memory 
  #(Size, Width, initval=0)
  (Din, Address, Dout, clk, rst, read, write);
  
  input [(Width-1):0] Din;
  input [($clog2(Size)):0] Address;
  output logic [(Width-1):0] Dout;
  input clk, rst, read, write;
  
  logic [(Width-1):0] Mem [(Size-1):0];
  integer i;
  
  initial begin
    for (int k=0; k<Size; k=k+1) begin
        Mem[k] = 0;
      end
  end
  
  always@(*) begin
    if (read) begin
		Dout = Mem[Address];
    end
  end
  
  always@(posedge clk) begin
    if(rst) begin
      for (i=0; i<Size; i=i+1) begin
        Mem[i] <= 0;
      end
    end
    else if(write) begin
        Mem[Address] <= Din;
    end
  end
  
endmodule
