
using namespace std;


template <class T>
class TempLinkedList {
private:
	
	struct Node{
		T value;
		struct Node *nextNodePointer;
	};
	Node *head;
	Node *lastRead;

	bool read;
	
public: 
	TempLinkedList()
	{
		head = NULL;
		lastRead = NULL;
		read = false;
	}
	
	//~TempLinkedList();
	
	void appeand (T value);
	T    getNextNode();
	void displayList();
	void readReset();
	void emptify();
	
};


template <class T>
void TempLinkedList<T>::appeand(T value){
	Node *newNode;
	Node *nodePtr;

	newNode = new Node;
	newNode->value = value;
	newNode->nextNodePointer = NULL;

	if (!head)
		head = newNode;
	else{
		nodePtr = head;
		while (nodePtr->nextNodePointer)
			nodePtr = nodePtr->nextNodePointer;
		nodePtr->nextNodePointer = newNode;
	}

}


template<class T>
T TempLinkedList<T>::getNextNode(){

	//cout << endl << lastRead->value << "meme" << endl;
	if (!read) {
		read = true;
		lastRead = head;
	}
	else {
		lastRead = lastRead->nextNodePointer;
	}
	if (lastRead == NULL) {
		read = false;
		return NULL;
	}
	else{
		return lastRead->value;
	}
}

template <class T>
void TempLinkedList<T>::readReset(){
	read = false;
}

template <class T>
void TempLinkedList<T>::emptify(){
	head = NULL;
}

template<class T>
void TempLinkedList<T>::displayList(){
	Node *nodePtr1;  // To move through the list

	// Position nodePtr at the head of the list.
	nodePtr1 = head;

	// While nodePtr points to a node, traverse
	// the list.
	while (nodePtr1)
	{
		// Display the value in this node.
		cout << nodePtr1->value << endl;

		// Move to the next node.
		nodePtr1 = nodePtr1->nextNodePointer;
	}
}



