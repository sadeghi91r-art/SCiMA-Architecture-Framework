
module BufferDepth
  #(parameter Size =128, Width=16)
  (clk, rst, zeroing, write, read, FullEmpty, Din, Dout, UsedDepth);
  
  input clk, rst, write, read;
  output FullEmpty;
  input [(Width-1):0] Din;
  output [(Width-1):0] Dout;
  input [($clog2(Size)-1):0] UsedDepth;
  
  logic [($clog2(Size)-1):0] count_reg;
  logic  [(Width-1):0] RegO [0:(Size-1)];
  

  
  always @(posedge clk) begin // writing 
	if (zeroing | rst) begin
		for (int i=0; i<Size; i=i+1) begin
			RegO[i] = 0;
		end
	end
	else if (write) begin
		RegO[count_reg] = Din;
	end
  end
  
  assign Dout = RegO [count_reg]; // reading 
  
   always@(posedge clk) begin // Poninter
    if(rst | zeroing) count_reg<=0;
    else if ((read||write)) count_reg <= count_reg + 1;
  end
  assign FullEmpty= (count_reg==UsedDepth);
  /*
  integer i;
  always @(posedge FullEmpty) begin
	for (i = 0 ; i<8; i=i+1) begin
		$display("Address(%d)->Data(%d) at %t", i, $signed(RegO[i]), $time );
	end 
  end
 */
  
endmodule
  
  module BufferTester
  #(parameter Size =128, Width=16)();
  
  logic clk=0, rst, write, read;
  wire FullEmpty;
  logic [(Width-1):0] Din;
  wire  [(Width-1):0] Dout;
  
  Buffer #(Size, Width) BufferUT(clk, rst, write, read, FullEmpty, Din, Dout);
  
  always #17 clk=~clk;
  initial begin
    rst =1;
    #27;
    rst =0;
    #27;
    write = 1;
    for (int i=0; i<Size-1; i=i+1) begin
      Din = i;
      #34;
    end
    #38;
    write = 0;
     #138;
    read = 1;
    
  end
  endmodule
  
  