module LayerTeser 
#(parameter XB_size=128, DataWidth=8,WeightWidth=8,  BitsApplied=2,BitsPerCell=2,
  VDD=3, HighResistance=10**6,LowResistance=10**3, NumclockTimer = 10, NumclockADC = 5, WidthTimer = 4, WidthADC = 4,
  mv = 2, nv=2, rowBatch=6, colBatch=6, depBatch=28,
  rowFltr=3, colFltr=3)
  ();
  
  
  
  logic clk=0, rst;
  logic [1:0] ReqLeft, AckRight;
  wire  [1:0] AckLeft, ReqRight;
  logic [1:0] ReqUp, AckDown;
  wire  [1:0] AckUp, ReqDown;
  
  logic  [(DataWidth-1):0]  Din_left_1_1=1, Din_left_2_1=1,Din_up_1_1=0, Din_up_1_2=0;
  wire [(DataWidth-1):0] Dout_right_1_2, Dout_right_2_2, Dout_down_2_1, Dout_down_2_2;
  wire [(DataWidth-1):0] Dout_right_1_1, Dout_down_1_1, Dout_right_2_1, Dout_down_1_2;
  
  
  logic ReqLeft_1_1=1, ReqLeft_2_1=1;
  wire  AckLeft_1_1, AckLeft_2_1;
  
  wire ReqUp_1_1, AckUp_1_1;
  wire ReqUp_1_2, AckUp_1_2;
  wire ReqRight_1_2, AckRight_1_2;
  wire ReqRight_2_2, AckRight_2_2;
  wire ReqDown_2_1, AckDown_2_1;
  wire ReqDown_2_2, AckDown_2_2;
  
  
  wire ReqRight_1_1, ReqDown_1_1, ReqRight_2_1, ReqDown_1_2;
  wire AckRight_1_1, AckDown_1_1, AckRight_2_1, AckDown_1_2;
  
  
   always #17 clk=~clk;

  Cluster 
#(XB_size, DataWidth, WeightWidth,  BitsApplied, BitsPerCell, VDD, HighResistance,LowResistance,
NumclockTimer, NumclockADC, WidthTimer, WidthADC, mv, nv, rowBatch, colBatch, depBatch, rowFltr, colFltr)
  ClusterInst_1_1 (clk, rst, ReqLeft_1_1, AckLeft_1_1, ReqRight_1_1, AckRight_1_1, ReqUp_1_1, AckUp_1_1,
  ReqDown_1_1, AckDown_1_1, Din_left_1_1, Din_up_1_1, Dout_right_1_1, Dout_down_1_1);
  
  Cluster 
#(XB_size, DataWidth, WeightWidth,  BitsApplied, BitsPerCell, VDD, HighResistance,LowResistance,
NumclockTimer, NumclockADC, WidthTimer, WidthADC, mv, nv, rowBatch, colBatch, depBatch, rowFltr, colFltr)
  ClusterInst_1_2 (clk, rst, ReqRight_1_1, AckRight_1_1, ReqRight_1_2, AckRight_1_2, ReqUp_1_2, AckUp_1_2,
  ReqDown_1_2, AckDown_1_2, Dout_right_1_1, Din_up_1_2, Dout_right_1_2, Dout_down_1_2);
  
  Cluster 
#(XB_size, DataWidth, WeightWidth,  BitsApplied, BitsPerCell, VDD, HighResistance,LowResistance,
NumclockTimer, NumclockADC, WidthTimer, WidthADC, mv, nv, rowBatch, colBatch, depBatch, rowFltr, colFltr)
  ClusterInst_2_1 (clk, rst, ReqLeft_2_1, AckLeft_2_1, ReqRight_2_1, AckRight_2_1, ReqDown_1_1, AckDown_1_1,
  ReqDown_2_1, AckDown_2_1, Din_left_2_1, Dout_down_1_1, Dout_right_2_1, Dout_down_2_1);
  
  Cluster 
#(XB_size, DataWidth, WeightWidth,  BitsApplied, BitsPerCell, VDD, HighResistance,LowResistance,
NumclockTimer, NumclockADC, WidthTimer, WidthADC, mv, nv, rowBatch, colBatch, depBatch, rowFltr, colFltr)
  ClusterInst_2_2 (clk, rst, ReqRight_2_1, AckRight_2_1, ReqRight_2_2, AckRight_2_2, ReqDown_1_2, AckDown_1_2,
  ReqDown_2_2, AckDown_2_2, Dout_right_2_1, Dout_down_1_2, Dout_right_2_2, Dout_down_2_2);

Requesting Requesting_up_1_1 (clk, ReqUp_1_1, AckUp_1_1);
Requesting Requesting_up_1_2 (clk, ReqUp_1_2, AckUp_1_2);
Acking Acking_right_1_2 (clk, ReqRight_1_2, AckRight_1_2);
Acking Acking_right_2_2 (clk, ReqRight_2_2, AckRight_2_2);
Acking Acking_down_2_1 (clk, ReqDown_2_1, AckDown_2_1);
Acking Acking_down_2_2 (clk, ReqDown_2_2, AckDown_2_2);

genvar i, j;	

generate
for (i = 0; i< mv; i=i+1) begin
	for (j = 0; j< nv; j=j+1) begin
		//ReqAckRegister #("left_right", "VMM", i+1, j+1) recorderLR (ClusterInst.ClusDP.VMMArray.Req_right_left[i][j], ClusterInst.ClusDP.VMMArray.Ack_right_left[i][j] );
		//ReqAckRegister #("up_down", "VMM", i+1, j+1) recorderUD (ClusterInst.ClusDP.VMMArray.Req_up_down[i][j], ClusterInst.ClusDP.VMMArray.Ack_up_down[i][j] );
		Recorder #("Cluster(1,1) VMM ", i, j) Monitor_1_1 (
		ClusterInst_1_1.ClusDP.VMMArray.Req_right_left[i][j],
		ClusterInst_1_1.ClusDP.VMMArray.Ack_right_left[i][j],
		ClusterInst_1_1.ClusDP.VMMArray.Req_right_left[i][j+1],
		ClusterInst_1_1.ClusDP.VMMArray.Ack_right_left[i][j+1],
		ClusterInst_1_1.ClusDP.VMMArray.Req_up_down[i][j],
		ClusterInst_1_1.ClusDP.VMMArray.Ack_up_down[i][j],
		ClusterInst_1_1.ClusDP.VMMArray.Req_up_down[i+1][j],
		ClusterInst_1_1.ClusDP.VMMArray.Ack_up_down[i+1][j]);
		
		Recorder #("Cluster(1,2) VMM ", i, j) Monitor_1_2 (
		ClusterInst_1_2.ClusDP.VMMArray.Req_right_left[i][j],
		ClusterInst_1_2.ClusDP.VMMArray.Ack_right_left[i][j],
		ClusterInst_1_2.ClusDP.VMMArray.Req_right_left[i][j+1],
		ClusterInst_1_2.ClusDP.VMMArray.Ack_right_left[i][j+1],
		ClusterInst_1_2.ClusDP.VMMArray.Req_up_down[i][j],
		ClusterInst_1_2.ClusDP.VMMArray.Ack_up_down[i][j],
		ClusterInst_1_2.ClusDP.VMMArray.Req_up_down[i+1][j],
		ClusterInst_1_2.ClusDP.VMMArray.Ack_up_down[i+1][j]);
		
		Recorder #("Cluster(2,1) VMM ", i, j) Monitor_2_1 (
		ClusterInst_2_1.ClusDP.VMMArray.Req_right_left[i][j],
		ClusterInst_2_1.ClusDP.VMMArray.Ack_right_left[i][j],
		ClusterInst_2_1.ClusDP.VMMArray.Req_right_left[i][j+1],
		ClusterInst_2_1.ClusDP.VMMArray.Ack_right_left[i][j+1],
		ClusterInst_2_1.ClusDP.VMMArray.Req_up_down[i][j],
		ClusterInst_2_1.ClusDP.VMMArray.Ack_up_down[i][j],
		ClusterInst_2_1.ClusDP.VMMArray.Req_up_down[i+1][j],
		ClusterInst_2_1.ClusDP.VMMArray.Ack_up_down[i+1][j]);
		
		Recorder #("Cluster(2,2) VMM ", i, j) Monitor_2_2 (
		ClusterInst_2_2.ClusDP.VMMArray.Req_right_left[i][j],
		ClusterInst_2_2.ClusDP.VMMArray.Ack_right_left[i][j],
		ClusterInst_2_2.ClusDP.VMMArray.Req_right_left[i][j+1],
		ClusterInst_2_2.ClusDP.VMMArray.Ack_right_left[i][j+1],
		ClusterInst_2_2.ClusDP.VMMArray.Req_up_down[i][j],
		ClusterInst_2_2.ClusDP.VMMArray.Ack_up_down[i][j],
		ClusterInst_2_2.ClusDP.VMMArray.Req_up_down[i+1][j],
		ClusterInst_2_2.ClusDP.VMMArray.Ack_up_down[i+1][j]);
	end
end
endgenerate	 
 
ReqAckRegister #("************Left", "Cluster_1_1", 0, 0)  recorderL_1_1 (ReqLeft_1_1, AckLeft_1_1);
ReqAckRegister #("************Up", "Cluster_1_1", 0, 0)    recorderU_1_1 (ReqUp_1_1, AckUp_1_1 );
ReqAckRegister #("************Right", "Cluster_1_1", 0, 0) recorderR_1_1 (ReqRight_1_1, AckRight_1_1);
ReqAckRegister #("************Down", "Cluster_1_1", 0, 0) recorderD_1_1 (ReqDown_1_1, AckDown_1_1);

ReqAckRegister #("************Left", "Cluster_1_2", 0, 0)  recorderL_1_2 (ReqLeft_1_2, AckLeft_1_2);
ReqAckRegister #("************Up", "Cluster_1_2", 0, 0)    recorderU_1_2 (ReqUp_1_2, AckUp_1_2 );
ReqAckRegister #("************Right", "Cluster_1_2", 0, 0) recorderR_1_2 (ReqRight_1_2, AckRight_1_2);
ReqAckRegister #("************Down", "Cluster_1_2", 0, 0) recorderD_1_2 (ReqDown_1_2, AckDown_1_2);

ReqAckRegister #("************Left", "Cluster_2_1", 0, 0)  recorderL_2_1 (ReqLeft_2_1, AckLeft_2_1);
ReqAckRegister #("************Up", "Cluster_2_1", 0, 0)    recorderU_2_1 (ReqUp_2_1, AckUp_2_1 );
ReqAckRegister #("************Right", "Cluster_2_1", 0, 0) recorderR_2_1 (ReqRight_2_1, AckRight_2_1);
ReqAckRegister #("************Down", "Cluster_2_1", 0, 0) recorderD_2_1 (ReqDown_2_1, AckDown_2_1);

ReqAckRegister #("************Left", "Cluster_2_2", 0, 0)  recorderL_2_2 (ReqLeft_2_2, AckLeft_2_2);
ReqAckRegister #("************Up", "Cluster_2_2", 0, 0)    recorderU_2_2 (ReqUp_2_2, AckUp_2_2 );
ReqAckRegister #("************Right", "Cluster_2_2", 0, 0) recorderR_2_2 (ReqRight_2_2, AckRight_2_2);
ReqAckRegister #("************Down", "Cluster_2_2", 0, 0) recorderD_2_2 (ReqDown_2_2, AckDown_2_2);

	
   initial begin
		rst =1;
		#170 rst=0;
	end
	
  initial begin
	ReqLeft_1_1 = 0;
	#500;
	ReqLeft_1_1 = 1;
	@(posedge AckLeft_1_1);
	#170;
	ReqLeft_1_1 = 0;
	#34000;
	
	ReqLeft_2_1 = 0;
	#170;
	ReqLeft_2_1 = 1;
	@(posedge AckLeft_2_1);
	#170;
	ReqLeft_2_1 = 0;
  end
  


  endmodule 
  
