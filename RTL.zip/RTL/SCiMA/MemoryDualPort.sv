module Memory 
  #(Size, Width)
  (clk, rst, 
  Din1, AW1, AR1, Dout1, read1, write1,
  Din2, AW2, AR2, Dout2, read2, write2,
);
  
  input [(Width-1):0] Din1, Din2;
  input [($clog2(Size)):0] AW1, AW2, AR1, AR2;
  output logic [(Width-1):0] Dout1, Dout2;
  input clk, rst, read1, write1, read2, write2;
  
  logic [(Width-1):0] Mem [(Size-1):0];
  integer i;
  
  initial begin
    for (int k=0; k<Size; k=k+1) begin
        Mem[k] = 0;
      end
  end
  
  assign Dout1=read1?Mem[AR1]:0;
  assign Dout2=read2?Mem[AR2]:0;

  
  always@(posedge clk) begin
    if(rst) for (i=0; i<Size; i=i+1) Mem[i] <= 0;
    else begin
		if(write1) Mem[AW1] <= Din1;
		if(write2) Mem[AW2] <= Din2;
    end
  end
  
endmodule
