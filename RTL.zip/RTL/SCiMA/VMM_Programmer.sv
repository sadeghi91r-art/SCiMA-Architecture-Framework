
module VMM_progrmmer #(DataWidth=16, y=1)
  (clk, rst, ReqLeft, AckLeft, ReqRight, AckRight, Prog, ProgDataIn, ProgDataOut, LIF, RIF, UIF, DIF);
  
  input clk, rst;
  input ReqLeft, AckRight;
  output AckLeft, ReqRight;
  output Prog, LIF, RIF, UIF, DIF;
  output [DataWidth-1:0] ProgDataOut;
  input [DataWidth-1:0] ProgDataIn;
 
	//ProgData=[x:2, y:2, LIF, RIF, UIF, DIF]
 logic [3:0] ns, ps;
  parameter Idle=0, GiveAckLeft=1, WaitForData=2,
  GetProg=3,
  GiveReqRight=5, ReqInAc=5, GiveProg=6, SetProg=7;
    
    always@(ps,ReqLeft) begin : GetIFM_Send
      ns=Idle;
      case(ps)
        Idle: begin
          if(ReqLeft==1'b1) ns=GiveAckLeft;
          else ns= Idle;
        end
        GiveAckLeft: begin
          if (ReqLeft==1'b0) ns=WaitForData;
          else ns= GiveAckLeft;
        end
        WaitForData: begin
          ns= GetProgIn;   //generate Address
        end
        GetProg: begin
          if(ProgDataIn[13:12]!=y) ns= GiveReqRight;
          else ns = SetProg;
        end
        GiveReqRight: begin
          if(AckRight==1'b1) ns = ReqInAc;
		  else ns=GiveReqRight;
        end
		ReqInAc: begin
          if(AckRight==1'b0) ns = GiveProg;
		  else ns=ReqInAc;
        end
		GiveProg: begin
          ns=Idle;
        end
		SetProg: begin
			ns = Idle;
		end
        default : begin
          ns = Idle;
        end
      endcase
    end
    
always @(posedge clk) begin 
	if (rst) begin
	ps <= 0; Prog<=0; LIF<=0; RIF<=0; UIF<=0; DIF<=0;
	end
	else begin
	ps <= ns;
	if (ps==SetProg) {Prog, LIF, RIF, UIF, DIF}<={1, ProgDataIn[11], ProgDataIn[10], ProgDataIn[9], ProgDataIn[8]};
	end
end


assign ProgDataOut=ProgDataIn;
endmodule
