module VMM_Array
#(parameter XB_size=128, DataWidth=16,WeightWidth=8, SliceWidth=2,CellBits=2,
	real DACmax=3,parameter ADCresolution=11, real Hcond=10**-9, real Lcond=0, parameter SRIF_ADC_delay = 10,
	mv = 4, nv=4, mav = 2, nav=2,
	 Tix=1, Tiy=1,Cix=1,Ciy=1)
	(clk, rst, ReqLeft, AckLeft, ReqDown, AckDown, DataLeft, DataDown);

  
input clk, rst;
input  [(DataWidth-1):0] DataLeft    [0:mv-1];
output [(DataWidth-1):0] DataDown    [0:nv-1];

input  ReqLeft     [0:mv-1];
output AckLeft     [0:mv-1];
input  AckDown    [0:nv-1];
output ReqDown    [0:nv-1];

wire Req_right_left [0:mv-1][0:nv];
wire Req_up_down    [0:mv][0:nv-1];
wire Ack_right_left [0:mv-1][0:nv];
wire Ack_up_down    [0:mv][0:nv-1];

wire [(DataWidth-1):0] Data_right_left    [0:mv-1][0:nv];
wire [(DataWidth-1):0] Data_up_down       [0:mv][0:nv-1];


genvar i, j;
generate
for (i = 0; i< mv; i=i+1) begin: rowvmms
	for (j = 0; j< nv; j=j+1) begin	: colvmms
		VMM #( XB_size,DataWidth,WeightWidth, SliceWidth,CellBits, DACmax, ADCresolution, Hcond, Lcond, 
		   SRIF_ADC_delay, ((i<mav)&&(j<nav)), ((i<mav)&&(j<nav-1)), ((i!=0)&&(j<nav)), ((j<nav)),
		   Tix, Tiy, Cix, Ciy, (i+1), (j+1)) VMMInst
		   (clk, rst,Req_right_left[i][j], Ack_right_left[i][j], Req_right_left[i][j+1], Ack_right_left[i][j+1],
		   Req_up_down[i][j], Ack_up_down[i][j], Req_up_down[i+1][j], Ack_up_down[i+1][j],
		   Data_right_left[i][j], Data_up_down[i][j], Data_right_left[i][j+1], Data_up_down[i+1][j]);
		   
	end
 end
endgenerate

generate
for (i = 0; i< mv; i=i+1) begin
	assign Data_right_left[i][0] =DataLeft[i];
	//Acking Acking_right (clk, Req_right_left[i][nv], Ack_right_left[i][nv]);
	assign Req_right_left[i][0] = ReqLeft[i];
	assign AckLeft[i]=Ack_right_left[i][0];
 end
endgenerate

generate
for (j = 0; j< nv; j=j+1) begin
  assign Data_up_down[0][j] = 0;
	assign DataDown[j] = Data_up_down[mv][j] ;
	//Requesting Requesting_up (clk, Req_up_down[0][j], Ack_up_down[0][j]);
	assign Ack_up_down[mv][j] = AckDown[j];
	assign ReqDown[j]         = Req_up_down[mv][j];
 end
endgenerate

endmodule