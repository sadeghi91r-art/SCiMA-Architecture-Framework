module ClusIFMContrConv  
  #(parameter mv=2, H=5, W=32, C=6, r=3, s=3, stride = 1, XBsize = 128, LIF=1, RIF=1)
  (clk, rst, write, read, AddIFM, ReqVMM, AckVMM, ReqLeft, AckLeft, ReqRight, AckRight, EnDataRight,
  zeroing, rstsum, loadSum, sendsum1, sendsum2);
  
  parameter IMA_IFM_size = H*W*C;
  
  input clk, rst;
  output write, read;
  output [$clog2(IMA_IFM_size):0] AddIFM;
  output logic ReqVMM [0:(mv-1)];
  input  AckVMM [0:(mv-1)];
  input ReqLeft, AckRight;
  output AckLeft, ReqRight, EnDataRight;
  output zeroing, rstsum, loadSum, sendsum1, sendsum2;
  
	parameter ChPerVMM = XBsize / (r*s);
	parameter mav = (C-1) / ChPerVMM;
	
	parameter RowMax        = H - r;
	parameter ColMax        = W - s;
	parameter ZeroData = XBsize - (r*s*ChPerVMM);

	parameter Addres_Width = $clog2(IMA_IFM_size);
  
	wire [$clog2(RowMax):0]   		RowIndx;
	wire [$clog2(ColMax):0]   		ColIndx;
	wire [$clog2(mav):0]       	VMMIndx;
	wire [$clog2(r-1):0]        	winx;
	wire [$clog2(s-1):0]        	winy;
	wire [$clog2(ChPerVMM-1):0] 	winz;
	
	wire [$clog2(ZeroData):0] ZeroCount;

	wire cowx, cowy, cowp, coxf, coyf, cozf;
	wire selAddD, selAddT, enAddTGen, coaddTgen;
	wire encntrz, initcz, cozero;
	wire sendbatch, sendwindow, sendsegment, sendxz;
	wire OutCh, givereqvmms;
 
	wire [Addres_Width:0] AddDistribute, AddTransfer;
	
	wire  [0:(mv-1)] vecAckVMM;
	genvar i;
	generate
		for ( i = 0; i< mv; i++) begin
		assign vecAckVMM[i] = AckVMM[i];
		end
	endgenerate

  logic [ 4:0] ns, ps;
  
  parameter Idle=0, GiveAckLeft=1, WaitForData=2,
  IFMBurst=3, StartingP=4, StartingN=5,
  GiveReqRight=6, ReqInAc=7, waiting=8, sendIFM=9, DoneSendIFM=10, ReqVMMs = 11,
  ReqVMMDeac = 12, Waiting1 = 13, SendRowData=14, gotonextvmm = 15, checkdonedistribution =16,
  Restart = 17, sendzeros=18, sends1 = 19, sends2 = 20;
    
    always@(ps,ReqLeft, vecAckVMM,coaddTgen, AckRight, sendsegment, cozero,
			sendwindow, sendbatch, cowx) begin : GetIFM_Send
      ns=Idle;
      case(ps)
        Idle: begin
          if(LIF==1 && ReqLeft==1'b1) ns=GiveAckLeft;
          else ns= Idle;
        end
        GiveAckLeft: begin
          if (ReqLeft==1'b0) ns=WaitForData;
          else ns= GiveAckLeft;
        end
        WaitForData: begin
          ns= IFMBurst;   //generate Address
        end
        IFMBurst: begin
          if(coaddTgen) begin
			if (RIF==1) ns= GiveReqRight; // co->empty
			else ns = ReqVMMs;
		  end
          else ns = IFMBurst;
        end
        GiveReqRight: begin
          if(AckRight==1'b1) ns = ReqInAc;
		  else ns=GiveReqRight;
        end
		ReqInAc: begin
          if(AckRight==1'b0) ns = sendIFM;
		  else ns=ReqInAc;
        end
		waiting: begin
          ns=sendIFM;
        end
		sendIFM: begin
          if(coaddTgen) ns = ReqVMMs; // genrate address  //check co
		  else ns=sendIFM;
        end
		ReqVMMs: begin
          if(AckVMM[VMMIndx]==1'b1) ns = ReqVMMDeac;
		  else ns=ReqVMMs;
        end
		ReqVMMDeac: begin
          if(AckVMM[VMMIndx]==1'b0) ns = SendRowData;
		  else ns=ReqVMMDeac;
        end
		Waiting1: begin
          ns=SendRowData;
        end
		SendRowData: begin
          if(sendsegment) ns = sendzeros;
		  else ns=SendRowData;
        end
		sendzeros: begin
          if(cozero) ns = gotonextvmm;
		  else ns=sendzeros;
        end
		sends1 : begin
			ns=sends2;
		end
		sends2: begin
			ns=gotonextvmm;
		end
		gotonextvmm: begin
			if (sendwindow) ns = checkdonedistribution;
			else ns = ReqVMMs;
        end
		checkdonedistribution: begin
			if (sendbatch & cowx) ns = Restart;
			else ns = ReqVMMs;
        end
		Restart: begin
			ns = Idle;
        end
        default : begin
          ns = Idle;
        end
      endcase
    end
    
    always @(posedge clk) begin 
if (rst) ps <= 0;
else ps <= ns;
end

 assign AddDistribute = (VMMIndx * ChPerVMM + winz) + (winx + RowIndx) * C * W + (winy + ColIndx) * C;
 
 assign AddIFM = selAddD ? AddDistribute : selAddT ? AddTransfer : 0;
 
 //--------------Generate Signals-----------------------------------
 assign sendsegment = cozf & coxf & coyf;
 assign sendwindow = cozf & coxf & coyf & cowp;
 assign sendbatch  = cowy & cozf & coxf & coyf & cowp;
 assign sendxz = coxf & cozf;
 
 assign write       = (ps == IFMBurst);
 assign read        = (ps == sendIFM) || (ps == SendRowData);
 assign AckLeft     = (ps == GiveAckLeft);
 assign ReqRight    = (ps == GiveReqRight);
 assign EnDataRight = (ps == sendIFM);
 assign enAddTGen   = (ps == IFMBurst) || (ps ==sendIFM);
 assign selAddD     = (ps == SendRowData);
 assign selAddT     = (ps == sendIFM || IFMBurst);
 assign encntr      = ((ps == SendRowData) && (~(sendbatch & cowx)) )|| (ps == Restart);
 assign cnt         = (ps == SendRowData);
 assign initc       = (ps == WaitForData)|| (ps == Waiting1)|| (ps == Restart);
 assign encntrz = (ps == sendzeros);
 assign  initcz = (ps == gotonextvmm);
 assign zeroing = (ps == sendzeros) || ((ps == SendRowData) && OutCh);
 assign OutCh = (VMMIndx * ChPerVMM + winz) >= C;
 
 assign  rstsum   = (ps == ReqVMMs);
 assign  loadSum  = (ps == SendRowData);
 assign  sendsum1 = (ps == sends1);
 assign  sendsum2 = (ps == sends2);
 assign givereqvmms = (ps == ReqVMMs);
 //------------------------------------------------------------------
 
 //------------Decoder ---------------
 always @(*) begin
 for (int i =0; i<mv; i=i+1) ReqVMM[i] = 0;
	if(givereqvmms) begin
		ReqVMM [VMMIndx] = 1;
	end
 end
// ------------------------------------------------
 
 // ----------------------Indexing Counters------------------------------------------------
CounterMax #($clog2(RowMax)+1    , RowMax   	) CounterRow  (clk, rst, encntr, initc, sendbatch, RowIndx, cowx);
CounterMax #($clog2(ColMax)+1    , ColMax   	) CounterCol  (clk, rst, encntr, initc, sendwindow, ColIndx, cowy);
CounterMax #($clog2(mav)+1     , (mav)  	    ) CounterVMM  (clk, rst, encntr, initc, sendsegment, VMMIndx, cowp);
CounterMax #($clog2(s-1)+1       , (s-1)     	) CounterWiny (clk, rst, encntr, initc, sendxz, winy, coyf);
CounterMax #($clog2(r-1)+1       , (r-1)     	) CounterWinx (clk, rst, encntr, initc, cozf, winx, coxf);
CounterMax #($clog2(ChPerVMM-1)+1, (ChPerVMM-1) ) CounterWinz (clk, rst, encntr, initc, cnt,  winz, cozf);
//------------------------------------------------------------------------------------------

// ------------------------Zeroing Counter---------------------------------------------------
CounterMax #($clog2(ZeroData)+1   , ZeroData ) CounterZero     (clk, rst, encntrz, initcz, encntrz,  ZeroCount, cozero);
//--------------------------------------------------------------------------------------------
// ------------------------Address of Data---------------------------------------------------
 CounterMax #(Addres_Width+1, IMA_IFM_size) CounterAddGen	(clk, rst, enAddTGen, initc, enAddTGen, AddTransfer, coaddTgen);
//---------------------------------------------------------------------------------------------
endmodule
