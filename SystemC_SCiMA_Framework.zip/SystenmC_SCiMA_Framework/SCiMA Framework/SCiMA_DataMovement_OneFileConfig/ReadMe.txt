This project does not include the funtionality of the memristor too.
It is only for extracting timing characteristics of the hardware.
for all tiles, a file is generated which includes all configurations of tiles.
I use one file, because when there is one file for each file, SystemC terminates when running large applications.
There is a corresponding compiler in python which when configuring tiles.
