module ClusOFMController  
  #(parameter nv=4, KPU=8, K=20, N=20, LIF = 1, UIF=1, DIF=1)
  (clk, rst, write, read, AddOFM, ReqVMM, AckVMM, ReqUp, AckUp, ReqDown, AckDown, selData, selVMM, enOFMDown);
  
  parameter ClusOFMsize = K * N;
  parameter nav = (K-1)/KPU;
  
  input clk, rst;
  output write, read;
  input ReqVMM [0:(nv-1)];
  output logic  AckVMM [0:(nv-1)];
  output [$clog2(ClusOFMsize):0] AddOFM;
  input ReqUp, AckDown;
  output AckUp, ReqDown;
  output selData;
  output [$clog2(nv):0] selVMM;
  output enOFMDown;
  
  wire [$clog2(N-1):0]   		IndxN;
  wire [$clog2(nv):0]   		IndxVMM;
  wire [$clog2(KPU-1):0]   		IndxKrnl;
  wire encKA, intKA, cnt, coN, coVMM, coKPU;
  
  wire [$clog2(ClusOFMsize):0] AddBurst, AddGDV;  
  wire coAB, enAB, intAB, OOR;
  wire giveackVMMs, endK;
 
 
   logic [ 4:0] ns, ps;
  
  assign selVMM = IndxVMM;
  
  wire  [0:(nv-1)] vecReqVMM;
	genvar i;
	generate
		for ( i = 0; i< nv; i++) begin
		assign vecReqVMM[i] = ReqVMM[i];
		end
	endgenerate
  
  parameter Idle=0, GiveAckVMM=1, CompHandShake1=2,
  GetOFMVMM=3, CheckEndVMMs=4, GetOFM=5,
  GiveAckUp=6, CompHandShake2=7, OFMBurstGet=8, GiveReqDown=9, ReqInAc=10, waiting = 11,
  sendOFM = 12, Restart = 13;
  
  
  always@(ps, coKPU, endK, vecReqVMM, coN, ReqUp, coAB, AckDown) begin : OFMHandling
      ns=Idle;
	  case(ps)
        Idle: begin
		if (LIF == 1) 
          if(ReqVMM[selVMM] ==1'b1) ns=GiveAckVMM;
          else ns= Idle;
		 else ns=GetOFM;
        end
		GiveAckVMM: begin
          if(ReqVMM[selVMM] ==1'b0) ns=CompHandShake1;
          else ns= GiveAckVMM;
        end
		CompHandShake1: begin
          ns= GetOFMVMM;
        end
		GetOFMVMM: begin
          if(coKPU) ns= CheckEndVMMs; // co->empty
          else ns = GetOFMVMM;
        end
		CheckEndVMMs: begin
          if(endK & coN) ns= GetOFM; // co->empty
          else ns = Idle;
        end
		GetOFM: begin
			if (UIF ==1)
				if(ReqUp==1'b1) ns=GiveAckUp;
				else ns= GetOFM;
			else ns=GiveReqDown;
        end
		GiveAckUp: begin
          if(ReqUp==1'b0) ns=CompHandShake2;
          else ns= GiveAckUp;
        end
		CompHandShake2: begin
          ns= OFMBurstGet;
        end
		OFMBurstGet: begin
          if(coAB) ns= GiveReqDown; // co->empty
          else ns = OFMBurstGet;
        end
		GiveReqDown: begin
		if (DIF == 1)
          if(AckDown==1'b1) ns = ReqInAc;
		  else ns=GiveReqDown;
		 else ns = Idle;
        end
		ReqInAc: begin
          if(AckDown==1'b0) ns = sendOFM;
		  else ns=ReqInAc;
        end
		waiting: begin
          ns=sendOFM;
        end
		sendOFM: begin
          if(coAB) ns = Restart; // genrate address  //check co
		  else ns=sendOFM;
        end
		Restart: begin
			ns = Idle;
        end
        default : begin
          ns = Idle;
        end
      endcase
    end

always @(posedge clk) begin 
	if (rst) ps <= 0;
	else ps <= ns;
end

//----------------Generate Signals-------------
assign AddGDV = (IndxN * K) + (IndxVMM * KPU) + IndxKrnl;
assign endK = coKPU & coVMM;
assign AddOFM = (ps == GetOFMVMM) ? AddGDV : AddBurst;
assign OOR = ((IndxVMM * KPU) + IndxKrnl)< K;

assign encKA = (ps == GetOFMVMM) && (~(endK & coN));
assign intKA = (ps == Idle);
assign cnt   = (ps == GetOFMVMM);
assign enAB     = (ps == OFMBurstGet) || (ps == sendOFM);
assign intAB    = (ps == CompHandShake2) || (ps == waiting) || (ps == Idle);
assign ReqDown  = (ps == GiveReqDown);
assign AckUp    = (ps == GiveAckUp);
assign write    = (ps == GetOFMVMM && OOR ) || (ps == OFMBurstGet);
assign read     = (ps == OFMBurstGet) || (ps == sendOFM);
assign selData  = (ps == GetOFMVMM);
assign enOFMDown= (ps == sendOFM);
assign giveackVMMs = ps == GiveAckVMM;
//-----------------------------------------------

//---------------Decoder-----------------------
always @(*) begin : Decoder 
	for (int i =0; i<nv; i=i+1) AckVMM[i] = 0;
	if(giveackVMMs) begin		
		AckVMM [selVMM] = 1;
	end

 end
 //--------------------------------------------
 
 
 //-----------------------------Indexer----------------------------
  CounterMax #($clog2(ClusOFMsize)+1, ClusOFMsize-1) counterAddOFM (clk, rst, enAB, intAB, enAB, AddBurst, coAB);
  CounterMax #($clog2(N-1)+1, N-1)     counterN      (clk, rst, encKA, intKA, endK, IndxN, coN);
  CounterMax #($clog2(nv)+1, nav)     counterVMM    (clk, rst, encKA, intKA, coKPU, IndxVMM, coVMM);
  CounterMax #($clog2(KPU-1)+1, KPU-1) counterKPU    (clk, rst, encKA, intKA, cnt, IndxKrnl, coKPU);
  //--------------------------------------------------------------
		
endmodule	
		