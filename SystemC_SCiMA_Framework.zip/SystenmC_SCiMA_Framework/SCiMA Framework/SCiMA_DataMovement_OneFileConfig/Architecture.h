
#include "BurstRouter.h"
#include "TileW.h"


template <int NOCDTR, int TmemSize, int TileDTR, int mc, int nc, int CMemSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk, int Trow, int Tcol>
SC_MODULE(Architecture)
{
#define   RowsNodes Trow
#define   ColsNodes Tcol
#define RowsRouters Trow/2
#define ColsRouters Tcol/2

	ifstream InputFile;
	string APPname;

	Router *Routers[RowsRouters][ColsRouters];
	TileW<TmemSize, TileDTR, mc, nc, CMemSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk> *Tiles[RowsNodes][ColsNodes];

	ChanelMD< NOCDTR, NOCDTR>* EastWestChan1[RowsRouters][ColsRouters + 1];
	ChanelMD< NOCDTR, NOCDTR>* EastWestChan2[RowsRouters][ColsRouters + 1];
	ChanelMD< NOCDTR, NOCDTR>* NorthSouthChan1[RowsRouters + 1][ColsRouters];
	ChanelMD< NOCDTR, NOCDTR>* NorthSouthChan2[RowsRouters + 1][ColsRouters];


	ChanelMD< TileDTR, NOCDTR>* Loc1_ChanIn[RowsNodes][ColsNodes];
	ChanelMD< TileDTR, NOCDTR>* Loc2_ChanIn[RowsNodes][ColsNodes];
	ChanelMD< TileDTR, NOCDTR>* Loc3_ChanIn[RowsNodes][ColsNodes];
	ChanelMD< TileDTR, NOCDTR>* Loc4_ChanIn[RowsNodes][ColsNodes];

	ChanelMD< NOCDTR, NOCDTR>* Loc1_ChanOut[RowsNodes][ColsNodes];
	ChanelMD< NOCDTR, NOCDTR>* Loc2_ChanOut[RowsNodes][ColsNodes];
	ChanelMD< NOCDTR, NOCDTR>* Loc3_ChanOut[RowsNodes][ColsNodes];
	ChanelMD< NOCDTR, NOCDTR>* Loc4_ChanOut[RowsNodes][ColsNodes];

	sc_export<Pburst_write_if> InjectInput;
	sc_export<Pburst_read_if> ReceiverOutput;
	/*
	sc_export<burst_write_if> LeftLiterals1[RowsRouters];
	sc_export<burst_read_if>  LeftLiterals2[RowsRouters];
	sc_export<burst_write_if> UpLiterals1[ColsRouters];
	sc_export<burst_read_if>  UpLiterals2[ColsRouters];
	sc_export<burst_read_if> RightLiterals1[RowsRouters];
	sc_export<burst_write_if>  RightLiterals2[RowsRouters];
	sc_export<burst_read_if> DownLiterals1[ColsRouters];
	sc_export<burst_write_if>  DownLiterals2[ColsRouters];
	*/

	int count = 0;
	Architecture(sc_module_name name, string APPname_) :sc_module(name)
	{
		string inputFileName = APPname_ + "\\inputInjector.txt";
		InputFile.open(inputFileName);
		APPname = APPname_;
		cout << "Instantiations" << endl;
		for (int i = 0; i < RowsNodes; i++)
		for (int j = 0; j < ColsNodes; j++){
			TileConfig config = ReadConfigs(i*ColsNodes + j, APPname);
			Tiles[i][j] = new TileW< TmemSize, TileDTR, mc, nc, CMemSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>
				(config.name.c_str(), config.C, config.r, config.s, config.K, config.Strd, config.COMP, config.Activation,
				config.PoolSize, config.NFC, config.Hd, config.Wd, config.TileWeight, config.PartialSum, config.TileID,
				config.inputConfig, config.outputConfig, config.partialConfig, config.InputConfigSize, config.OutputConfigSize,
				config.PartialConfigSize);
		}
		for (int i = 0; i < RowsRouters; i++)
		for (int j = 0; j < ColsRouters; j++){
			string namemodule = "Node__" + to_string(i) + "__" + to_string(j);
			Routers[i][j] = new Router(namemodule.c_str(), i, j, RowsNodes, ColsNodes);
		}

		for (int i = 0; i < RowsRouters; i++)
		for (int j = 0; j < ColsRouters + 1; j++){
			string namemodule = "EastWestChan1__" + to_string(i) + "__" + to_string(j);
			EastWestChan1[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule.c_str());
			namemodule = "EastWestChan2__" + to_string(i) + "__" + to_string(j);
			EastWestChan2[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule.c_str());
		}

		for (int i = 0; i < RowsRouters + 1; i++)
		for (int j = 0; j < ColsRouters; j++){
			string namemodule = "NorthSouthChan1__" + to_string(i) + "__" + to_string(j);
			NorthSouthChan1[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule.c_str());
			namemodule = "NorthSouthChan2__" + to_string(i) + "__" + to_string(j);
			NorthSouthChan2[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule.c_str());
		}

		for (int i = 0; i < RowsNodes; i++)
		for (int j = 0; j < ColsNodes; j++){
			string namemodule = "Loc1_ChanIn__" + to_string(i) + "__" + to_string(j);
			Loc1_ChanIn[i][j] = new ChanelMD<TileDTR, NOCDTR>(namemodule.c_str());
			string namemodule1 = "Loc2_ChanIn__" + to_string(i) + "__" + to_string(j);
			Loc2_ChanIn[i][j] = new ChanelMD<TileDTR, NOCDTR>(namemodule1.c_str());
			string namemodule2 = "Loc3_ChanIn__" + to_string(i) + "__" + to_string(j);
			Loc3_ChanIn[i][j] = new ChanelMD<TileDTR, NOCDTR>(namemodule2.c_str());
			string namemodule3 = "Loc4_ChanIn__" + to_string(i) + "__" + to_string(j);
			Loc4_ChanIn[i][j] = new ChanelMD<TileDTR, NOCDTR>(namemodule3.c_str());
			string namemodule4 = "Loc1_ChanOut__" + to_string(i) + "__" + to_string(j);
			Loc1_ChanOut[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule4.c_str());
			string namemodule5 = "Loc2_ChanOut__" + to_string(i) + "__" + to_string(j);
			Loc2_ChanOut[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule5.c_str());
			string namemodule6 = "Loc3_ChanOut__" + to_string(i) + "__" + to_string(j);
			Loc3_ChanOut[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule6.c_str());
			string namemodule7 = "Loc4_ChanOut__" + to_string(i) + "__" + to_string(j);
			Loc4_ChanOut[i][j] = new ChanelMD<NOCDTR, NOCDTR>(namemodule7.c_str());
		}

		InjectInput(*EastWestChan1[0][0]);
		ReceiverOutput(*NorthSouthChan1[RowsRouters][ColsRouters-1]);

		cout << "connecting Nodes to Routers" << endl;
		for (int i = 0; i < RowsNodes; i++)
		for (int j = 0; j < ColsNodes; j++){
			Tiles[i][j]->InitPort(*Loc1_ChanIn[i][j]);
			Tiles[i][j]->TargetPort(*Loc1_ChanOut[i][j]);
		}

		for (int i = 0; i < RowsRouters; i++)
		for (int j = 0; j < ColsRouters; j++){

			Routers[i][j]->Node1_In(*Loc1_ChanIn[i * 2][j * 2]);
			Routers[i][j]->Node1_Out(*Loc1_ChanOut[i * 2][j * 2]);
			Routers[i][j]->Node2_In(*Loc1_ChanIn[i * 2][j * 2 + 1]);
			Routers[i][j]->Node2_Out(*Loc1_ChanOut[i * 2][j * 2 + 1]);
			Routers[i][j]->Node3_In(*Loc1_ChanIn[i * 2 + 1][j * 2 + 1]);
			Routers[i][j]->Node3_Out(*Loc1_ChanOut[i * 2 + 1][j * 2 + 1]);
			Routers[i][j]->Node4_In(*Loc1_ChanIn[i * 2 + 1][j * 2]);
			Routers[i][j]->Node4_Out(*Loc1_ChanOut[i * 2 + 1][j * 2]);
		}
		cout << "connecting Routers to Routers" << endl;
		for (int i = 0; i < RowsRouters; i++)
		for (int j = 0; j < ColsRouters; j++){


			Routers[i][j]->WestIn(*EastWestChan1[i][j]);
			Routers[i][j]->WestOut(*EastWestChan2[i][j]);
			Routers[i][j]->NorthIn(*NorthSouthChan1[i][j]);
			Routers[i][j]->NorthOut(*NorthSouthChan2[i][j]);
			Routers[i][j]->EastIn(*EastWestChan2[i][j + 1]);
			Routers[i][j]->EastOut(*EastWestChan1[i][j + 1]);
			Routers[i][j]->SouthIn(*NorthSouthChan2[i + 1][j]);
			Routers[i][j]->SouthOut(*NorthSouthChan1[i + 1][j]);
		}
		cout << "Connecting Left Right literals" << endl;
		/*
		for (int i = 0; i < RowsRouters; i++){
		cout << i;
		LeftLiterals1[i](*EastWestChan1[i][0]);
		LeftLiterals2[i](*EastWestChan2[i][0]);
		RightLiterals1[i](*EastWestChan1[i][ColsRouters]);
		RightLiterals2[i](*EastWestChan2[i][ColsRouters]);

		}
		cout << "Connecting Up down literals" << endl;
		for (int j = 0; j < ColsRouters; j++){
		UpLiterals1[j](*NorthSouthChan1[0][j]);
		UpLiterals2[j](*NorthSouthChan2[0][j]);
		DownLiterals1[j](*NorthSouthChan1[RowsRouters][j]);
		DownLiterals2[j](*NorthSouthChan2[RowsRouters][j]);
		}
		*/
		cout << "End of constructor" << endl;
		SC_THREAD(InjectorF);
		SC_THREAD(ReceiverF);
		set_stack_size(400097152);
	}
	SC_HAS_PROCESS(Architecture);
	void InjectorF();
	void ReceiverF();
};

template <int NOCDTR, int TmemSize, int TileDTR, int mc, int nc, int CMemSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk, int Trow, int Tcol>
void Architecture< NOCDTR, TmemSize, TileDTR, mc, nc, CMemSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk, Trow, Tcol>::InjectorF(){
	string line;
	string value;
	getline(InputFile, line);
	int N = stoi(line);
	PacketBurst *PacketSendOut1 = new PacketBurst[N];
	for (int i = 0; i < N; i++){
		PacketBurst PacketSendOut = PacketSendOut1[i];
		getline(InputFile, line);
		istringstream iss(line);
		getline(iss, value, '	');
		PacketSendOut1[i].H = stoi(value);
		getline(iss, value, '	');
		PacketSendOut1[i].W = stoi(value);
		getline(iss, value, '	');
		PacketSendOut1[i].C = stoi(value);
		getline(iss, value, '	');
		PacketSendOut1[i].sourceNum = stoi(value);
		PacketSendOut1[i].DestNum.emptify();
		while (getline(iss, value, '	')){
			int x = stoi(value);
			PacketSendOut1[i].DestNum.appeand(x);
		}
		PacketSendOut1[i].DestNum.appeand(-1);
		int *data = new int[1];
		PacketSendOut1[i].data = data;
		
		wait(PacketSendOut1[i].H*PacketSendOut1[i].W*PacketSendOut1[i].C, SC_NS);
		InjectInput->burstWrite(PacketSendOut1[i]);
	}
}

template <int NOCDTR, int TmemSize, int TileDTR, int mc, int nc, int CMemSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk, int Trow, int Tcol>
void Architecture< NOCDTR, TmemSize, TileDTR, mc, nc, CMemSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk, Trow, Tcol>::ReceiverF(){
	PacketBurst packetOutput;
	while (1) packetOutput=ReceiverOutput->burstRead();
}