
#include "BurstChannel.h"

#include <iostream>
#include <fstream>
using namespace std;

SC_MODULE(Router)
{

	sc_port<Pburst_read_if> WestIn;
	sc_port<Pburst_write_if> WestOut;
	sc_port<Pburst_read_if> NorthIn;
	sc_port<Pburst_write_if> NorthOut;
	sc_port<Pburst_read_if> EastIn;
	sc_port<Pburst_write_if> EastOut;
	sc_port<Pburst_read_if> SouthIn;
	sc_port<Pburst_write_if> SouthOut;

	sc_port<Pburst_read_if> Node1_In;
	sc_port<Pburst_write_if> Node1_Out;
	sc_port<Pburst_read_if> Node2_In;
	sc_port<Pburst_write_if> Node2_Out;
	sc_port<Pburst_read_if> Node3_In;
	sc_port<Pburst_write_if> Node3_Out;
	sc_port<Pburst_read_if> Node4_In;
	sc_port<Pburst_write_if> Node4_Out;


	bool reqW, reqN, reqE, reqS, req1, req2, req3, req4;
	sc_signal<sc_logic>  grantW, grantN, grantE, grantS, grant1, grant2, grant3, grant4;
	bool  fullW = false, fullN = false, fullE = false, fullS = false, full1 = false, full2 = false, full3 = false, full4 = false;
	int  portW, portN, portE, portS, port1, port2, port3, port4;

	int RowID, ColID;
	int dimRowNodes, dimColNodes;

	PacketBurst PacketW;
	PacketBurst PacketN;
	PacketBurst PacketE;
	PacketBurst PacketS;
	PacketBurst Packet1;
	PacketBurst Packet2;
	PacketBurst Packet3;
	PacketBurst Packet4;

	int PacketW_DestNum;
	int PacketN_DestNum;
	int PacketE_DestNum;
	int PacketS_DestNum;
	int Packet1_DestNum;
	int Packet2_DestNum;
	int Packet3_DestNum;
	int Packet4_DestNum;
	Router(sc_module_name name, int RowID_, int ColID_, int dimRowNodes_, int dimColNodes_) :sc_module(name)
	{
		dimRowNodes = dimRowNodes_;
		dimColNodes = dimColNodes_;
		RowID = RowID_;
		ColID = ColID_;

		SC_THREAD(BufferW);
		sensitive << grantW;
		SC_THREAD(BufferN);
		sensitive << grantN;
		SC_THREAD(BufferE);
		sensitive << grantE;
		SC_THREAD(BufferS);
		sensitive << grantS;
		SC_THREAD(BufferNode1);
		sensitive << grant1;
		SC_THREAD(BufferNode2);
		sensitive << grant2;
		SC_THREAD(BufferNode3);
		sensitive << grant3;
		SC_THREAD(BufferNode4);
		sensitive << grant4;
		SC_THREAD(Arbitter);

	}
	SC_HAS_PROCESS(Router);
	void BufferW();
	void BufferN();
	void BufferE();
	void BufferS();
	void BufferNode1();
	void BufferNode2();
	void BufferNode3();
	void BufferNode4();

	void Arbitter();

};
