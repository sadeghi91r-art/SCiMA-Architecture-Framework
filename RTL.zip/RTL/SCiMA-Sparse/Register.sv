module Register
  #(parameter Width =16)
  (Din, clk, reset, load, Dout);
  
  input clk, reset, load;
  input [(Width-1):0] Din;
  output logic [(Width-1):0] Dout=0;
  
  
  always@(posedge clk) begin
    if (reset) Dout<=0;
    else if (load) Dout<=Din;
  end
  
  
endmodule