
#ifndef BurstINTERFACE
#define BurstINTERFACE
#ifndef SC_LIB
#define SC_LIB
#include <systemc.h>
#endif
#include "Packets.h"

class Pburst_write_if : virtual public sc_interface
{
public:
	virtual void burstWrite(PacketBurst Data) = 0;
};

class Pburst_read_if : virtual public sc_interface
{
public:
	virtual PacketBurst burstRead() = 0;
};
#endif
