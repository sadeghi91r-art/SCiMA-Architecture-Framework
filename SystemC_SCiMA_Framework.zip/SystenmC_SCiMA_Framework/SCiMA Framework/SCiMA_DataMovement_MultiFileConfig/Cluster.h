﻿
#include "VMM.h"

/*

-Cluster is the second level of architecture
-It has interfaces like VMM to provide systolic dataflow in second level of architecture

-Cluster has:
- An <mv,nv> array of VMMs which provides a weight matrix by the size of <mv*IVS, nv*OVS>
- Memory is to store input and output data of the application which can be convolution, Fully connected, or matrix matrix multiplication which has been modeld as two pointers for input and output separately
- Two buses are for distributing input data vector slices to left VMMs and collecting accumulated output vector from buttom row of VMM modeld as two pointer array of left and down ports
- A contrllers (thread) is used for handeling input data including receiving input, moving it, and distribue input vectors beween left VMMs
- A controller (thread)is used for handeling output data including collecting output vector from buttom VMMs, receving partial from up, and send accumulated result to down

-Constant parameters of Cluster are as follows:
-mv, nv:							mv rows and nv columns of VMMs inside cluster
-CLusMemSize:						Memory Size which is redundant to now
-ClusDTR:							Data transfer rate when distributing and collecting input and outputs to and from VMMs respectively
-mv, nv, VIVS, VOVS, VmmDTR, Dclk:	Parameters of VMMs inside cluster
-Other parameters of Cluster including interface configuration, weight matrix going to be mapped to memristor array,


-Based on the application size, the whole VMMs of cluster may not be used. assume <mav, nav> array of VMMs will be used as shown below.
In addition, in the case that all memristors of lowest row of VMM may not be used, lower not used memristors will be set to zero.
Therefore input vectors would be <IVS*mav> and it would sliced into mav parts and will be sent to mv-mav to mav rows of VMMs




-Input contrller thread
1-it receives input data from left interface(a batch of IFM, input matrix, input vector for fully connect)
2-move data to the right cluster if employed
3-it vectorize input data to input vectors and sends slices of input vector by the size of IVS to corriesponding VMMs


-Output contrller thread
1-it starts to collect output vector slice from down VMMs for left to right
2-After collecting all rounds, it receives partial sum from up interface and collects with its output
3-sends accumulated output result through down interfaces

-Dataflow for a <4,4> array of VMMs when sending input vector slices to rows of VMMs
1	-	-	-		2	1	-	-		3	2	1	-		4	3	2	1		5	4	3	2		6	5	4	3		7	6	5	4
-	-	-	-		1	-	-	-		2	1	-	-		3	2	1	-		4	3	2	1		5	4	3	2		6	5	4	3
-	-	-	-		-	-	-	-		1	-	-	-		2	1	-	-		3	2	1	-		4	3	2	1		5	4	3	2
-	-	-	-		-	-	-	-		-	-	-	-		1	-	-	-		2	1	-	-		3	2	1	-		4	3	2	1



up interface
||
_______________________________________\/___________________________
| _________________________________________________________________ |
||					<----------------nv---------------------->		||
||	________		______		______		______		______		||
||	|		|	-@->|	 |___@__|	 |___@__|	 |___@__|	 |	/|\	||
||	|		|		|____|		|____|		|____|		|____|	 |	||
||	|	E	|		__@___		__@___		__@___		__@___	 |	||
||	|	M	|/|\-@->|used|___@__|used|___@__|used|___@__|	 |	 |	||
||	|	O	| |		|____|		|____|		|____|		|____|	 |	||
left interface   ---\||	|	Y	| |		__@___		__@___		__@___		__@___	 mv	||-->right interface
---/||	|		| |	-@->|used|___@__|used|___@__|used|___@__|	 |	 |	||
||	|_______|mav	|____|		|____|		|____|		|____|	 |	||
||			  |		__@___		__@___		__@___		__@___	 |	||
||			  |	-@->|used|___@__|used|___@__|used|___@__|	 |	 |	||
||			  |		|____|		|____|		|____|		|____|	\|/	||
||			 \|/	 \|/		 \|/		 \|/		 \|/		||
||					<----------------nv----------->					||
||_________________________________________________________________||
|___________________________________________________________________|
||
\/
down interface
*/

template<int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
SC_MODULE(Cluster)
{

	ofstream record;
	string filename;

	int C; int r; int s; int K; int Strd;
	bool LIF; bool RIF; bool UIF; bool DIF; bool COMP;
	int *ClustWeight;

	int Hi; int Wi; int Ci;  int Ho; int Wo; int Co;
	int NWi; int NWo;

	int ODS; int IDS; int cpv; int kpv;



	int mav; int nav;

	//Declare ports of Cluster Left, Right, Up, Down as sc_port
	sc_port<burst_write_if> outR;
	sc_port<burst_write_if> outD;
	sc_port<burst_read_if> inL;
	sc_port<burst_read_if> inU;

	//Declare ports for Left and Down VMMs to distribute input and collect output respectively
	sc_export<burst_write_if> InLeftVs[mv];
	sc_export<burst_read_if>  OutDownVs[nv];

	//Declare array of VMMs along with source and destination data transfer rate
	VMM<VIVS, VOVS, Dclk> *VMMs[mv][nv];

	//Declare channels for input data tranfer between rows of VMMs and for output data tranfer between columns of VMMs
	Chanel< ClusDTR, VmmDTR>* chanInD[mv][nv];
	Chanel< ClusDTR, VmmDTR>* chanOutD[mv][nv];

	//Declare channels distribution and collection bus of left and down VMMs
	Chanel<ClusDTR, VmmDTR>* chanCVin[mv];
	Chanel<ClusDTR, VmmDTR>* chanCVout[nv];

	sc_event NewIFM; bool flagNewIFM = false;
	sc_event NewOFM; bool flagNewOFM = false;

	/*
	-Parameters passed to the cluster depends on application, so they will be passes when instanting inside higher levels of architecture
	-These parameters are as follows:
	-C, r, s, K, Strd: number of channels, rows, columns of kernels
	-K, Strd: number and stride of kernels
	(for vector matrix multiplication like fully connected, r=input size, s=1, K=number of neurons, and C=1, stride=1)
	-name: name of module
	-RIF, LIF, UIF, DIF flags for interface confiuration
	-ClustWeight_:pointer of weight matrix
	*/
	Cluster(sc_module_name name, int C_, int r_, int s_, int K_, int Strd_,
		bool LIF_, bool RIF_, bool UIF_, bool DIF_, bool COMP_, int *ClustWeight_) :sc_module(name)
	{
		int *MatWghtVMM=new int [1];

		string direct = "Cluster\\";
		string parent = get_parent()->basename();
		string modulename = name;
		string namemodule = parent + modulename;
		filename = direct + namemodule + ".rec";// +name() + ".rec";
		//r*record.open(filename);

		ClustWeight = ClustWeight_;
		C = C_; r = r_; s = s_; K = K_; Strd = Strd_;
		LIF = LIF_; RIF = RIF_; UIF = UIF_; DIF = DIF_; COMP = COMP_;

		//Calculate number of channels and kernels per VMM
		cpv = (s==1) ? 1 : (VIVS / (r*s));
		kpv = VOVS;
		//Calculate number of VMMs associated with weight matrix dimension
		mav = int((C - 1) / (cpv)) + 1;
		nav = int((K - 1) / (kpv)) + 1;

		//Instantiation of <mv, nv> VMMs and pass suitable paraemters to VMMs noticing to weight matrix dimension
		for (int i = 0; i < mv; i++)
		for (int j = 0; j < nv; j++){
			string namemodule = "VMM__" + to_string(i) + "__" + to_string(j);

			//If cluster is not used or VMM is out of <mav, nav> array of utilized VMMs determined by their index <i, j>
			//Weight matrix is 0 and flags are set to 0
			if ((COMP == false) || (i < (mv - mav)) || (j>nav - 1)){
				/*F
				for (int i = 0; i<VIVS; i++)
				for (int j = 0; j < VOVS; j++){
					MatWghtVMM[i][j] = 0;
				}
				*/
				VMMs[i][j] = new VMM<VIVS, VOVS, Dclk>(namemodule.c_str(), 0, 0, 0, 0, 0, MatWghtVMM);
			}
			// If cluster is  used and is inside <mav, nav> array of utilized VMMs determined by their index <i, j>
			else{
				/*F
				for (int i = 0; i<VIVS; i++)
				for (int j = 0; j < VOVS; j++){
					MatWghtVMM[i][j] = 0;
				}
				*/
				//Determine number of channels  assigned to VMM
				int chanVMM, kernelVMM;
				if (i == mv - 1) chanVMM = C - (mav - 1)*cpv;//last VMM may be partially utilized
				else chanVMM = cpv;//not last VMM: fully utilized all rows

				//Determine number of kernels assigned to VMM
				if (j == nav - 1) kernelVMM = K - (nav - 1)*kpv;//last VMM may be partially utilized
				else kernelVMM = kpv;//not last VMM fully utilized all columns

				/* Split weight assigned to VMM
				-Kernel are stored in pointer variable in the form of unrolled.
				-Each Kernel is unrolled in C, s, and r direction respectively and constitutes one column of weight matrix.
				-Therefore weight of xkth kernel in position <xr, xs, xc> is indexed by address: (xc+xs*X+xr*C*s+xk*r*s*C).
				-This section split kernels noticing to part of channels and kernels assigned to VMM
				*/
				/*F
				for (int kw = 0; kw < kernelVMM; kw++){ //for number of kernels assigned to VMM
					int dex = 0;
					for (int yw = 0; yw < s; yw++)			//for columns of filter
					for (int xw = 0; xw < r; xw++)			//for rows of filter
					for (int cw = 0; cw < chanVMM; cw++){	//for number of channels assigned to VMM

						int indexi = ((i - (mv - mav)) * cpv + cw) + (xw)* C *s + (yw)* C; //row of weight matrix
						int indexj = (kpv * j + kw);								   //column of weight matrix
						if (indexj < K && indexi<(r*s*C) && ((i - (mv - mav)) * cpv + cw) < C){
							int tt = *(ClustWeight + indexi + indexj*(r*s*C));
							MatWghtVMM[dex][kw] = tt;
						}
						dex++;
					}
				}
				*/
				//Determinne interface flags if they are inside <mav, nav> array of VMMs
				bool compute, leftInterface, rightinterface, topinterface, buttominterface;
				compute = ((i < (mv - mav)) || (j>nav - 1)) ? 0 : 1;
				leftInterface = ((i < (mv - mav)) || (j>nav - 1)) ? 0 : 1;
				rightinterface = ((i >= (mv - mav)) && (j < nav - 1)) ? 1 : 0;
				topinterface = ((i >(mv - mav)) && (j <= nav - 1)) ? 1 : 0;
				buttominterface = ((i >= (mv - mav)) && (j <= nav - 1)) ? 1 : 0;

				VMMs[i][j] = new VMM<VIVS, VOVS, Dclk>(namemodule.c_str(), leftInterface, rightinterface, topinterface, buttominterface, compute, MatWghtVMM);
				//delete MatWghtVMM;
			}
		}

		//*******************Instantiation of channels*************
		for (int i = 0; i < mv; i++)
		for (int j = 0; j < nv; j++){
			string namemodule = "chanelsL" + to_string(i) + "_" + to_string(j);
			chanInD[i][j] = new Chanel<ClusDTR, VmmDTR>(namemodule.c_str());
		}
		for (int i = 0; i < mv; i++)
		for (int j = 0; j < nv; j++){
			string namemodule = "chanelsR" + to_string(i) + "_" + to_string(j);
			chanOutD[i][j] = new Chanel<ClusDTR, VmmDTR>(namemodule.c_str());
		}
		for (int i = 0; i < mv; i++){
			string namemodule = "chanCVin" + to_string(i);
			chanCVin[i] = new Chanel< ClusDTR, VmmDTR>(namemodule.c_str());
		}
		for (int i = 0; i < nv; i++){
			string namemodule = "chanCVout" + to_string(i);
			chanCVout[i] = new Chanel<ClusDTR, VmmDTR>(namemodule.c_str());
		}

		//*******************binding VMMs and channels*******************
		//binding input and output ports of VMM to channels(except las row and first column)
		for (int i = 0; i < mv - 1; i++)
		for (int j = 1; j < nv; j++){
			VMMs[i][j]->inL(*chanInD[i][j - 1]);
			VMMs[i][j]->inU(*chanOutD[i][j]);
			VMMs[i][j]->outR(*chanInD[i][j]);
			VMMs[i][j]->outD(*chanOutD[i + 1][j]);
		}

		//binding input and output ports of first column except last one
		for (int i = 0; i < mv - 1; i++){
			InLeftVs[i](*chanCVin[i]);
			VMMs[i][0]->inL(*chanCVin[i]);
			VMMs[i][0]->inU(*chanOutD[i][0]);
			VMMs[i][0]->outR(*chanInD[i][0]);
			VMMs[i][0]->outD(*chanOutD[i + 1][0]);

		}

		//binding input and output ports of last row except first one
		for (int i = 1; i < nv; i++){
			OutDownVs[i](*chanCVout[i]);
			VMMs[mv - 1][i]->inL(*chanInD[mv - 1][i - 1]);
			VMMs[mv - 1][i]->inU(*chanOutD[mv - 1][i]);
			VMMs[mv - 1][i]->outR(*chanInD[mv - 1][i]);
			VMMs[mv - 1][i]->outD(*chanCVout[i]);

		}

		//binding input and output ports of VMM of last row and first column
		OutDownVs[0](*chanCVout[0]);
		InLeftVs[mv - 1](*chanCVin[mv - 1]);
		VMMs[mv - 1][0]->inL(*chanCVin[mv - 1]);
		VMMs[mv - 1][0]->inU(*chanOutD[mv - 1][0]);
		VMMs[mv - 1][0]->outR(*chanInD[mv - 1][0]);
		VMMs[mv - 1][0]->outD(*chanCVout[0]);


		SC_THREAD(IFMcontroller);
		SC_THREAD(OFMcontroller);
		SC_THREAD(RegCalc);
		//set_stack_size(16097152);
	}
	SC_HAS_PROCESS(Cluster);
	void IFMcontroller();
	void OFMcontroller();
	void RegCalc();
};

template<int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
void Cluster<ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>::RegCalc(){
	while (1){
		flagNewIFM = true;
		wait(NewIFM);


		while (!flagNewOFM);
		Ho = (Hi>Strd) ? int(Hi / Strd) : 1; Wo = (Wi>Strd) ? int(Wi / Strd) : 1; Co = K; NWo = Ho*Wo;
		ODS = NWo * K;
		NewOFM.notify();
		flagNewOFM = false;
	}
}


/*
This thread: 1-receives input data from left interface, 2-moves it to right, and 3- vectorize input and distributes slices to corresponding VMMs
*/
template<int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
void Cluster<ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>::IFMcontroller(){
	int *databufferI = NULL;
	int round = 0;
	while (LIF || COMP || RIF){
		//wait(3, SC_NS);
		DataVol DataPackI;
		DataVol VmmDataPackI;
		int *bufD;

		//1-Receive input from left interface InL
		if (LIF){
			//wait(200, SC_NS);
			//r*record << "IFMCONTROLLER WAITS_GET_IFM @ " << sc_time_stamp() << " Round " << round << endl;
			cout << "****" << name() << "waits IFM  at time : " << sc_time_stamp() << endl;
			DataPackI = inL->burstRead();
			//cout << "****" << name() << "waits IFM  at time : " << sc_time_stamp() << endl;
			//r*record << "IFMCONTROLLER GOT_IFM @ " << sc_time_stamp() << " Round " << round << endl;
			databufferI = DataPackI.data;
			Hi = DataPackI.H; Wi = DataPackI.W; Ci = DataPackI.C;

			while (!flagNewIFM);
			NewIFM.notify();
			flagNewIFM = false;
		}

		//2-Move input to the right OutR
		if (RIF){
			cout << "****" << name() << " Skipping IFM  at time : " << sc_time_stamp() << endl;
			outR->burstWrite(DataPackI);
			cout << "****" << name() << " Skipped IFM  at time : " << sc_time_stamp() << endl;
		}
		//3-Start Distribution of input vectors (Windows of convolution or vectors of matrix-matrix multplication

		if (COMP){
			ofstream filedata;
			//For each window of input feature map

			for (int x = 0; x < Hi; x = x + Strd)
			for (int y = 0; y < Wi; y = y + Strd)
			{
				//Vectorize window to input vector
				for (int v = (mv - mav); v < mv; v++){	//For utilized VMMs from up to down
					int Ct = (v != (mv - 1)) ? cpv : (int(C%cpv) == 0) ? cpv : int(C%cpv);
					int *VMMI = new int[1];
					/*F
					int IndexVmmI = 0;
					//Split input vector into slices for sending to utilized VMMs
					for (int iii = 0; iii < VIVS; iii++) VMMI[iii] = 0;
					for (int yw = (-1 * int(s / 2)); yw < (int(s / 2) + 1); yw++){
						int hh1 = (s>1) ? (-1 * int(r / 2)) : 0;
						int hh2 = (s>1) ? (int(r / 2) + 1) : r;
						for (int xw = hh1; xw < hh2; xw++)
						for (int cw = 0; cw < Ct; cw++){
							int Addindx = ((v - (mv - mav)) * cpv + cw) + (xw + x) * C*Wi + (yw + y)*C;
							//Just for checking channel index of last VMM is out of channels specified to the cluster
							if (((x + xw) >= 0) && ((y + yw) >= 0) && ((y + yw) < Wi) && ((x + xw) < Hi) && (((v - (mv - mav))*cpv + cw) < C)){
								VMMI[IndexVmmI] = *(databufferI + Addindx);
							}
							else VMMI[IndexVmmI] = 0;
							IndexVmmI++;

						}
					}
					*/
					//Sending input vector slices to corresponding VMM through ports of left VMMs
					VmmDataPackI.data = VMMI;
					VmmDataPackI.H = VIVS; VmmDataPackI.W = 1; VmmDataPackI.C = 1;
					cout << "****" << name() << " Sending to VMM :" << v << "-<window [" << x << "," << y << "] at time" << sc_time_stamp() << endl;
					//wait(1, SC_NS);
					InLeftVs[v]->burstWrite(VmmDataPackI);
					cout << "****" << name() << " Sent to VMM :" << v << "-<window [" << x << "," << y << "] at time" << sc_time_stamp() << endl;

				}
			}

		}
		round++;
	}
}

/*
This thread handles ouput data as follows:
1-It waits for being triggered for new computation
2-It starts to collect output vector slice from down VMMs and constitutes output vector by storing inside databufferO
noticing to the size of input data
3-It then receives partial sum from up if its flag is activated
4-It sends accumulated partial output to down
*/
template<int ClusMSize, int ClusDTR, int mv, int nv, int VIVS, int VOVS, int VmmDTR, int Dclk>
void Cluster<ClusMSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk>::OFMcontroller(){
	int round = 0;
	int *databufferO;
	//databufferO = (int *)malloc(2);

	DataVol VmmDataPackO;
	DataVol DataPackO;
	int *bufD;

	while (UIF || COMP || DIF){

		//1-It waits for being triggered by thread receiving input data
		int* databufferO = new int[];
		if (COMP){
			flagNewOFM = true;
			wait(NewOFM);
			int* databufferO = new int[1];


			//2-It starts to collect output vectors form down VMMs

			if (COMP) {
				//r*record << "OFMCONTROLLER WAITS_COLLECT_OFM @ " << sc_time_stamp() << " Round " << round << endl;
				int IndexVmmO = 0;
				cout << "OFMcontroller" << endl;
				for (int w = 0; w < NWo; w++){		//For each wbindow or input vector
					for (int v = 0; v < nav; v++){	//For utilized VMMs of last row
						wait(1, SC_NS);
						cout << "****" << name() << "Getting OFM window  from VMM :" << v << "-<window [" << w << "]  at time" << sc_time_stamp() << endl;
						//Receiving output vector slice through ports of down VMMs
						VmmDataPackO = OutDownVs[v]->burstRead();
						cout << "****" << name() << "Got OFM window  from VMM :" << v << "-<window [" << w << "]  at time" << sc_time_stamp() << endl;
						bufD = VmmDataPackO.data;
						/*F
						for (int vo = 0; vo < VOVS; vo++){
							//stores output vector slices into output databuffer
							//This condition skips elements of output vector which are related to not fully utilized last column of VMMs
							if ((v*VOVS + vo) < K){
								int x;
								*(databufferO + IndexVmmO) = *(bufD + vo);
								x = *(bufD + vo);
								IndexVmmO++;
							}
						}
						*/
					}
				}
				//r*record << "OFMCONTROLLER COLLECT_OFM @ " << sc_time_stamp() << " Round " << round << endl;
			}
			//3-Receving partial result from up it its flag has been set to 1
			if (UIF) {
				//r*record << "OFMCONTROLLER WAITS_GET_POFM @ " << sc_time_stamp() << " Round " << round << endl;
				if (COMP){

					cout << "****" << name() << " Getting Partial OFM   at time" << sc_time_stamp() << endl;
					DataPackO = inU->burstRead();
					cout << "****" << name() << " Got Partial OFM   at time" << sc_time_stamp() << endl;

					int volpack = DataPackO.H * DataPackO.W * DataPackO.C;

					bufD = DataPackO.data;
					/*F
					for (int i = 0; i < volpack; i++) {
						int n = *(bufD + i);
						*(databufferO + i) = COMP* *(databufferO + i) + *(bufD + i);
					}
					*/
				}
				else{
					cout << "****" << name() << " Getting Partial OFM   at time" << sc_time_stamp() << endl;
					DataPackO = inU->burstRead();
					cout << "****" << name() << " Got Partial OFM   at time" << sc_time_stamp() << endl;
					databufferO = DataPackO.data;
				}
				//r*record << "OFMCONTROLLER GOT_POFM @ " << sc_time_stamp() << " Round " << round << endl;
			}
			//4-Sending acuumulated partial result to down through OutDown port 
			if (DIF){
				//cout << endl;
				DataPackO.data = databufferO;
				if (COMP) {
					DataPackO.H = Ho; DataPackO.W = Wo; DataPackO.C = Co;
				}

				//r*record << "OFMCONTROLLER WAIT_SEND_OFM @ " << sc_time_stamp() << " Round " << round << endl;
				cout << "****" << name() << " Sending  OFM   at time" << sc_time_stamp() << endl;
				outD->burstWrite(DataPackO);
				cout << "****" << name() << " Sent  OFM   at time" << sc_time_stamp() << endl;
				//r*record << "OFMCONTROLLER SENT_OFM @ " << sc_time_stamp() << " Round " << round << endl;
			}
		}
		round++;
		wait(1, SC_NS);
	}
}
