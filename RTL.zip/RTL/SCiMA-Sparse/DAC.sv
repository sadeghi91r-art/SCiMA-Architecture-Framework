module DAC
  #(parameter real MaxDAC=3, parameter precision=2)
  (DigIn, SigOut);
 
 input [(precision-1):0] DigIn;
 output real SigOut;
 real regout, step;
 real v1;
 
 always@(*) begin
   step = ((2**precision)-1);
   v1=DigIn;
   regout = v1 / step;
   SigOut = regout * MaxDAC;
 end
  
endmodule

module DAC_tester();
  
  logic [2:0] DigIn;
  real SigOut;
  DAC #(3, 3) DAC_UT(DigIn, SigOut);
  
  initial begin
    DigIn=1;
    #17;
    DigIn=5;
    #17;
    DigIn=7;
    #17;
  end
endmodule