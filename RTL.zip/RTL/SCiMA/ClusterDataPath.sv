module ClusterDatapath
#(parameter XB_size=128, DataWidth=16,WeightWidth=8,  SliceWidth=2,CellBits=2,
  real DACmax=3,parameter ADCresolution=11, real Hcond=10**-9, real Lcond=0, parameter SRIF_ADC_delay = 10,
  mv = 4, nv=4, MemorySize=2**16, Cluster_OFM_size=100, mav=2, nav=2, Tix=1, Tiy=1,Cix=1,Ciy=1)
  (clk, rst,
  ReqVMMLeft, AckVMMLeft, ReqVMMDown, AckVMMDown,
	Din, AW1, AR1, Dout, read1, write1,
  AW2, AR2, read2, write2, 
  SelVMM, seldata,
  zeroing, rstsum, loadSum, sendsum1, sendsum2);
    
  
  input  clk, rst;
  input ReqVMMLeft [0:(mv-1)];
  output  AckVMMLeft [0:(mv-1)];
  
  output ReqVMMDown [0:(nv-1)];
  input  AckVMMDown [0:(nv-1)];
  
  input  [(DataWidth-1):0]  Din;
  output [(DataWidth-1):0] Dout;
  

  
  input seldata;
  input [$clog2(MemorySize):0] AW1;
  input [$clog2(MemorySize):0] AW2;
  input [$clog2(MemorySize):0] AR1;
  input [$clog2(MemorySize):0] AR2;
  input [$clog2(nv):0] SelVMM;
  output zeroing, rstsum, loadSum, sendsum1, sendsum2;
  
  logic [(DataWidth-1):0] Dport1;
  logic [(DataWidth-1):0] Dout2;
  
   wire  [(DataWidth-1):0]  DataLeft [0:(mv-1)];
   wire  [(DataWidth-1):0]  DataDown [0:(nv-1)];
   
   wire  [(DataWidth-1):0]  DinIFM, DinOFM;
   wire  [(2*DataWidth-1):0]  DoutSum;
   wire  [(DataWidth-1):0]  DoutIFM, DoutOFM, VMMDownOut;
   logic  [(DataWidth-1):0]  DataMux;


module Memory #(MemorySize, DataWidth)
  (clk, rst, 
  Dport1, AW1, AR1, Dout, read1, write1,
  VMMDownOut, AW2, AR2, Dout2, read2, write2,
);

assign Dport1 = seldata ? Din : (Din + Dout);

VMM_Array
#( XB_size, DataWidth, WeightWidth, SliceWidth, CellBits, DACmax, ADCresolution, Hcond,Lcond, SRIF_ADC_delay,
	mv, nv, mav, nav, Tix, Tiy,Cix,Ciy) VMMArray (clk, rst, ReqVMMLeft, AckVMMLeft, ReqVMMDown, AckVMMDown, DataLeft, DataDown);
	
Mux 	#(nv, DataWidth) VMM_selector (DataDown, SelVMM, 1'b1, VMMDownOut);


assign DataMux = zeroing ? 0 : sendsum1 ? DoutSum[DataWidth-1: 0] : sendsum2? DoutSum[(2*DataWidth-1): DataWidth]: Dout2;
genvar i;
generate // concting one port to some ports directly
	for (i = 0; i< mv; i=i+1) begin
		assign DataLeft[i] = DataMux;
	end
endgenerate

Register #(2*DataWidth) RegSum (({{DataWidth{1'b0 }}, DataLeft[0]} + DoutSum), clk, rstsum, loadSum, DoutSum);

endmodule