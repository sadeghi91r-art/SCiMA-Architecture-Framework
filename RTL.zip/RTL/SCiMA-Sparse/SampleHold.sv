
module SampleHold 
  #(Size = 8, bit_slice=2)
  (SigIn, SigOut, discharege, SampleSel, SmpInEn, SmpOutEn);
  
  input real SigIn;
  output real SigOut;
  real temp;
  input discharege;
  input  [($clog2(Size)-1) : 0] SampleSel;
  input SmpInEn;
  input SmpOutEn;
  
  
  real sampleReg [0:(Size-1)]; 
  integer i;
  
  always@(*) begin
    if(discharege) begin
      for (i=0; i< Size; i=i+1) begin
        sampleReg[i] = 0;
      end
    end
    
  else begin
    if (SmpInEn) begin
        sampleReg[SampleSel] = SigIn;
    end
  end
end
  always@(*) begin
    if (SmpOutEn) begin
      SigOut=0;
      for(i = 0; i < Size; i++) begin
		temp = ((2**(bit_slice))**i);
		temp = temp * sampleReg[i];
        SigOut = SigOut + temp;
      end     
   end
  end
  
     
   
endmodule


module TseterSmpHold 
  #(Size = 4)
  ();
  
   real SigIn;
   real SigOut;
  reg discharege;
  reg  [(Size-1) : 0] SampleSel;
  reg SmpInEn;
  reg SmpOutEn;
  
  SampleHold #(Size) SH (SigIn, SigOut, discharege, SampleSel, SmpInEn, SmpOutEn);
  
  initial begin
    SigIn = 1.5;
    discharege=0;
    SampleSel=1;
    SmpInEn=1;
    SmpOutEn=0;
    #17;
    SigIn = 2.5;
    discharege=0;
    SampleSel=2;
    SmpInEn=1;
    SmpOutEn=0;
    #17;
    SigIn = 3.5;
    discharege=0;
    SampleSel=4;
    SmpInEn=1;
    SmpOutEn=0;
    #17;
    SigIn = 4.5;
    discharege=0;
    SampleSel=8;
    SmpInEn=1;
    SmpOutEn=0;
    #17;
    SampleSel=8;
    SmpInEn=0;
    SmpOutEn=0;
    #17;
    SampleSel=1;
    SmpInEn=0;
    SmpOutEn=1;
    #17;
    SampleSel=2;
    SmpInEn=0;
    SmpOutEn=1;
    #17;
    SampleSel=4;
    SmpInEn=0;
    SmpOutEn=1;
    #17;
    SampleSel=8;
    SmpInEn=0;
    SmpOutEn=1;
    #17;
    discharege=1;
    SmpOutEn=0;
    
  end
  
endmodule