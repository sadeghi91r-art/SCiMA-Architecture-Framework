
module VMM_ContInput
  #(XB_size=128, LIF=1, RIF=1,
  PSI=64, logic [($clog2(PSI)-1):0] PrunedRows [0:PSI-1])
  (clk, rst, start,
  witeIFM, readIFM,
  FullEmptyIFM, doneOFM,
  zeroingBPRD, writeBPRD, readBPRD, FullEmptyBPRD,
  selectPruned,
  req_left, ack_left,
  req_right, ack_right);
    
  input clk, rst, FullEmptyIFM, doneOFM;
  input req_left, ack_right;
  output ack_left, req_right;
  output start, witeIFM, readIFM;
  
  output zeroingBPRD;
  output writeBPRD;
  output readBPRD;
  input FullEmptyBPRD;
  

  output selectPruned;
  
  logic [9:0] TempPruned;
  logic [ 3:0] ns, ps;
  logic rstC, enC, DetTransferEnd;
  
  logic [($clog2(2*XB_size)-1):0] count_reg;
  logic [($clog2(PSI)-1):0] index_Temp_Pruned;
  
  parameter Idle=0, GiveAckLeft=1, WaitForData=2,
  IFMBurst=3, StartingP=4, StartingN=5,
  GiveReqRight=6, ReqInAc=7, waiting=8, sendIFM=9, DoneSendOFM=10, GetSum1=11, GetSum2=12, 
  SendSum1=13, SendSum2=14;
  parameter WritePrunedRowDepth=5, WritePrunedColumnDepth=6, GetPrunedRows=7, GetPrunedColumns=8;
    	 
	 logic [9:0] PrunedRows1 [0:PSI-1]='{
4, 5, 6, 7, 14, 15, 16, 17, 24, 25, 26, 27, 34, 35, 36, 37,
44, 45, 46, 47, 54, 55, 56, 57, 64, 65, 66, 67, 74, 75, 76, 77,
84, 85, 86, 87, 94, 95, 96, 97, 104, 105, 106, 107, 114, 115, 116, 117,
124, 125, 126, 127, 134, 135, 136, 137, 144, 145, 146, 147, 154, 155, 156, 157
};


	
	
    always@(*) begin
      ns=Idle;
      case(ps)
        Idle: begin
          if(req_left==1'b1 && LIF==1) ns=GiveAckLeft;
          else ns= Idle;
        end
        GiveAckLeft: begin
          if (req_left==1'b0) ns=WaitForData;
          else ns= GiveAckLeft;
        end
        WaitForData: begin
          ns= IFMBurst;
        end
        IFMBurst: begin
			if(DetTransferEnd) begin
				if (RIF==1)ns = GiveReqRight;
				else ns = StartingP;
			end
			else ns = IFMBurst;
        end
		GiveReqRight: begin
          if(ack_right==1'b1) ns = ReqInAc;
		      else ns=GiveReqRight;
          end
		ReqInAc: begin
          if(ack_right==1'b0) ns = sendIFM;
		      else ns=ReqInAc;
        end
		waiting: begin
          ns=sendIFM;
        end
		sendIFM: begin
          if(DetTransferEnd) ns = StartingP;
		      else ns=sendIFM;
        end
		StartingP: begin
          ns = StartingN;
        end
		StartingN: begin
          if(doneOFM) ns = Idle;
		      else ns=StartingN;
        end
        default : begin
          ns = Idle;
        end
      endcase
    end
    
    always@(posedge clk) begin
      if (rst) ps<=Idle;
      else ps<=ns;
    end
	
	assign start = (ps == StartingP);
	assign witeIFM = (ps == IFMBurst && !selectPruned);
	assign readIFM = (ps == sendIFM && !selectPruned);
	assign ack_left = (ps == GiveAckLeft);
	assign req_right = (ps == GiveReqRight);
	


	
	assign rstC = (ps == WaitForData || ps == ReqInAc);
	assign enC = (ps == IFMBurst || ps == sendIFM);
	assign DetTransferEnd=count_reg==(PSI+XB_size-1);
	always@(posedge clk) begin
		if(rstC) count_reg<=0;
		else if (enC) count_reg <= count_reg+1;
	end
	always@(posedge clk) begin
		if(rstC) index_Temp_Pruned<=0;
		else if (selectPruned) index_Temp_Pruned <= index_Temp_Pruned+1;
	end
	assign selectPruned=TempPruned==count_reg;
	assign TempPruned=PrunedRows1[index_Temp_Pruned];
	
	assign zeroingBPRD = (ps==Idle);
	assign writeBPRD = (ps == IFMBurst && selectPruned);
	assign readBPRD = (ps == sendIFM && selectPruned);
	
	
endmodule
  
  
