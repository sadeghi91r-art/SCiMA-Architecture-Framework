
#ifndef INTERFACE
#define INTERFACE
#ifndef SC_LIB
#define SC_LIB
#include <systemc.h>
#endif
#include "DataVol.h"

class burst_write_if: virtual public sc_interface
	{
		public:
			virtual void burstWrite(DataVol Data) = 0;
};

class burst_read_if: virtual public sc_interface
	{
		public:
			virtual DataVol burstRead() = 0;
};
#endif
