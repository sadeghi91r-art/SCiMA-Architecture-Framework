module ReqAckRegister 
#(parameter pos = "left", level = "VMM", xx = 1, yy=1)
(req, ack );
input req, ack;

always @(posedge req)begin
	$display("%s(%d,%d)->(%s):request time = %t", level, xx, yy, pos, ($time-10000) );
end
always @(posedge ack)begin
	$display("%s(%d,%d)->(%s):ack time = %t", level, xx, yy, pos, ($time-10000) );
end

endmodule

module Recorder 
#(parameter level = "VMM", xx = 1, yy=1)
(reql, ackl, reqr, ackr,requ, acku, reqd, ackd );
input reql, ackl, reqr, ackr,requ, acku, reqd, ackd;

integer i1=0, i2=0, i3=0, i4=0, i5=0, i6=0, i7=0, i8=0;
always @(posedge reql)begin
i1=i1+1;
	$display("%s(%d,%d)->>>:req left--  number %d ---time = %t", level, xx, yy, i1, ($time-10000) );
end
always @(posedge ackl)begin
i2=i2+1;
	$display("%s(%d,%d)-<<<:ack left--  number %d ---time = %t", level, xx, yy, i2, ($time-10000) );
end

always @(posedge reqr)begin
i3=i3+1;
	$display("%s(%d,%d)->>>:req right--  number %d ---time = %t", level, xx, yy, i3, ($time-10000) );
end
always @(posedge ackr)begin
i4=i4+1;
	$display("%s(%d,%d)->:ack right--  number %d ---time = %t", level, xx, yy, i4, ($time-10000) );
end
always @(posedge requ)begin
i5=i5+1;
	$display("%s(%d,%d)->:req up--  number %d ---time = %t", level, xx, yy, i5, ($time-10000) );
end
always @(posedge acku)begin
i6=i6+1;
	$display("%s(%d,%d)->:ack up--  number %d ---time = %t", level, xx, yy, i6, ($time-10000) );
end

always @(posedge reqd)begin
i7=i7+1;
	$display("%s(%d,%d)->:req down--  number %d ---time = %t", level, xx, yy, i7, ($time-10000) );
end
always @(posedge ackd)begin
i8=i8+1;
	$display("%s(%d,%d)->:ack down--  number %d ---time = %t", level, xx, yy, i8, ($time-10000) );
end

endmodule