#include"LinkedList.h"
struct Packet{
public:
	int H = 0;
	int W = 0;
	int C = 0;
	int* data;
	int sourceNum = 0;
	int DestNum = 0;
};
struct PacketBurst{
public:
	int H = 0;
	int W = 0;
	int C = 0;
	int* data;
	int sourceNum = 0;
	TempLinkedList<int> DestNum;
	int cnt = 0;
};
struct TransferConfig {
	int H1=0;
	int W1=0;
	int C1=0;
	int H2=0;
	int W2=0;
	int C2=0;
	TempLinkedList<int> ListTile;
	bool done=false;
};