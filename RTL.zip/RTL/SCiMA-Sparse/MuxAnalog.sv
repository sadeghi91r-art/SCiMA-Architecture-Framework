
module MuxAnalog
#(parameter Size=1024)
(In, Out, Sel);

input real In [(Size-1):0];
output real Out=0;
input [($clog2(Size)-1):0] Sel;



always@(*) begin
  Out=0;
  for (int i=0; i<Size; i=i+1) begin
    if(Sel==i) Out=In[i];
  end
end

endmodule

module TesterMux
  #(parameter Size=1024)
  ();

real In [(Size-1):0];
real Out;
reg [($clog2(Size)-1):0] Sel;  
  
MuxAnalog #(Size) MuxAnalog0 (In, Out, Sel);
  
  initial begin 
    In[0] =1.5;
    In[250] =4.7;
    In[577] = 25.9;
    
    #15;
    Sel =0;
    #15;
    Sel =250;
    #15;
    Sel =577;
    
  end
endmodule