module TestClusOFMController  
 #(parameter nv=4, KPU=8, K=24, N=20, LIF = 1, UIF=1, DIF=1)();
  parameter ClusOFMsize = K * N;
  logic clk=0, rst;
  wire write, read;
  wire ReqVMM [0:(nv-1)];
  wire AckVMM [0:(nv-1)];
  wire [$clog2(ClusOFMsize):0] AddOFM;
  logic ReqUp, AckDown;
  wire AckUp, ReqDown;
  wire selData;
  wire [$clog2(nv):0] selVMM;
  wire enOFMDown;
  
  always #17 clk=~clk;
  
  ClusOFMController  #(nv, KPU, K, N, LIF, UIF, DIF) OFMcntlr
  (clk, rst, write, read, AddOFM, ReqVMM, AckVMM, ReqUp, AckUp, ReqDown, AckDown, selData, selVMM, enOFMDown);
  generate
    for ( genvar i = 0; i< nv; i=i+1) begin
	     Requesting Requesting_VMMs (clk, ReqVMM[i], AckVMM[i]);
    end
  endgenerate
  assign AckDown = ReqDown;
  initial begin
   rst =1;
    #170 rst=0;
	ReqUp = 1;
	@(posedge AckUp);
	ReqUp = 0;
	@(negedge AckUp);
	#34;
	#34;
	for (integer i = 0; i<(N*K); i=i+1) begin
		#34;
	end
  end
	
endmodule


