module VMM 
#(parameter XB_size=128, DataWidth=16,WeightWidth=8, SliceWidth=2,CellBits=2,
  real DACmax=1, parameter ADCresolution=11, real Hcond=10**-9, real Lcond=0, parameter SRIF_ADC_delay = 10,
  Vix=1, Viy=1)
  (clk, rst,
  req_left, ack_left, req_right, ack_right,
  req_up, ack_up, req_down, ack_down,
  Din_left, Din_up, Dout_right, Dout_down);

  parameter NumSlices=DataWidth/SliceWidth;
  parameter OVsize=(XB_size*CellBits/WeightWidth);
  
  input clk, rst, req_left, ack_right, req_up, ack_down;
  output ack_left, req_right, ack_up, req_down;
  
  input [(DataWidth-1):0] Din_left;
  input [(DataWidth-1):0] Din_up;
  output [(DataWidth-1):0] Dout_right; 
  output [(DataWidth-1):0] Dout_down;
  
  
  logic dataready, writeOFM, readOFM, DoneSendOFM, FullEmptyOFM, start, writeIFM, readIFM, FullEmptyIFM,shiftIFM;
  logic writeOFM1, writeOFM2;
  logic [($clog2(OVsize)-1) : 0] index;
  logic [($clog2(NumSlices)-1) : 0] slice;
  logic LIF, RIF, UIF, DIF;
  logic [(DataWidth-1):0] ProgDataOut;
  logic [(DataWidth-1):0] Dout_rightM;
  logic ack_leftM, ack_leftP;
  logic req_rightM, req_rightP;
  logic Prog
assign writeOFM = writeOFM1 | writeOFM2;

  module VMM_progrmmer #(DataWidth, Viy) VMM_P
  (clk, rst,req_left, ack_leftP, req_rightP, ack_right, Prog, Din_left, ProgDataOut, LIF, RIF, UIF, DIF);
  
  VMM_IFCntlrUpDown  VMM_OC
  (clk, rst, dataready, writeOFM1, readOFM, DoneSendOFM, FullEmptyOFM, req_up, ack_up, req_down, ack_down, Prog, LIF, UIF, DIF);
  
  VMM_InputController VMM_IC
  (clk, rst, start, writeIFM, readIFM, FullEmptyIFM, DoneSendOFM, req_left, ack_leftM, req_rightM, ack_right, Prog, LIF, RIF);
  
  VMM_CompControl #(XB_size, DataWidth,WeightWidth, SliceWidth, CellBits, SRIF_ADC_delay) VMM_CC
  (clk, rst, start, dataready, shiftIFM, writeOFM2, DoneSendOFM, index, slice);

  VMM_DatapathA
  #(XB_size, DataWidth,WeightWidth, SliceWidth, CellBits, ADCresolution, DACmax, Hcond, Lcond, Vix, Viy) VMM_DatapathA0 
  ( clk, rst, writeIFM, readIFM, shiftIFM, writeOFM, readOFM, index, slice,
  FullEmptyIFM, FullEmptyOFM, Din_left, Din_up, Dout_right, Dout_down, LIF);
  
  assign ack_left=Prog? ack_leftM: ack_leftP;
  assign req_right=Prog? req_rightM: req_rightP;
  assign Dout_right=Prog? Dout_rightM: ProgDataOut;
  endmodule