module ClusterInterface  #(DataWidth=16, PacketSize=16, ConfigSize=32)
  (clk, rst, reqIn, ackIn, Din, reqOut, ackOut, Dout, writeMem, readMem, addressWrite, addressRead,
  Index, LIF, RIF, UIF, DIF, H, W, C, K, r, s, stride, MP, Act,
  BaseI, PacketI, NumI, BaseO, PacketO, NumO,BaseP, PacketP, NumP, N, KPU, CPU, mav, nav
  );
  
  parameter IMA_IFM_size = H*W*C;
  
  input clk, rst, reqIn, ackOut;
  output ackIn, reqOut;
  input [DataWidth-1:0] Din;
  output [DataWidth-1:0] Dout;
  output writeMem, readMem;
  logic  [(DataWidth-1):0] Config [0:(ConfigSize-1)];
  
  output writeMem, readMem;
  output [(DataWidth-1):0] addressWrite, addressRead;

  
  output [15:0] Index=Config[0];
  output [15:0] LIF=Config[1];
  output [15:0] RIF=Config[2];
  output [15:0] UIF=Config[3];
  output [15:0] DIF=Config[4];
  output [7:0] H=Config[5][15:8];
  output [7:0] W=Config[5][7:0];
  output [7:0] C=Config[6][15:8];
  output [7:0] K=Config[6][7:0];
  output [2:0] r=Config[7][15:13];
  output [2:0] s=Config[7][12:10];
  output [2:0] stride=Config[7][9:7];
  output [2:0] MP=Config[7][6:4];
  output Act=Config[7][3];
  output [15:0] BaseI=Config[8];
  output [15:0] PacketI=Config[9];
  output [15:0] NumI=Config[10];
  output [15:0] BaseO=Config[11];
  output [15:0] PacketO=Config[12];
  output [15:0] NumO=Config[13];
  output [15:0] BaseP=Config[14];
  output [15:0] PacketP=Config[15];
  output [15:0] NumP=Config[16];
  output [15:0] N=Config[17];
  output [7:0] KPU=Config[18][15:8];
  output [7:0] CPU=Config[18][7:0];
  output [2:0] mav=Config[19][15:13];
  output [2:0] nav=Config[19][12:10];
  
  /*
  Packet header:
  3bits:prog(0), i(1), o(2), p(3)
  5 bits: nimber of data,
  8 bits Tile index
  */
  
    
  logic [ 4:0] ns, ps;
  logic [4:0]countGetConfig;
    logic [4:0]countP;
  logic [2:0] typeD;
  logic [4:0] NumD;
  logic [7:0] TileIndex;
  
  
  logic coGC, coC;
  logic [15:0] TempPacketI, TempPacketO, TempPackeP;
  logic doneI, doneO, doneP;
  parameter Idle=0, GiveAckLeft=1, WaitForData=2,
  GetConfig=3, laodCounter=4, Decision=5;
  
  always@(posedge clk) begin
	if(ps==GiveAckLeft || rst==1) countGetConfig<=0;
	else if(ps==GetConfig) countGetConfig<=countGetConfig+1;
  end
  assign coGC=countGetConfig==19;
  
  always@(posedge clk) begin
	if(TempPacketI==PacketI || rst==1) TempPacketI<=0;
	else if((ps==WaitForData && Din[15:13]==1)) TempPacketI<=TempPacketI+1;
  end
  assign doneI=TempPacketI==PacketI;
  
  always@(posedge clk) begin
	if(TempPacketO==PacketO || rst==1) TempPacketO<=0;
	else if((ps==WaitForData && Din[15:13]==2)) TempPacketO<=TempPacketO+1;
  end
  assign doneO=TempPacketO==PacketO;
  
  always@(posedge clk) begin
	if(TempPacketP==PacketP || rst==1) TempPacketP<=0;
	else if((ps==WaitForData && Din[15:13]==3)) TempPacketP<=TempPacketP+1;
  end
  assign doneP=TempPacketP==PacketP;
  
  always@(posedge clk) begin
	if(ps==WaitForData) begin
		typeD<=Din[15:13];
		NumD<=Din[12:8];
		TileIndex<=Din[7:0];
	end
  end
  
    always@(ps,reqIn, AckRight) begin : GetIFM_Send
      ns=Idle;
      case(ps)
        Idle: begin
          if(reqIn==1'b1) ns=GiveAckLeft;
          else ns= Idle;
        end
        GiveAckLeft: begin
          if (reqIn==1'b0) ns=WaitForData;
          else ns= GiveAckLeft;
        end
        WaitForData: begin
			if(Din[15:13]==0) ns= GetConfig;
			else if(Din[15:13]==1) ns= laodCounter;
			else if(Din[15:13]==2) ns= laodCounter;
			else if(Din[15:13]==3) ns= laodCounter;
        end
        GetConfig: begin
          if(coGC) ns = Idle;
          else ns = GetConfig;
        end
        laodCounter: begin
          if(DoneTrnasfer==1'b1) ns = Decision;
		  else ns=laodCounter;
        end
		Decision: begin
          if(AckRight==1'b0) ns = sendIFM;
		  else ns=Idle;
        end
        default : begin
          ns = Idle;
        end
      endcase
    end
    
always @(posedge clk) begin 
if (rst) ps <= 0;
else ps <= ns;
end

assign addressWrite=(ps!=laodCounter)? 0: countP+(Type==1?(BaseI+TempPacketI*PacketSize): Type==3 ? (BaseP+TempPacketP*PacketSize)): 0;
assign addressRead=(ps!=laodCounter)? 0: countP+(Type==2 ?(BaseO+TempPacketO*PacketSize): Type==3 ? (BaseP+TempPacketP*PacketSize)): 0;
assign writeMem=(ps==laodCounter) && (Type==1||Type==3);
assign readMem=(ps==laodCounter) && (Type==2||Type==3);

always@(posedge clk) begin
	if(ps==GiveAckLeft || rst==1) countP<=0;
	else if(ps==laodCounter) countP<=countP+1;
  end
  assign coC=countP==NumD;

assign zeroing=(ps==WaitForData && typeD==0);
assign write=(ps==GetConfig);
assign 
BufferConfig #(ConfigSize, DataWidth) BufferConf (clk, rst, zeroing, write, read, Din_left, Dout_IFM, Config);

endmodule
