#ifndef CHANNEL
#define CHANNEL

#include "interfaceClasses.h"

template<int WTR, int RTR>
class Chanel : public sc_channel, public burst_write_if, public burst_read_if {

public:
	bool full = false;
	bool ready = false;
	DataVol saved, savedR;
	sc_event put_event, get_event;
	Chanel(sc_module_name NAME) : sc_channel(NAME){
	};
	SC_HAS_PROCESS(Chanel);
	void burstWrite(DataVol Data);
	DataVol burstRead();
};

template<int WTR, int RTR>
void Chanel<WTR, RTR>::burstWrite(DataVol Data) {
	//cout << "This is the channel writer " << endl;
	full = true;
	if (ready == false) wait(get_event);
		
	saved = Data;
	int vol = saved.H*saved.W*saved.C;
	double delay = (WTR > RTR) ? (vol)*WTR : (vol)*RTR;
	wait(4 + delay, SC_NS);
	put_event.notify();

	full = false;
	wait(1, SC_NS);
}

template<int WTR, int RTR>
DataVol Chanel<WTR, RTR>::burstRead(){
	ready = true;
	if (full == true)	get_event.notify();

	wait(put_event);
	savedR = saved;

	ready = false;
	wait(1, SC_NS);
	return savedR;
}
#endif

