
module Decoder #(
  parameter Size = 128
) (
  input logic [$clog2(Size)-1:0] in,
  input en,
  output logic [(Size-1):0] out
);

genvar i;
generate
  for(i = 0; i < Size; i++) begin
    assign out[i] = (in==i && en) ? 1 : 0;
  end
endgenerate

endmodule