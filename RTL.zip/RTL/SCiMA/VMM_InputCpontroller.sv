
module VMM_InputCpontroller
  (clk, rst, start,
  witeIFM, readIFM,
  FullEmptyIFM, doneOFM,
  req_left, ack_left,
  req_right, ack_right, Prog, LIF, RIF);
    
  input clk, rst, FullEmptyIFM, doneOFM;
  input req_left, ack_right;
  output ack_left, req_right;
  output start, witeIFM, readIFM;
  input Prog, LIF, RIF;
  logic [ 3:0] ns, ps;
  
  parameter Idle=0, GiveAckLeft=1, WaitForData=2,
  IFMBurst=3, StartingP=4, StartingN=5,
  GiveReqRight=6, ReqInAc=7, waiting=8, sendIFM=9, DoneSendOFM=10, GetSum1=11, GetSum2=12, 
  SendSum1=13, SendSum2=14;
    
    always@(ps, req_left, FullEmptyIFM, ack_right, doneOFM) begin
      ns=Idle;
      case(ps)
        Idle: begin
          if(req_left==1'b1 && LIF==1) ns=GiveAckLeft;
          else ns= Idle;
        end
        GiveAckLeft: begin
          if (req_left==1'b0) ns=WaitForData;
          else ns= GiveAckLeft;
        end
        WaitForData: begin
          ns= IFMBurst;
        end
        IFMBurst: begin
			if(FullEmptyIFM) begin
				if (RIF==1)ns = GiveReqRight;
				else ns = StartingP;
			end
			else ns = IFMBurst;
        end
		GiveReqRight: begin
          if(ack_right==1'b1) ns = ReqInAc;
		      else ns=GiveReqRight;
          end
		ReqInAc: begin
          if(ack_right==1'b0) ns = sendIFM;
		      else ns=ReqInAc;
        end
		waiting: begin
          ns=sendIFM;
        end
		sendIFM: begin
          if(FullEmptyIFM) ns = StartingP;
		      else ns=sendIFM;
        end
		StartingP: begin
          ns = StartingN;
        end
		StartingN: begin
          if(doneOFM) ns = Idle;
		      else ns=StartingN;
        end
        default : begin
          ns = Idle;
        end
      endcase
    end
    
    always@(posedge clk) begin
      if (rst) ps<=Idle;
      else ps<=ns;
    end
	
	assign start = (ps == StartingP);
	assign witeIFM = (ps == IFMBurst);
	assign readIFM = (ps == sendIFM);
	assign ack_left = (ps == GiveAckLeft);
	assign req_right = (ps == GiveReqRight);

	
endmodule
  
  