
#include "Architecture.h"
#include"ReadConfigs.h"
ofstream Trecord("TileRecords.txt");

int sc_main(int argc, char *argv[]) {


#define NOCDTR 0
#define TmemSize 2
#define TileDTR 1
#define mc 1 //
#define nc 1 //
#define CMemSize 2000
#define ClusDTR 1
#define mv 4 // 5 //3 //4
#define nv 4 // 5 //3 //4
#define VIVS 128
#define VOVS 16
#define VmmDTR 1
#define Dclk 1
#define Trow 18
#define Tcol 18
	Architecture< NOCDTR, TmemSize, TileDTR, mc, nc, CMemSize, ClusDTR, mv, nv, VIVS, VOVS, VmmDTR, Dclk,  Trow,  Tcol>Architecture1("Architecture", "VGG16_");


	sc_start();
	cout << "End of simulation is " << sc_time_stamp() << endl;
	system("pause");
	return 0;
}
